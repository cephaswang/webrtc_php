package tw.ibiz.yukachat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import com.squareup.picasso.Picasso
import android.view.View

class FullImageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_image)

        val imageView = findViewById<ImageView>(R.id.fullImageView)
        val imageUrl = intent.getStringExtra("imageUrl")

        imageUrl?.let {
            Picasso.get()
                .load(it)
                .into(imageView)
        }

        // 點擊圖片關閉
        imageView.setOnClickListener {
            finish()
        }
    }
}