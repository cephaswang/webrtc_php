package tw.ibiz.yukachat

import android.app.AlertDialog
import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.IOException
import org.json.JSONObject // Added for JSON parsing

object LogUtils {
    private const val LOG_FILE_NAME = "yuka_log.txt"
    private const val MAX_LOG_SIZE_BYTES = 1024 * 1024 // 1MB

    // Original logToFile method remains unchanged
    fun logToFile(context: Context, message: String) {
        try {
            val timestamp =
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val logMessage = "[$timestamp] $message\n"
            Log.d("LogFile", "寫入日誌: $logMessage")

            val logFile = File(context.filesDir, LOG_FILE_NAME)

            if (logFile.exists() && logFile.length() > MAX_LOG_SIZE_BYTES) {
                logFile.delete()
            }

            FileOutputStream(logFile, true).use { fos ->
                fos.write(logMessage.toByteArray())
            }
        } catch (e: Exception) {
            Log.e("LogFile", "寫入日誌檔案失敗: ${e.message}")
        }
    }


    fun uploadLogFile(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val sharedPreferences =
                    context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                val xid = sharedPreferences.getString("xid", "") ?: ""

                val logFile = File(context.filesDir, LOG_FILE_NAME)
                if (!logFile.exists()) {
                    withContext(Dispatchers.Main) {
                        Log.d("LogFile", "日誌檔案不存在，無法上傳")
                        AlertDialog.Builder(context)
                            .setTitle("上傳失敗")
                            .setMessage("日誌檔案不存在，無法上傳")
                            .setPositiveButton("確定") { _, _ -> }
                            .show()
                    }
                    return@launch
                }

                // Prepare the multipart request body
                val requestBody = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(
                        "file",
                        LOG_FILE_NAME,
                        logFile.asRequestBody("text/plain".toMediaType())
                    )
                    .build()

// https://ims.yukaai.com/app/log/?mode=upload&xid=

                var upLoadUrl = "${ConfigIni.SERVER_URL}upload_log.php?xid=$xid"
                     upLoadUrl = "http://192.168.0.100/upload_log.php?xid=$xid"
                //  upLoadUrl = "${ConfigIni.SERVER_URL}app/log/?mode=upload&xid=$xid"

                // Build the request
                val request = Request.Builder()
                    .url(upLoadUrl)
                    .post(requestBody)
                    .build()

                // Execute the network request
                val client = OkHttpClient()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        // Parse the JSON response
                        val responseBody = response.body?.string()


                        val responseMessage = try {
                            val json = JSONObject(responseBody ?: "{}")

                            Log.d("json", json.toString())

                            val logUrl = json.getString("logUrl")
                            Log.d("json", logUrl)
                            json.getString("title") // Extract the 'title' field
                        } catch (e: Exception) {
                            "無法解析回應: ${e.message}"
                        }

                        withContext(Dispatchers.Main) {
                            Log.d("LogFile", "日誌檔案上傳成功: $responseMessage (URL: $upLoadUrl)")
                            logToFile(
                                context,
                                "[INFO] Log file uploaded successfully: $responseMessage"
                            )
                            AlertDialog.Builder(context)
                                .setTitle("上傳提示")
                                .setMessage("日誌檔案上傳成功: $responseMessage")
                                .setPositiveButton("確定") { _, _ -> }
                                .show()
                        }
                    } else {
                        val errorMessage = "日誌檔案上傳失敗: ${response.code}"
                        withContext(Dispatchers.Main) {
                            Log.e("LogFile", errorMessage)
                            logToFile(context, "[ERROR] $errorMessage")
                            AlertDialog.Builder(context)
                                .setTitle("上傳失敗")
                                .setMessage(errorMessage)
                                .setPositiveButton("確定") { _, _ -> }
                                .show()
                        }
                    }
                }
            } catch (e: IOException) {
                val errorMessage = "日誌檔案上傳異常: ${e.message}"
                withContext(Dispatchers.Main) {
                    Log.e("LogFile", errorMessage)
                    logToFile(context, "[ERROR] $errorMessage")
                    AlertDialog.Builder(context)
                        .setTitle("上傳異常")
                        .setMessage(errorMessage)
                        .setPositiveButton("確定") { _, _ -> }
                        .show()
                }
            } catch (e: Exception) {
                val errorMessage = "日誌檔案上傳未知錯誤: ${e.message}"
                withContext(Dispatchers.Main) {
                    Log.e("LogFile", errorMessage)
                    logToFile(context, "[ERROR] $errorMessage")
                    AlertDialog.Builder(context)
                        .setTitle("上傳錯誤")
                        .setMessage(errorMessage)
                        .setPositiveButton("確定") { _, _ -> }
                        .show()
                }
            }
        }
    }


    // Other methods remain unchanged
    fun clearLogFile(context: Context) {
        try {
            val logFile = File(context.filesDir, LOG_FILE_NAME)
            if (logFile.exists()) {
                logFile.delete()
            }
        } catch (e: Exception) {
            Log.e("LogFile", "清除日誌檔案失敗: ${e.message}")
        }
    }

    fun readLogFile(context: Context): String {
        return try {
            val logFile = File(context.filesDir, LOG_FILE_NAME)
            if (logFile.exists()) {
                logFile.readText()
            } else {
                "日誌檔案不存在"
            }
        } catch (e: Exception) {
            Log.e("LogFile", "讀取日誌檔案失敗: ${e.message}")
            "讀取日誌檔案失敗: ${e.message}"
        }
    }

    fun logError(context: Context, tag: String, message: String, e: Throwable? = null) {
        val fullMessage = if (e != null) {
            "$message - ${e.message}\n${e.stackTraceToString()}"
        } else {
            message
        }
        Log.e(tag, fullMessage)
        logToFile(context, "[ERROR] $tag: $fullMessage")
    }

    fun logDebug(context: Context, tag: String, message: String) {
        Log.d(tag, message)
        logToFile(context, "[DEBUG] $tag: $message")
    }

    fun logInfo(context: Context, tag: String, message: String) {
        Log.i(tag, message)
        logToFile(context, "[INFO] $tag: $message")
    }
}