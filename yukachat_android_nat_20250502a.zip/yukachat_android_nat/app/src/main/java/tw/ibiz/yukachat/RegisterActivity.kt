package tw.ibiz.yukachat

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.ProgressDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.URLEncoder
import java.util.regex.Pattern

class RegisterActivity : AppCompatActivity() {

    private lateinit var scrollView: ScrollView
    private lateinit var nameLabel: TextView
    private lateinit var nameField: EditText
    private lateinit var genderLabel: TextView
    private lateinit var genderField: TextView
    private lateinit var triangleImageView: ImageView
    private lateinit var usernameLabel: TextView
    private lateinit var usernameField: EditText
    private lateinit var passwordLabel: TextView
    private lateinit var passwordField: EditText
    private lateinit var emailLabel: TextView
    private lateinit var emailField: EditText
    private lateinit var mobileLabel: TextView
    private lateinit var mobileField: EditText
    private lateinit var registerButton: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_register)
            Log.d("RegisterActivity", "onCreate")

            initializeUI()
            setupClickListeners()
            setupTextFields()
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "onCreate failed", e)
        }
    }

    private fun initializeUI() {
        try {
            val backButton: ImageView = findViewById(R.id.backButton)
            backButton.setOnClickListener {
                Log.d("RegisterActivity", "返回按鈕被點擊")
                finish()
            }

            title = "註冊帳號"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_chevron_left)

            // Initialize views
            scrollView = findViewById(R.id.scrollView)
            nameLabel = findViewById(R.id.nameLabel)
            nameField = findViewById(R.id.nameField)
            genderLabel = findViewById(R.id.genderLabel)
            genderField = findViewById(R.id.genderField)
            triangleImageView = findViewById(R.id.triangleImageView)
            usernameLabel = findViewById(R.id.usernameLabel)
            usernameField = findViewById(R.id.usernameField)
            passwordLabel = findViewById(R.id.passwordLabel)
            passwordField = findViewById(R.id.passwordField)
            emailLabel = findViewById(R.id.emailLabel)
            emailField = findViewById(R.id.emailField)
            mobileLabel = findViewById(R.id.mobileLabel)
            mobileField = findViewById(R.id.mobileField)
            registerButton = findViewById(R.id.registerButton)
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "initializeUI failed", e)
        }
    }

    private fun setupClickListeners() {
        try {
            registerButton.setOnClickListener { registerButtonTapped() }
            genderField.setOnClickListener { didTapChangeGenderLabel() }
            triangleImageView.setOnClickListener { didTapChangeGenderLabel() }
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "setupClickListeners failed", e)
        }
    }

    private fun setupTextFields() {
        try {
            nameField.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    usernameField.requestFocus()
                    true
                } else {
                    false
                }
            }

            usernameField.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    passwordField.requestFocus()
                    true
                } else {
                    false
                }
            }

            passwordField.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    emailField.requestFocus()
                    true
                } else {
                    false
                }
            }

            emailField.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_NEXT) {
                    mobileField.requestFocus()
                    true
                } else {
                    false
                }
            }

            mobileField.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    registerButtonTapped()
                    true
                } else {
                    false
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "setupTextFields failed", e)
        }
    }

    private fun isValidPhoneNumber(phoneNumber: String): Boolean {
        try {
            val phoneRegex = "^09[0-9]{8}$"
            return Pattern.matches(phoneRegex, phoneNumber)
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "isValidPhoneNumber validation failed", e)
            return false
        }
    }

    private fun isValidEmail(email: String): Boolean {
        try {
            val emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            return Pattern.matches(emailRegex, email)
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "isValidEmail validation failed", e)
            return false
        }
    }

    private fun showAlert(message: String, completion: (() -> Unit)? = null) {
        try {
            val alertDialog = AlertDialog.Builder(this)
                .setTitle("提示")
                .setMessage(message)
                .setPositiveButton("確定") { _, _ -> completion?.invoke() }
                .create()

            alertDialog.show()
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "showAlert failed: $message", e)
        }
    }

    private fun alertUserLoginError(message: String = "請填寫完整正確的資料") {
        showAlert(message)
    }

    private fun registerUser(username: String, password: String, name: String, email: String, gender: String, mobile: String) {
        try {
            if (password.length < 6) {
                alertUserLoginError(message = "密碼長度至少需要6位")
                return
            }

            val progressDialog = ProgressDialog(this).apply {
                setMessage("處理中...")
                setCancelable(false)
                show()
            }

            val xid = getSharedPreferences("AppPrefs", MODE_PRIVATE).getString("xid", "") ?: ""

            val genderValue = when(gender) {
                "先生" -> "m"
                "小姐" -> "f"
                else -> ""
            }

            val encodedUsername = URLEncoder.encode(username, "UTF-8")
            val encodedPassword = URLEncoder.encode(password, "UTF-8")
            val encodedName = URLEncoder.encode(name, "UTF-8")
            val encodedEmail = URLEncoder.encode(email, "UTF-8")
            val encodedGender = URLEncoder.encode(genderValue, "UTF-8")
            val encodedMobile = URLEncoder.encode(mobile, "UTF-8")

            val urlString = "${ConfigIni.SERVER_URL}user/app/api/?mode=insert" +
                    "&username=$encodedUsername" +
                    "&password=$encodedPassword" +
                    "&name=$encodedName" +
                    "&gender=$encodedGender" +
                    "&email=$encodedEmail" +
                    "&mobile=$encodedMobile" +
                    "&xid=$xid"

            Log.d("RegisterActivity", "Register URL: $urlString")

            Thread {
                try {
                    val url = java.net.URL(urlString)
                    val connection = url.openConnection() as java.net.HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 15000 // 15秒連線超時
                    connection.readTimeout = 15000 // 15秒讀取超時

                    val responseCode = connection.responseCode
                    val inputStream = if (responseCode == 200) connection.inputStream else connection.errorStream
                    val response = inputStream.bufferedReader().use { it.readText() }

                    runOnUiThread {
                        try {
                            progressDialog.dismiss()

                            val json = JSONObject(response)
                            Log.d("RegisterActivity", json.toString())

                            if (json.has("status") && json.getString("status") == "succ") {
                                showAlert(message = "註冊成功") {
                                    finish()
                                }
                            } else {
                                val errorMsg = if (json.has("message")) json.getString("message") else "註冊失敗，請稍後再試"
                                showAlert(message = errorMsg)
                            }
                        } catch (e: Exception) {
                            LogUtils.logError(this, "RegisterActivity", "解析註冊響應失敗", e)
                            showAlert(message = "註冊處理失敗，請稍後再試")
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        try {
                            progressDialog.dismiss()
                            LogUtils.logError(this, "RegisterActivity", "註冊請求失敗", e)
                            showAlert(message = "連線失敗，請檢查網路連接")
                        } catch (innerE: Exception) {
                            LogUtils.logError(this, "RegisterActivity", "UI更新失敗", innerE)
                        }
                    }
                }
            }.start()
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "registerUser調用失敗", e)
            showAlert(message = "註冊處理失敗，請稍後再試")
        }
    }

    private fun backButtonTapped() {
        try {
            finish()
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "backButtonTapped failed", e)
        }
    }

    @SuppressLint("ResourceAsColor")
    private fun didTapChangeGenderLabel() {
        try {
            val options = arrayOf("先生", "小姐", "未定", "")

            val customTitle = TextView(this).apply {
                text = "性別"
                setTextColor(Color.BLACK)
                textSize = 20f
                setPadding(32, 32, 32, 16)
                typeface = Typeface.DEFAULT_BOLD
            }

            val dialog = AlertDialog.Builder(this)
                .setCustomTitle(customTitle)
                .setItems(options) { _, which ->
                    val selectedOption = options[which]
                    if (selectedOption.isNotEmpty()) {
                        genderField.text = selectedOption
                    }
                }
                .setNegativeButton("Done") { dialog, _ ->
                    dialog.dismiss()
                }
                .create()
                .apply {
                    window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)

                    listView?.apply {
                        divider = ColorDrawable(Color.parseColor("#EEEEEE"))
                        dividerHeight = 6

                        setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                            override fun onChildViewAdded(parent: View?, child: View?) {
                                if (child is TextView) {
                                    child.setTextColor(Color.BLACK)
                                }
                            }
                            override fun onChildViewRemoved(parent: View?, child: View?) {}
                        })
                    }
                }

            dialog.show()
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "didTapChangeGenderLabel failed", e)
        }
    }

    private fun registerButtonTapped() {
        try {
            val name = nameField.text.toString().trim()
            val username = usernameField.text.toString().trim()
            val email = emailField.text.toString().trim()
            val password = passwordField.text.toString()
            val gender = genderField.text.toString()
            val mobile = mobileField.text.toString().trim()

            if (name.isEmpty() || username.isEmpty() || email.isEmpty() ||
                password.isEmpty() || gender.isEmpty() || mobile.isEmpty()) {
                alertUserLoginError()
                return
            }

            // 驗證郵箱和手機號
            if (!isValidEmail(email)) {
                alertUserLoginError("請輸入有效的電子郵件地址")
                return
            }

            if (!isValidPhoneNumber(mobile)) {
                alertUserLoginError("請輸入有效的手機號碼，必須是09開頭的10位數字")
                return
            }

            registerUser(username, password, name, email, gender, mobile)
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "registerButtonTapped processing failed", e)
            showAlert(message = "處理註冊資料時發生錯誤")
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        try {
            backButtonTapped()
            return true
        } catch (e: Exception) {
            LogUtils.logError(this, "RegisterActivity", "onSupportNavigateUp failed", e)
            return false
        }
    }
}