package tw.ibiz.yukachat

import android.content.Context
import android.net.ConnectivityManager
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class NetworkMonitor(private val activity: AppCompatActivity) {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var networkCheckRunnable: Runnable
    private val httpClient = OkHttpClient.Builder().connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS).build()
    private var isAlertShowing = false
    private var alertDialog: AlertDialog? = null

    fun startNetworkCheck() {
        networkCheckRunnable = object : Runnable {
            override fun run() {
                checkNetworkConnection()
                handler.postDelayed(this, 10000)
            }
        }
        handler.post(networkCheckRunnable)
    }

    fun stopNetworkCheck() {
        handler.removeCallbacks(networkCheckRunnable)
        alertDialog?.dismiss()
        isAlertShowing = false
    }

    private fun checkNetworkConnection() {
        if (activity.isFinishing || activity.isDestroyed) return

        val connectivityManager = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        if (networkInfo == null || !networkInfo.isConnected) {
            showNetworkAlert("設備無網路連線")
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val request = Request.Builder().url(ConfigIni.SERVER_URL).head().build()
                httpClient.newCall(request).execute().use { response ->
                    withContext(Dispatchers.Main) {
                        if (!response.isSuccessful && !isAlertShowing) {
                            showNetworkAlert("無法連接到伺服器")
                        }
                    }
                }
            } catch (e: IOException) {
                withContext(Dispatchers.Main) {
                    if (!isAlertShowing) {
                        showNetworkAlert("網路連線測試失敗")
                    }
                }
            }
        }
    }

    private fun showNetworkAlert(message: String) {
        if (activity.isFinishing || activity.isDestroyed) return
        activity.runOnUiThread {
            if (!isAlertShowing) {
                isAlertShowing = true
                alertDialog?.dismiss()
                alertDialog = AlertDialog.Builder(activity)
                    .setTitle("網路錯誤")
                    .setMessage("$message，請檢查您的網路設定")
                    .setPositiveButton("確定") { dialog, _ ->
                        isAlertShowing = false
                        dialog.dismiss()
                    }
                    .setCancelable(false)
                    .create()
                alertDialog?.show()
            }
        }
    }
}