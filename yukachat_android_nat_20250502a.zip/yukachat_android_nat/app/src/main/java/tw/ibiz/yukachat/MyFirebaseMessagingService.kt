package tw.ibiz.yukachat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/*


Android 12 kotlin

MyFirebaseMessagingService : FirebaseMessagingService()
fun sendTokenToServer
傳送 API token 到服務器，(get) 用 okhttp 整個 package 所有 web api 都只有一個連線
https://ims.yukaai.com/app/api/?mode=token&device=android&token=token&language=tw
讀取回傳 json ，並解析 cmark 的值， cmark 寫入 SharedPreferences name:AppPrefs 記錄


ConversationsActivity

按鍵1事件
https://ims.yukaai.com/user/app/api/?mode=log_in

按鍵2事件
https://ims.yukaai.com/app/api/?mode=token


中文回答



運行 firebase

*/


class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("Firebase", "onNewToken triggered: $token")
        // 使用 applicationContext 傳入 Context

        val sharedPref = applicationContext.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        sharedPref.edit().putString("token", token).apply()
        val xid = sharedPref.getString("xid", "") ?: ""

        sendTokenToServer(applicationContext, token, xid)
    }


    private  fun sendTokenToServer(context: Context, token: String, xid: String) {
        Thread {
            try {
                // API URL
                val urlString = "${ConfigIni.SERVER_URL}app/api/?mode=token&device=android&xid=$xid&token=$token&language=tw"
                Log.d("MessagingService", urlString)

                val url = URL(urlString)

                // 開啟 HTTP 連線
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                // 讀取回應
                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    Log.d("API_RESPONSE", response)

                    // 解析 JSON
                    val jsonObject = JSONObject(response)
                    val xid = jsonObject.optString("xid", "")
                    //ConfigIni.xid = xid

                    // 儲存 cmark 到 SharedPreferences
                    val sharedPreferences: SharedPreferences =
                        context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                    sharedPreferences.edit().putString("xid", xid).apply()
                    Log.d("MessagingService: xid", xid)


                    Log.d("TOKEN_UPDATE", "xid saved: $xid")
                } else {
                    Log.e("API_ERROR", "Response Code: $responseCode")
                }

                connection.disconnect()
            } catch (e: Exception) {
                Log.e("API_ERROR", "Exception: ${e.message}")
            }
        }.start()
    }

    private fun showNotification(title: String, message: String) {
        val channelId = "chat_notifications"
        val notificationId = System.currentTimeMillis().toInt()
        val intent = Intent(this, ConversationsActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification) // 確保你有這個圖示
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message)) // 展示完整訊息
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // 設置 Android 8.0+ 通知頻道
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "聊天通知",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "顯示聊天推播訊息"
            }
            notificationManager.createNotificationChannel(channel)
        }

        notificationManager.notify(notificationId, notificationBuilder.build())
    }


    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        // 確保 notification 存在
        val notification = remoteMessage.notification
        if (notification != null) {
            val title = notification.title ?: "新通知"
            val message = notification.body ?: "你有一則新訊息"
            showNotification(title, message)
        } else {
            Log.e("Firebase", "推播訊息未包含 notification 欄位")
        }
    }


}


