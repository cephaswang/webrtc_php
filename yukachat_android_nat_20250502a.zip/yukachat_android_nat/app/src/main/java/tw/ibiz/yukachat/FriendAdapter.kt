package tw.ibiz.yukachat

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Locale

class FriendAdapter(
    private val friendList: List<Friend>,
    private val onItemClick: (Friend) -> Unit
) : RecyclerView.Adapter<FriendAdapter.FriendViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FriendViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_friend, parent, false)
        return FriendViewHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: FriendViewHolder, position: Int) {
        val friend = friendList[position]
        holder.bind(friend)
        holder.itemView.setOnClickListener { onItemClick(friend) }

        if (friend.unread > 0) {
            holder.tvUnread.text = friend.unread.toString()
            holder.tvUnread.visibility = View.VISIBLE
        } else {
            holder.tvUnread.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int = friendList.size

    class FriendViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivAvatar: ImageView = itemView.findViewById(R.id.ivAvatar)
        private val tvName: TextView = itemView.findViewById(R.id.tvName)
        private val tvMessage: TextView = itemView.findViewById(R.id.tvMessage)
        private val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val tvUnread: TextView = itemView.findViewById(R.id.tvUnread)

        fun bind(friend: Friend) {
            // 載入頭像，處理 null 或無效 URL
            Glide.with(itemView.context)
                .load(friend.targetFigure?.takeIf { it.isNotEmpty() })
                .placeholder(R.drawable.ic_default_avatar)
                .error(R.drawable.ic_default_avatar)
                .into(ivAvatar)

            // 設置名稱，處理 null
            tvName.text = friend.targetName ?: "未知用戶"

            // 處理最新訊息，檢查 null
            tvMessage.text = friend.lateMessage?.let {
                try {
                    URLDecoder.decode(it, "UTF-8")
                } catch (e: Exception) {
                    it // 如果解碼失敗，使用原始訊息
                }
            } ?: ""

            // 處理時間顯示
            tvTime.text = formatTime(friend.timeLate)
        }

        private fun formatTime(timeLate: String?): String {
            if (timeLate.isNullOrEmpty()) return ""

            try {
                // 支援多種時間格式
                val inputFormat = when {
                    timeLate.contains("T") -> SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                    timeLate.matches(Regex("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}")) ->
                        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    else -> SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                }
                val outputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val date = inputFormat.parse(timeLate)
                return date?.let { outputFormat.format(it) } ?: ""
            } catch (e: Exception) {
                // 如果解析失敗，返回空字符串
                return ""
            }
        }
    }
}