package tw.ibiz.yukachat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.stfalcon.chatkit.messages.MessagesListAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

@RequiresApi(Build.VERSION_CODES.O)
class ChatManager(
    private val context: Context,
    private val userId: String,
    private val targetXid: String,
    private val messagesAdapter: MessagesListAdapter<ChatMessage>,
    private val onError: (String, String) -> Unit
) {

    private val httpClient = OkHttpClient.Builder().readTimeout(3, TimeUnit.SECONDS).build()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    private lateinit var mediaPlayer: MediaPlayer

    private val messageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    when (intent.getStringExtra("type")) {
                        "message" -> handleTextMessage(intent)
                        "file" -> handleFileMessage(intent)
                        "WebSocket_Fail" -> onError("WebSocket 連線失敗", "無法連接到伺服器，正在嘗試重新連線")
                        "WebSocket_Pass" -> {} // 連線成功不做處理
                    }
                } catch (e: Exception) {
                    if (context != null) {
                        LogUtils.logError(context, "ChatManager", "BroadcastReceiver 處理失敗", e)
                    }
                    onError("錯誤", "訊息接收處理失敗：${e.message}")
                }
            }
        }
    }

    init {
        try {
            val filter = IntentFilter("tw.ibiz.yukachat.MESSAGE_RECEIVED")
            LocalBroadcastManager.getInstance(context).registerReceiver(messageReceiver, filter)

            mediaPlayer = MediaPlayer.create(context, R.raw.notify)
                ?: throw IllegalStateException("無法初始化 MediaPlayer")

            val serviceIntent = Intent(context, WebSocketService::class.java)
            serviceIntent.putExtra("userId", userId)
            context.startForegroundService(serviceIntent)
            // 確保通知渠道已創建
            createNotificationChannel()
        } catch (e: Exception) {
            LogUtils.logError(context, "ChatManager", "初始化失敗", e)
            onError("初始化錯誤", "無法啟動 ChatManager：${e.message}")
        }
    }

    private fun createNotificationChannel() {
        val channelId = "chat_channel"
        val channelName = "聊天通知"
        val channelDescription = "新訊息通知"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(channelId, channelName, importance).apply {
            description = channelDescription
        }

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (notificationManager.getNotificationChannel(channelId) == null) {
            notificationManager.createNotificationChannel(channel)
            Log.d("NotificationChannel", "通知渠道已建立")
        } else {
            Log.d("NotificationChannel", "通知渠道已存在")
        }
    }

    fun sendTextMessage(text: String) {
        try {
            val message = ChatMessage(UUID.randomUUID().toString(), userId, "You", "", text, null, Date())
            messagesAdapter.addToStart(message, true)

            val serviceIntent = Intent(context, WebSocketService::class.java).apply {
                putExtra("action", "send_text")
                putExtra("fromXid", userId)
                putExtra("targetXid", targetXid)
                putExtra("message", text)
            }
            context.startService(serviceIntent)
        } catch (e: Exception) {
            LogUtils.logError(context, "ChatManager", "發送文字訊息失敗", e)
            onError("錯誤", "發送訊息失敗：${e.message}")
        }
    }

    fun sendImageMessage(imageUrl: String) {
        try {
            val message = ChatMessage(UUID.randomUUID().toString(), userId, "You", "", null, imageUrl, Date())
            messagesAdapter.addToStart(message, true)

            val serviceIntent = Intent(context, WebSocketService::class.java).apply {
                putExtra("action", "send_image")
                putExtra("fromXid", userId)
                putExtra("targetXid", targetXid)
                putExtra("imageUrl", imageUrl)
            }
            context.startService(serviceIntent)
        } catch (e: Exception) {
            LogUtils.logError(context, "ChatManager", "發送圖片訊息失敗", e)
            onError("錯誤", "發送圖片失敗：${e.message}")
        }
    }

    fun fetchMessages() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = "${ConfigIni.SERVER_URL}im/app/api/?mode=target_message&xid=$userId&target_sid=$targetXid&property=all"
                val request = Request.Builder().url(url).build()
                httpClient.newCall(request).execute().use { response ->
                    response.body?.string()?.let { parseMessages(it) }
                        ?: throw IllegalStateException("伺服器回應為空")
                }
            } catch (e: Exception) {
                LogUtils.logError(context, "ChatManager", "獲取訊息失敗", e)
                withContext(Dispatchers.Main) {
                    onError("錯誤", "無法獲取歷史訊息：${e.message}")
                }
            }
        }
    }

    private suspend fun parseMessages(jsonResponse: String) {
        withContext(Dispatchers.Main) {
            try {
                val jsonObject = JSONObject(jsonResponse)
                if (!jsonObject.has("status")) {
                    throw IllegalStateException("伺服器回應格式無效")
                }
                if (jsonObject.getString("status") == "succ") {
                    val data = jsonObject.getJSONObject("data")
                    val target = data.getJSONObject("target")
                    val targetName = target.getString("name")
                    val targetFigure = target.getString("figure")
                    val messagesArray = data.getJSONArray("message")
                    val messageList = ArrayList<ChatMessage>()

                    for (i in 0 until messagesArray.length()) {
                        val messageObj = messagesArray.getJSONObject(i)
                        val id = messageObj.getString("id")
                        val type = messageObj.getString("type")
                        val message = if (messageObj.isNull("message")) null else messageObj.getString("message")
                        val imageList = if (messageObj.isNull("image_list")) null else messageObj.getString("image_list")
                        val timeAdd = messageObj.getString("time_add")
                        val date = dateFormat.parse(timeAdd) ?: Date()
                        val authorId = if (type == "s") userId else targetXid
                        val authorName = if (type == "s") "You" else targetName
                        val authorAvatar = if (type == "s") "" else targetFigure

                        val chatMessage = if (imageList != null) {
                            ChatMessage(id, authorId, authorName, authorAvatar, null, imageList, date)
                        } else {
                            ChatMessage(id, authorId, authorName, authorAvatar, message ?: "", null, date)
                        }
                        messageList.add(chatMessage)
                    }
                    messagesAdapter.addToEnd(messageList, true)
                } else {
                    throw IllegalStateException("伺服器回應狀態異常")
                }
            } catch (e: Exception) {
                LogUtils.logError(context, "ChatManager", "解析訊息失敗", e)
                onError("錯誤", "解析歷史訊息失敗：${e.message}")
            }
        }
    }

    private fun handleTextMessage(intent: Intent) {
        Log.d("handleTextMessage", "")
        try {
            val userSid = intent.getStringExtra("user_sid") ?: return
            val name = intent.getStringExtra("name") ?: "對方"
            val figure = intent.getStringExtra("figure") ?: ""
            val message = intent.getStringExtra("message")?.let { URLDecoder.decode(it, "UTF-8") } ?: ""
            val timeAdd = intent.getStringExtra("time_add") ?: ""
            val date = try {
                dateFormat.parse(timeAdd) ?: Date()
            } catch (e: Exception) {
                LogUtils.logError(context, "ChatManager", "日期解析失敗", e)
                Date()
            }

            Log.d("handleTextMessage", message)
            if (!mediaPlayer.isPlaying) mediaPlayer.start()

            if (userSid != targetXid) {
                Log.d("handleTextMessage", "userSid != targetXid")
                try {
                    val notificationManager =
                        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                    // 使用訊息內容的雜湊值作為 notificationId (更穩定的唯一 ID)
                    val notificationId = message.hashCode()

                    // **重要：更換成你應用程式的圖示！**
                    val notificationBuilder = NotificationCompat.Builder(context, "chat_channel")
                        .setSmallIcon(R.drawable.ic_notification) // 替換成你的圖示
                        .setContentTitle("新訊息")
                        .setContentText("收到來自 $name 的訊息: $message")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setAutoCancel(true)

                    notificationManager.notify(notificationId, notificationBuilder.build())
                    Log.d("通知", "通知已發送 userSid=$userSid, targetXid=$targetXid")

                    return
                } catch (e: Exception) {
                    LogUtils.logError(context, "ChatManager", "處理檔案訊息失敗", e)
                    onError("錯誤", "處理檔案訊息失敗：${e.message}")
                }
            }

            // 原有邏輯：處理目標對象的訊息
            val chatMessage = ChatMessage(UUID.randomUUID().toString(), userSid, name, figure, message, null, date)
            messagesAdapter.addToStart(chatMessage, true)

        } catch (e: Exception) {
            LogUtils.logError(context, "ChatManager", "處理文字訊息失敗", e)
            onError("錯誤", "處理文字訊息失敗：${e.message}")
        }
    }


    private fun handleFileMessage(intent: Intent) {
        Log.d("handleFileMessage","")
        try {
            val userSid = intent.getStringExtra("user_sid") ?: return
            val name = intent.getStringExtra("name") ?: "對方"
            val figure = intent.getStringExtra("figure") ?: ""
            val fileList = intent.getStringExtra("file_list") ?: ""
            val timeAdd = intent.getStringExtra("time_add") ?: ""
            val date = try {
                dateFormat.parse(timeAdd) ?: Date()
            } catch (e: Exception) {
                LogUtils.logError(context, "ChatManager", "日期解析失敗", e)
                Date()
            }

            Log.d("handleFileMessage",fileList)
            if (!mediaPlayer.isPlaying) mediaPlayer.start()

            if (userSid != targetXid) {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val notificationId = System.currentTimeMillis().toInt()

                val notificationBuilder = NotificationCompat.Builder(context, "chat_channel")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("新訊息")
                    .setContentText("收到 $name，圖檔")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)

                notificationManager.notify(notificationId, notificationBuilder.build())
                return
            }

            val chatMessage = ChatMessage(UUID.randomUUID().toString(), userSid, name, figure, null, fileList, date)

            messagesAdapter.addToStart(chatMessage, true)
        } catch (e: Exception) {
            LogUtils.logError(context, "ChatManager", "處理檔案訊息失敗", e)
            onError("錯誤", "處理檔案訊息失敗：${e.message}")
        }
    }


    fun cleanup() {
        try {
            if (mediaPlayer.isPlaying) mediaPlayer.stop()
            mediaPlayer.release()
            LocalBroadcastManager.getInstance(context).unregisterReceiver(messageReceiver)
            val serviceIntent = Intent(context, WebSocketService::class.java)
            if (context.stopService(serviceIntent)) {
                LogUtils.logInfo(context, "ChatManager", "WebSocketService 已停止")
            }
            messagesAdapter.clear()
        } catch (e: Exception) {
            LogUtils.logError(context, "ChatManager", "清理資源失敗", e)
            onError("錯誤", "清理資源失敗：${e.message}")
        }
    }
}