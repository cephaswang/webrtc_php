package tw.ibiz.yukachat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

class WebSocketService : Service() {

    private var webSocket: WebSocket? = null
    private val client = OkHttpClient()
    private var webSocketListener: EchoWebSocketListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private val heartbeatInterval = 30000L // 30 seconds heartbeat interval
    private var userId: String? = null
    private var userSid: String? = null
    private val networkCheckInterval = 10000L // 10 seconds network check interval

    override fun onCreate() {
        super.onCreate()
        try {
            val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            userId = sharedPref.getString("xid", "") ?: ""
            userSid = sharedPref.getString("sid", "") ?: ""

            createNotificationChannel()
            startForeground(1, createNotification())
            startNetworkCheck()
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error in onCreate", e)
            stopSelf()
        }
    }

    private fun startNetworkCheck() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                try {
                    if (isWebSocketConnected()) {
                       // LogUtils.logDebug(this@WebSocketService, "WebSocketService", "WebSocket is connected")
                    } else {
                        //LogUtils.logInfo(this@WebSocketService, "WebSocketService", "WebSocket not connected. Attempting to reconnect")
                        userId?.let { connectWebSocket(it) }
                    }
                    handler.postDelayed(this, networkCheckInterval)
                } catch (e: Exception) {
                    LogUtils.logError(this@WebSocketService, "WebSocketService", "Error in network check", e)
                }
            }
        }, networkCheckInterval)
    }

    private fun isWebSocketConnected(): Boolean {
        return try {
            isNetworkAvailable() && webSocketListener?.isWebSocketClosed == false
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error checking WebSocket connection", e)
            false
        }
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = connectivityManager.activeNetwork ?: return false
            val networkCapabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
            networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error checking network availability", e)
            false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            userId?.let { uid ->
                if (webSocket == null || webSocketListener?.isWebSocketClosed == true) {
                    connectWebSocket(uid)
                }
            }

            intent?.let { it ->
                when (it.getStringExtra("action")) {
                    "send_text" -> {
                        val fromXid = it.getStringExtra("fromXid") ?: ""
                        val targetXid = it.getStringExtra("targetXid") ?: ""
                        val message = it.getStringExtra("message") ?: ""
                        sendMessage(fromXid, targetXid, message, null)
                    }
                    "send_image" -> {
                        val fromXid = it.getStringExtra("fromXid") ?: ""
                        val targetXid = it.getStringExtra("targetXid") ?: ""
                        val imageUrl = it.getStringExtra("imageUrl") ?: ""
                        sendMessage(fromXid, targetXid, null, imageUrl)
                    }
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error in onStartCommand", e)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            webSocket?.close(1000, "Service stopped")
            handler.removeCallbacksAndMessages(null)
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error in onDestroy", e)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun connectWebSocket(userId: String) {
        try {
            val request = Request.Builder()
                .url("${ConfigIni.WEBSOCKET_URL}?xid=$userId")
                .build()
            webSocketListener = EchoWebSocketListener()
            webSocket = client.newWebSocket(request, webSocketListener!!)
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error connecting WebSocket", e)
        }
    }

    private fun sendMessage(fromXid: String, targetXid: String, message: String?, imageUrl: String?) {
        try {
            if (webSocket == null || webSocketListener?.isWebSocketClosed == true) {
                LogUtils.logError(this, "WebSocketService", "WebSocket not connected, attempting reconnect")
                userId?.let { connectWebSocket(it) }
                return
            }

            val jsonMessage = when {
                !message.isNullOrEmpty() -> """
                    {
                        "type": "send_text",
                        "sid": "$userSid",
                        "xid": "$userId",
                        "target_sid": "$targetXid",
                        "message": "$message"
                    }
                """.trimIndent()

                !imageUrl.isNullOrEmpty() -> """
                    {
                        "type": "send_image",
                        "sid": "$userSid",
                        "xid": "$userId",
                        "target_sid": "$targetXid",
                        "image": "$imageUrl"
                    }
                """.trimIndent()

                else -> return
            }

            webSocket?.let { ws ->
                val isSent = ws.send(jsonMessage)
                if (isSent) {
                  //  LogUtils.logDebug(this, "WebSocketService", "Message sent successfully: $jsonMessage")
                } else {
                    LogUtils.logError(this, "WebSocketService", "Failed to send message")
                    userId?.let { connectWebSocket(it) }
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error sending message", e)
            userId?.let { connectWebSocket(it) }
        }
    }

    private fun createNotification(): Notification {
        return try {
            val notificationIntent = Intent(this, ChatActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE)

            NotificationCompat.Builder(this, "websocket_channel")
                .setContentTitle("聊天服務")
                .setContentText("正在保持連線...")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .build()
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error creating notification", e)
            NotificationCompat.Builder(this, "websocket_channel")
                .setContentTitle("聊天服務")
                .setContentText("服務運行中")
                .build()
        }
    }

    private fun createNotificationChannel() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    "websocket_channel",
                    "WebSocket Service",
                    NotificationManager.IMPORTANCE_LOW
                )
                val manager = getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(channel)
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "WebSocketService", "Error creating notification channel", e)
        }
    }

    private inner class EchoWebSocketListener : WebSocketListener() {
        var isWebSocketClosed = false
        private var reconnectAttempts = 0
        private val MAX_RECONNECT_ATTEMPTS = 50000

        override fun onOpen(webSocket: WebSocket, response: Response) {
            try {
               // LogUtils.logDebug(this@WebSocketService, "WebSocket", "Connected")
                val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                val sid = sharedPref.getString("sid", "") ?: ""

                isWebSocketClosed = false
                val connectMessage = """
                    {
                        "type": "connect",
                        "sid": "$sid"
                    }
                """.trimIndent()

                val isSent = webSocket.send(connectMessage)
                if (isSent) {
                  //  LogUtils.logDebug(this@WebSocketService, "WebSocket", "Connect message sent successfully")
                    val intent = Intent("tw.ibiz.yukachat.MESSAGE_RECEIVED")
                    intent.putExtra("type", "WebSocket_Pass")
                    LocalBroadcastManager.getInstance(this@WebSocketService).sendBroadcast(intent)
                } else {
                    LogUtils.logError(this@WebSocketService, "WebSocket", "Failed to send connect message")
                }
            } catch (e: Exception) {
                LogUtils.logError(this@WebSocketService, "WebSocket", "Error in onOpen", e)
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
               // LogUtils.logDebug(this@WebSocketService, "WebSocket", "Received message: $text")
                Log.d("WebSocket", "Received message: $text")
                val jsonObject = JSONObject(text)
                val type = jsonObject.getString("type")

                if (type =="connect_ack"){
                    print("connect_ack")
                    return
                }

                val intent = Intent("tw.ibiz.yukachat.MESSAGE_RECEIVED").apply {
                    putExtra("type", jsonObject.getString("type"))
                    putExtra("sid", jsonObject.getString("sid"))
                    putExtra("user_sid", jsonObject.getString("user_sid"))
                    putExtra("name", jsonObject.getString("name"))
                    putExtra("figure", jsonObject.getString("figure"))
                    putExtra("message", jsonObject.optString("message", null))
                    putExtra("message_hint", jsonObject.optString("message_hint", null))
                    putExtra("file_list", jsonObject.optString("file_list", null))
                    putExtra("time_late", jsonObject.optString("time_late", null))
                    putExtra("unread", jsonObject.optString("unread", null))
                    putExtra("time_add", jsonObject.optString("time_add", null))
                }
                LocalBroadcastManager.getInstance(this@WebSocketService).sendBroadcast(intent)
            } catch (e: Exception) {
                LogUtils.logError(this@WebSocketService, "WebSocket", "Error parsing message", e)
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
         //   LogUtils.logDebug(this@WebSocketService, "WebSocket", "Closing: $code / $reason")
            isWebSocketClosed = true
            handler.removeCallbacksAndMessages(null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
          //  LogUtils.logDebug(this@WebSocketService, "WebSocket", "Closed: $code / $reason")
            isWebSocketClosed = true
            handler.removeCallbacksAndMessages(null)
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            try {
                LogUtils.logError(this@WebSocketService, "WebSocket", "Connection error", t)
                isWebSocketClosed = true
                handler.removeCallbacksAndMessages(null)

                val intent = Intent("tw.ibiz.yukachat.MESSAGE_RECEIVED")
                intent.putExtra("type", "WebSocket_Fail")
                LocalBroadcastManager.getInstance(this@WebSocketService).sendBroadcast(intent)

                if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                    val delay = 5000L
                //    LogUtils.logInfo(this@WebSocketService, "WebSocket",
                    //    "Reconnecting (${reconnectAttempts + 1}/$MAX_RECONNECT_ATTEMPTS) after ${delay/1000}s")

                    handler.postDelayed({
                        if (isWebSocketClosed && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                            reconnectAttempts++
                            userId?.let { connectWebSocket(it) }
                        }
                    }, delay)
                } else {
                    LogUtils.logError(this@WebSocketService, "WebSocket",
                        "Max reconnection attempts ($MAX_RECONNECT_ATTEMPTS) reached")
                    stopSelf()
                }
            } catch (e: Exception) {
                LogUtils.logError(this@WebSocketService, "WebSocket", "Error in onFailure", e)
            }
        }
    }
}