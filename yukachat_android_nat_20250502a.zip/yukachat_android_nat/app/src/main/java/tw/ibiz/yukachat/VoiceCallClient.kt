package tw.ibiz.yukachat

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI

class VoiceCallClient(
    private val context: Context,
    serverUri: String,
    private val listener: VoiceCallListener
) {
    companion object {
        const val REQUEST_CODE = 1001
    }

    private var webSocketClient: WebSocketClient? = null
    var partner: String? = null
    private var isReconnecting = false

    init {
        if (checkPermission()) {
            connectWebSocket(serverUri)
        }
    }

    fun checkPermission(): Boolean {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                context as VoiceMainActivity,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_CODE
            )
            return false
        }
        return true
    }

    private fun connectWebSocket(serverUri: String) {
        webSocketClient = object : WebSocketClient(URI(serverUri)) {
            override fun onOpen(handshakedata: ServerHandshake?) {
                isReconnecting = false
                listener.onConnected()
            }

            override fun onMessage(message: String?) {
                message?.let {
                    listener.onMessageReceived(it)
                    val json = org.json.JSONObject(it)
                    when (json.getString("type")) {
                        "username" -> listener.onUsernameReceived(json.getString("username"))
                        "disconnected" -> listener.onDisconnected(json.getString("message"))
                        "call_accepted" -> partner = json.getString("partner")
                    }
                }
            }

            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                listener.onDisconnected("連接已關閉")
                if (!isReconnecting) {
                    attemptReconnect(serverUri)
                }
            }

            override fun onError(ex: Exception?) {
                listener.onError(ex?.message ?: "未知錯誤")
            }
        }.apply { connect() }
    }

    private fun attemptReconnect(serverUri: String) {
        isReconnecting = true
        GlobalScope.launch(Dispatchers.IO) {
            Thread.sleep(2000) // 等待 2 秒後重連
            connectWebSocket(serverUri)
        }
    }

    fun sendMessage(message: String) {
        webSocketClient?.send(message)
    }

    fun disconnect() {
        isReconnecting = false
        webSocketClient?.close()
    }

    interface VoiceCallListener {
        fun onConnected()
        fun onUsernameReceived(username: String)
        fun onMessageReceived(message: String)
        fun onDisconnected(message: String)
        fun onError(message: String)
    }
}