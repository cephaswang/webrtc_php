package tw.ibiz.yukachat

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var instructionLabel: TextView
    private lateinit var emailEditText: EditText
    private lateinit var submitButton: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("ForgotPasswordActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }


        // Set up action bar
        supportActionBar?.title = "取得密碼"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Initialize UI elements
        instructionLabel = findViewById(R.id.instructionLabel)
        emailEditText = findViewById(R.id.emailEditText)
        submitButton = findViewById(R.id.submitButton)

        // Set up click listener
        submitButton.setOnClickListener {
            submitButtonTapped()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish() // Close this activity and return to previous one
        return true
    }

    private fun submitButtonTapped() {
        val email = emailEditText.text.toString().trim()

        if (email.isEmpty()) {
            showAlert("錯誤", "請輸入 Email")
            return
        }

        // Get xid from SharedPreferences or generate if needed
        val sharedPref = getSharedPreferences("AppPrefs", MODE_PRIVATE)
        val xid = sharedPref.getString("xid", "") ?: ""

        // URL encode the email
        val encodedEmail = URLEncoder.encode(email, "UTF-8")

        // Build the URL
        val apiUrl = "${ConfigIni.SERVER_URL}user/app/api/?mode=forgot_password&email=$encodedEmail&xid=$xid"
        println("API URL: $apiUrl")

        // Create OkHttp client
        val client = OkHttpClient()

        // Create request
        val request = Request.Builder()
            .url(apiUrl)
            .get() // This is a GET request
            .build()

        // Make the API call
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showAlert("連線失敗", e.message ?: "未知錯誤")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                println("Response: $responseBody")

                runOnUiThread {
                    try {
                        val json = JSONObject(responseBody ?: "{}")
                        Log.d("ForgotPasswordActivity",json.toString())

                        if (json.getString("status") == "succ") {
                            val message = json.optString("message", "重設密碼連結已發送至您的 Email")
                            showAlert("成功", message)
                        } else {
                            val errorMessage = json.optString("message", "請求失敗")
                            showAlert("錯誤", errorMessage)
                        }
                    } catch (e: Exception) {
                        showAlert("錯誤", "解析資料失敗: ${e.message}")
                    }
                }
            }
        })
    }

    private fun showAlert(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("確定", null)
            .show()
    }

    // TODO: Implement your API request function
    /*
    private fun sendRequest(urlString: String) {
        // Implement your network request here using Volley, Retrofit, etc.
    }
    */
}