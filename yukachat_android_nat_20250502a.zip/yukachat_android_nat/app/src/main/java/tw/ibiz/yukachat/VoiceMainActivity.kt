package tw.ibiz.yukachat

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class VoiceMainActivity : AppCompatActivity(), VoiceCallClient.VoiceCallListener {
    private val TAG = "VoiceMainActivity"
    private val REQUEST_RECORD_AUDIO_PERMISSION = 1001

    private lateinit var voiceCallClient: VoiceCallClient
    private val serverUri = ConfigIni.WEBSOCKET_VOICE

    // UI Elements
    private lateinit var statusText: TextView
    private lateinit var usernameText: TextView
    private lateinit var onlineUsersRecycler: RecyclerView
    private lateinit var callStatusText: TextView
    private lateinit var callTimeText: TextView
    private lateinit var btnMute: Button
    private lateinit var btnSpeaker: Button

    private var onlineUsers = mutableListOf<VoiceUser>()
    private lateinit var usersAdapter: OnlineUsersAdapter

    // Audio related
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isRecording = false
    private var isMuted = false
    private var isSpeakerOn = false
    private var callStartTime: Long = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var executor: ExecutorService
    private lateinit var audioManager: AudioManager

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voice_main)

        // Initialize AudioManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // Initialize UI
        statusText = findViewById(R.id.status_text)
        usernameText = findViewById(R.id.user_id_text)
        onlineUsersRecycler = findViewById(R.id.online_users_recycler)
        callStatusText = findViewById(R.id.call_status_text)
        callTimeText = findViewById(R.id.call_time_text)
        btnMute = findViewById(R.id.btn_mute)
        btnSpeaker = findViewById(R.id.btn_speaker)

        // Initialize executor for audio tasks
        executor = Executors.newSingleThreadExecutor()

        // Setup RecyclerView
        usersAdapter = OnlineUsersAdapter(onlineUsers) { user ->
            if (!user.inCall) {
                callStatusText.text = "呼叫中..."
                voiceCallClient.sendMessage(JSONObject().apply {
                    put("type", "call_request")
                    put("targetId", user.id)
                }.toString())
            } else {
                Toast.makeText(this, "該用戶正在通話中", Toast.LENGTH_SHORT).show()
            }
        }
        onlineUsersRecycler.layoutManager = LinearLayoutManager(this)
        onlineUsersRecycler.adapter = usersAdapter

        // Button listeners
        findViewById<Button>(R.id.btn_end_call).setOnClickListener {
            endCall()
        }

        btnMute.setOnClickListener {
            isMuted = !isMuted
            btnMute.text = if (isMuted) "取消靜音" else "靜音"
        }

        btnSpeaker.setOnClickListener {
            isSpeakerOn = !isSpeakerOn
            btnSpeaker.text = if (isSpeakerOn) "關閉揚聲器" else "開啟揚聲器"
            audioManager.isSpeakerphoneOn = isSpeakerOn
        }

        // Check and request permissions
        if (checkPermission()) {
            initializeVoiceClient()
            initializeAudioTrack()
            if (audioTrack == null) {
                statusText.text = "無法初始化音頻播放設備"
                return
            }
        }
    }

    private fun initializeVoiceClient() {
        voiceCallClient = VoiceCallClient(this, serverUri, this)
    }

    private fun initializeAudioTrack() {
        val sampleRate = 44100
        val channelConfig = AudioFormat.CHANNEL_OUT_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        if (bufferSize <= 0) {
            Log.e(TAG, "Invalid buffer size returned: $bufferSize. Check sample rate, channel config, and audio format.")
            return // 或設置一個默認值，例如 4096 字節
        }

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .setEncoding(audioFormat)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .build()
    }

    private fun checkPermission(): Boolean {
        return if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_RECORD_AUDIO_PERMISSION
            )
            false
        } else {
            true
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_RECORD_AUDIO_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initializeVoiceClient()
                    initializeAudioTrack()
                } else {
                    statusText.text = "需要錄音權限才能使用語音功能"
                }
            }
        }
    }

    // VoiceCallListener implementations
    override fun onConnected() {
        runOnUiThread {
            statusText.text = "已連接到伺服器"
        }
    }

    override fun onUsernameReceived(username: String) {
        runOnUiThread {
            usernameText.text = "你的名字: $username"
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onMessageReceived(message: String) {
        try {
            val json = JSONObject(message)
            when (json.getString("type")) {
                "online_users" -> handleOnlineUsers(json)
                "incoming_call" -> handleIncomingCall(json)
                "call_waiting" -> updateCallStatus(json.getString("message"))
                "call_accepted" -> handleCallAccepted(json)
                "call_rejected" -> handleCallRejected(json)
                "audio_data" -> handleAudioData(json)
                "disconnected" -> handleDisconnected(json)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing message: ${e.message}")
        }
    }

    private fun handleOnlineUsers(json: JSONObject) {
        val usersArray = json.getJSONArray("users")
        onlineUsers.clear()
        for (i in 0 until usersArray.length()) {
            val user = usersArray.getJSONObject(i)
            onlineUsers.add(VoiceUser(
                user.getInt("id"),
                user.getString("username"),
                user.getBoolean("inCall")
            ))
        }
        runOnUiThread {
            usersAdapter.notifyDataSetChanged()
        }
    }

    private fun handleIncomingCall(json: JSONObject) {
        runOnUiThread {
            showCallDialog(
                json.getString("fromUsername"),
                json.getInt("fromId")
            )
        }
    }

    private fun handleCallAccepted(json: JSONObject) {
        runOnUiThread {
            callStatusText.text = "通話中"
            callStartTime = System.currentTimeMillis()
            startCallTimer()
            startAudioRecording()
            audioTrack?.play()
            Toast.makeText(this, "已連接到 ${json.getString("partner")}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleCallRejected(json: JSONObject) {
        runOnUiThread {
            callStatusText.text = json.getString("message")
        }
    }

    private fun handleAudioData(json: JSONObject) {
        val audioDataBase64 = json.getString("data")
        val audioData = Base64.decode(audioDataBase64, Base64.DEFAULT)
        audioTrack?.write(audioData, 0, audioData.size)
    }

    private fun handleDisconnected(json: JSONObject) {
        runOnUiThread {
            endCall()
            callStatusText.text = json.getString("message")
        }
    }

    private fun updateCallStatus(message: String) {
        runOnUiThread {
            callStatusText.text = message
        }
    }

    private fun showCallDialog(callerName: String, callerId: Int) {
        AlertDialog.Builder(this)
            .setTitle("來電")
            .setMessage("來自 $callerName 的通話請求")
            .setPositiveButton("接聽") { _, _ ->
                voiceCallClient.sendMessage(JSONObject().apply {
                    put("type", "call_response")
                    put("callerId", callerId)
                    put("accepted", true)
                }.toString())
                callStatusText.text = "通話中"
                callStartTime = System.currentTimeMillis()
                startCallTimer()
                startAudioRecording()
                audioTrack?.play()
            }
            .setNegativeButton("拒絕") { _, _ ->
                voiceCallClient.sendMessage(JSONObject().apply {
                    put("type", "call_response")
                    put("callerId", callerId)
                    put("accepted", false)
                }.toString())
                callStatusText.text = "已拒絕通話"
            }
            .setCancelable(false)
            .show()
    }

    private fun startAudioRecording() {
        if (isRecording) return

        val sampleRate = 44100
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        isRecording = true
        executor.execute {
            val buffer = ByteArray(bufferSize)
            audioRecord?.startRecording()

            while (isRecording) {
                if (!isMuted) {
                    val bytesRead = audioRecord?.read(buffer, 0, bufferSize) ?: 0
                    if (bytesRead > 0) {
                        val audioDataBase64 = Base64.encodeToString(buffer.copyOf(bytesRead), Base64.DEFAULT)
                        voiceCallClient.sendMessage(JSONObject().apply {
                            put("type", "audio_data")
                            put("data", audioDataBase64)
                        }.toString())
                    }
                }
            }

            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        }
    }

    private fun stopAudioRecording() {
        isRecording = false
    }

    private fun startCallTimer() {
        handler.removeCallbacks(updateCallTimeRunnable)
        handler.post(updateCallTimeRunnable)
    }

    private val updateCallTimeRunnable = object : Runnable {
        override fun run() {
            val currentTime = System.currentTimeMillis()
            val elapsedTime = currentTime - callStartTime
            val seconds = (elapsedTime / 1000) % 60
            val minutes = (elapsedTime / (1000 * 60)) % 60
            val hours = (elapsedTime / (1000 * 60 * 60)) % 24

            callTimeText.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
            handler.postDelayed(this, 1000)
        }
    }

    private fun endCall() {
        stopAudioRecording()
        audioTrack?.stop()
        handler.removeCallbacks(updateCallTimeRunnable)
        callTimeText.text = "00:00:00"
        callStatusText.text = "通話已結束"

        voiceCallClient.sendMessage(JSONObject().apply {
            put("type", "end_call")
        }.toString())
    }

    override fun onDisconnected(message: String) {
        runOnUiThread {
            endCall()
            statusText.text = message
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            statusText.text = "錯誤: $message"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        endCall()
        audioTrack?.release()
        executor.shutdown()
        voiceCallClient.disconnect()
    }
}

data class VoiceUser(val id: Int, val username: String, val inCall: Boolean)

class OnlineUsersAdapter(
    private val users: List<VoiceUser>,
    private val onUserClick: (VoiceUser) -> Unit
) : RecyclerView.Adapter<OnlineUsersAdapter.UserViewHolder>() {

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val usernameText: TextView = itemView.findViewById(R.id.username_text)
        val statusIndicator: ImageView = itemView.findViewById(R.id.status_indicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = users[position]
        holder.usernameText.text = user.username
        holder.statusIndicator.setImageResource(
            if (user.inCall) R.drawable.ic_busy else R.drawable.ic_available
        )
        holder.itemView.setOnClickListener { onUserClick(user) }

        // 單雙數不同底色
        val backgroundColor = if (position % 2 == 0) {
            // 偶數項（雙數）：淺粉色
            android.graphics.Color.parseColor("#FFE1E9") // 美美的淺粉色
        } else {
            // 奇數項（單數）：淺藍色
            android.graphics.Color.parseColor("#E1F0FF") // 美美的淺藍色
        }
        holder.itemView.setBackgroundColor(backgroundColor)
    }

    override fun getItemCount() = users.size
}