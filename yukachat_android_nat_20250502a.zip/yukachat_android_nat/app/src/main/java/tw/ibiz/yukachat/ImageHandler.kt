package tw.ibiz.yukachat



import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale



class ImageHandler(
    private val activity: AppCompatActivity,
    private val onError: (String, String) -> Unit
) {

    private val httpClient = OkHttpClient.Builder()
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()
    private var tempImageUri: Uri? = null // 臨時儲存拍照的 Uri

    @RequiresApi(Build.VERSION_CODES.O)
    private val takePictureLauncher = activity.registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        tempImageUri?.let { uri ->
            if (success) {
                try {
                    val bitmap = BitmapFactory.decodeStream(activity.contentResolver.openInputStream(uri))
                    uploadImage(bitmap) { imageUrl ->
                        if (!activity.isFinishing && !activity.isDestroyed) {
                            (activity as ChatActivity).chatManager.sendImageMessage(imageUrl)
                        }
                    }
                    updateMediaStore(uri)
                } catch (e: IOException) {
                    LogUtils.logError(activity, "ImageHandler", "無法處理照片", e)
                    onError("錯誤", "無法處理照片：${e.message}")
                }
            } else {
                LogUtils.logError(activity, "ImageHandler", "無法拍攝照片")
                onError("錯誤", "無法拍攝照片")
            }
            tempImageUri = null // 清除臨時 Uri
        } ?: run {
            LogUtils.logError(activity, "ImageHandler", "拍照失敗，無法獲取照片路徑")
            onError("錯誤", "拍照失敗，無法獲取照片路徑")
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private val selectImageLauncher = activity.registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val bitmap = getBitmapFromUri(it)
            bitmap?.let { bmp ->
                uploadImage(bmp) { imageUrl ->
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        (activity as ChatActivity).chatManager.sendImageMessage(imageUrl)
                    }
                }
            } ?: run {
                LogUtils.logError(activity, "ImageHandler", "無法載入圖片")
                onError("錯誤", "無法載入圖片，請確認檔案是否有效")
            }
        } ?: run {
            LogUtils.logError(activity, "ImageHandler", "未選擇圖片")
            onError("錯誤", "未選擇任何圖片")
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun showImagePickerDialog() {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showImageOptions()
        } else {
            activity.requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun handlePermissionResult(requestCode: Int, grantResults: IntArray) {
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showImageOptions()
            } else {
                LogUtils.logError(activity, "ImageHandler", "相機權限被拒絕")
                onError("權限被拒絕", "需要相機權限以使用拍照功能")
                showAlert("權限被拒絕", "請在應用程式設定中開啟相機權限") {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    intent.data = Uri.parse("package:${activity.packageName}")
                    activity.startActivity(intent)
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun showImageOptions() {
        val options = arrayOf("拍照", "選擇圖片")
        AlertDialog.Builder(activity)
            .setTitle("選擇圖片來源")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> takePhoto()
                    1 -> showImagePicker()
                }
            }
            .show()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun takePhoto() {
        try {
            val photoFile = createImageFile()
            tempImageUri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", photoFile)
            tempImageUri?.let { uri ->
                takePictureLauncher.launch(uri)
            } ?: run {
                LogUtils.logError(activity, "ImageHandler", "無法創建照片路徑")
                onError("錯誤", "無法創建照片路徑")
            }
        } catch (ex: IOException) {
            LogUtils.logError(activity, "ImageHandler", "無法建立照片檔案", ex)
            onError("錯誤", "無法建立照片檔案：${ex.message}")
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun showImagePicker() {
        selectImageLauncher.launch("image/*")
    }

    private fun showAlert(title: String, message: String, onPositive: () -> Unit) {
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("確定") { _, _ -> onPositive() }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun uploadImage(bitmap: Bitmap, onSuccess: (String) -> Unit) {
        val cacheFile = File(activity.cacheDir, "upload.jpg")
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos)
        val bitmapData = bos.toByteArray()

        try {
            FileOutputStream(cacheFile).use { fos ->
                fos.write(bitmapData)
                fos.flush()
            }
        } catch (e: IOException) {
            LogUtils.logError(activity, "ImageHandler", "無法寫入緩存檔案", e)
            onError("錯誤", "無法準備圖片檔案：${e.message}")
            return
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", cacheFile.name, cacheFile.asRequestBody("image/jpeg".toMediaTypeOrNull()))
            .build()

        val request = Request.Builder().url("${ConfigIni.SERVER_URL}upload.php").post(requestBody).build()
        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                LogUtils.logError(activity, "ImageHandler", "圖片上傳失敗", e)
                onError("上傳失敗", "無法上傳圖片：${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                if (response.isSuccessful && responseBody != null) {
                    try {
                        val json = JSONObject(responseBody)
                        val imageUrl = json.getString("imageUrl")
                        if (!activity.isFinishing && !activity.isDestroyed) {
                            activity.runOnUiThread { onSuccess(imageUrl) }
                        }
                    } catch (e: Exception) {
                        LogUtils.logError(activity, "ImageHandler", "無法解析伺服器回應", e)
                        onError("解析錯誤", "無法解析伺服器回應：${e.message}")
                    }
                } else {
                    LogUtils.logError(activity, "ImageHandler", "伺服器回應錯誤，代碼：${response.code}")
                    onError("上傳失敗", "伺服器回應錯誤，代碼：${response.code}")
                }
            }
        })
    }

    private fun getBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            BitmapFactory.decodeStream(activity.contentResolver.openInputStream(uri))
        } catch (e: IOException) {
            LogUtils.logError(activity, "ImageHandler", "無法從 URI 載入圖片", e)
            null
        }
    }

    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir = activity.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: activity.cacheDir
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
    }

    private fun updateMediaStore(uri: Uri) {
        val contentValues = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.TITLE, "新照片")
            put(MediaStore.Images.Media.DESCRIPTION, "來自 YukaChat")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/YukaChat")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        try {
            activity.contentResolver.update(uri, contentValues, null, null)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                activity.contentResolver.update(uri, contentValues, null, null)
            }
        } catch (e: Exception) {
            LogUtils.logError(activity, "ImageHandler", "無法更新媒體庫", e)
        }
    }

    companion object {
        const val CAMERA_PERMISSION_CODE = 100
    }
}