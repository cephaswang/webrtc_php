package tw.ibiz.yukachat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI

class VideoCallActivity : AppCompatActivity() {

    private lateinit var currentUsernameTextView: TextView
    private lateinit var onlineUsersRecyclerView: RecyclerView
    private lateinit var statusTextView: TextView
    private lateinit var callButton: Button
    private lateinit var endCallButton: Button
    private lateinit var muteButton: Button
    private lateinit var videoToggleButton: Button

    private var webSocketClient: WebSocketClient? = null
    private var isMuted = false
    private var isVideoEnabled = true
    private var currentUsername = ""
    private var inCall = false
    private val onlineUsers = mutableListOf<VideoUser>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_call)

        // 綁定 UI 元件
        currentUsernameTextView = findViewById(R.id.currentUsernameTextView)
        onlineUsersRecyclerView = findViewById(R.id.onlineUsersRecyclerView)
        statusTextView = findViewById(R.id.statusTextView)
        callButton = findViewById(R.id.callButton)
        endCallButton = findViewById(R.id.endCallButton)
        muteButton = findViewById(R.id.muteButton)
        videoToggleButton = findViewById(R.id.videoToggleButton)

        // 初始化 RecyclerView
        onlineUsersRecyclerView.layoutManager = LinearLayoutManager(this)
        onlineUsersRecyclerView.adapter = VideoUserAdapter(onlineUsers) { user ->
            if (!inCall && !user.inCall) {
                showCallDialog(user)
            } else {
                Toast.makeText(this, "無法通話：您或對方已在通話中", Toast.LENGTH_SHORT).show()
            }
        }

        // 設置按鈕點擊事件
        endCallButton.setOnClickListener { endCall() }
        muteButton.setOnClickListener { toggleMute() }
        videoToggleButton.setOnClickListener { toggleVideo() }

        // 初始化 WebSocket 連接
        connectWebSocket()
    }

    private fun connectWebSocket() {
        val uri = URI( ConfigIni.WEBSOCKET_VIDEO ) // 替換為您的服務器地址
        webSocketClient = object : WebSocketClient(uri) {
            override fun onOpen(handshakedata: ServerHandshake?) {
                runOnUiThread {
                    statusTextView.text = "狀態: 已連接"
                    Toast.makeText(this@VideoCallActivity, "WebSocket 已連接", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onMessage(message: String?) {
                message?.let { handleMessage(it) }
            }

            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                runOnUiThread {
                    statusTextView.text = "狀態: 未連接"
                    inCall = false
                    updateButtonStates()
                }
            }

            override fun onError(ex: Exception?) {
                runOnUiThread {
                    statusTextView.text = "狀態: 錯誤 - ${ex?.message}"
                }
            }
        }
        webSocketClient?.connect()
    }

    private fun handleMessage(message: String) {
        val json = JSONObject(message)
        when (json.getString("type")) {
            "username" -> {
                currentUsername = json.getString("username")
                runOnUiThread {
                    currentUsernameTextView.text = "您的用戶名: $currentUsername"
                }
            }
            "online_users" -> {
                val usersArray = json.getJSONArray("users")
                onlineUsers.clear()
                for (i in 0 until usersArray.length()) {
                    val user = usersArray.getJSONObject(i)
                    onlineUsers.add(
                        VideoUser(
                            user.getInt("id"),
                            user.getString("username"),
                            user.getBoolean("inCall")
                        )
                    )
                }
                runOnUiThread {
                    onlineUsersRecyclerView.adapter?.notifyDataSetChanged()
                }
            }
            "incoming_call" -> {
                runOnUiThread {
                    statusTextView.text = "狀態: 收到來自 ${json.getString("fromUsername")} 的通話請求"
                    showIncomingCallDialog(json.getInt("fromId"))
                }
            }
            "call_accepted" -> {
                runOnUiThread {
                    statusTextView.text = "狀態: 通話已連接 - ${json.getString("partner")}"
                    inCall = true
                    updateButtonStates()
                }
            }
            "call_rejected" -> {
                runOnUiThread {
                    statusTextView.text = "狀態: 通話被拒絕 - ${json.getString("message")}"
                    inCall = false
                    updateButtonStates()
                }
            }
            "disconnected" -> {
                runOnUiThread {
                    statusTextView.text = "狀態: 通話已結束 - ${json.getString("message")}"
                    inCall = false
                    updateButtonStates()
                }
            }
        }
    }

    private fun initiateCall(targetId: String) {
        val message = JSONObject().apply {
            put("type", "call_request")
            put("targetId", targetId)
        }
        webSocketClient?.send(message.toString())
        statusTextView.text = "狀態: 正在等待回應..."
    }

    private fun acceptCall(callerId: Int) {
        val message = JSONObject().apply {
            put("type", "call_response")
            put("callerId", callerId)
            put("accepted", true)
        }
        webSocketClient?.send(message.toString())
    }

    private fun endCall() {
        val message = JSONObject().apply {
            put("type", "end_call")
        }
        webSocketClient?.send(message.toString())
        inCall = false
        updateButtonStates()
    }

    private fun toggleMute() {
        isMuted = !isMuted
        val message = JSONObject().apply {
            put("type", if (isMuted) "mute_mic" else "unmute_mic")
        }
        webSocketClient?.send(message.toString())
        muteButton.text = if (isMuted) "取消靜音" else "靜音"
    }

    private fun toggleVideo() {
        isVideoEnabled = !isVideoEnabled
        val message = JSONObject().apply {
            put("type", if (isVideoEnabled) "enable_video" else "disable_video")
        }
        webSocketClient?.send(message.toString())
        videoToggleButton.text = if (isVideoEnabled) "關閉視訊" else "開啟視訊"
    }

    private fun updateButtonStates() {
        endCallButton.isEnabled = inCall
    }

    private fun showCallDialog(user: VideoUser) {
        AlertDialog.Builder(this)
            .setTitle("通話請求")
            .setMessage("是否要與 ${user.username} 通話？")
            .setPositiveButton("是") { _, _ ->
                initiateCall(user.id.toString())
            }
            .setNegativeButton("否", null)
            .show()
    }

    private fun showIncomingCallDialog(fromId: Int) {
        AlertDialog.Builder(this)
            .setTitle("來電")
            .setMessage("來自 ${onlineUsers.find { it.id == fromId }?.username} 的通話請求")
            .setPositiveButton("接受") { _, _ ->
                acceptCall(fromId)
            }
            .setNegativeButton("拒絕") { _, _ ->
                val message = JSONObject().apply {
                    put("type", "call_response")
                    put("callerId", fromId)
                    put("accepted", false)
                }
                webSocketClient?.send(message.toString())
            }
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketClient?.close()
    }
}

// 修改後的數據類
data class VideoUser(val id: Int, val username: String, val inCall: Boolean)

// RecyclerView 適配器
class VideoUserAdapter(
    private val users: List<VideoUser>,
    private val onUserClick: (VideoUser) -> Unit
) : RecyclerView.Adapter<VideoUserAdapter.VideoUserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoUserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false)
        return VideoUserViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoUserViewHolder, position: Int) {
        val user = users[position]
        holder.bind(user)
        // 設置單雙列不同底色
        holder.itemView.setBackgroundColor(
            if (position % 2 == 0) 0xFFE6F0FA.toInt() else 0xFFF5E6FA.toInt() // 偶數淺藍，奇數淺紫
        )
        holder.itemView.setOnClickListener { onUserClick(user) }
    }

    override fun getItemCount(): Int = users.size

    class VideoUserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val userIdTextView: TextView = itemView.findViewById(R.id.userIdTextView)
        private val usernameTextView: TextView = itemView.findViewById(R.id.usernameTextView)
        private val statusTextView: TextView = itemView.findViewById(R.id.statusTextView)

        fun bind(user: VideoUser) {
            userIdTextView.text = user.id.toString()
            usernameTextView.text = user.username
            statusTextView.text = if (user.inCall) "通話中" else "空閒"
        }
    }
}