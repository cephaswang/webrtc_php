package tw.ibiz.yukachat

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLDecoder
import java.net.URLEncoder

class ProfileActivity : AppCompatActivity() {

    private lateinit var profileImage: ImageView
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var saveButton: TextView
    private var selectedImageUri: Uri? = null
    private lateinit var Xid: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        try {
            LogUtils.logDebug(this, "ProfileActivity", "Activity started")

            val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            Xid = sharedPref.getString("xid", "") ?: ""

            profileImage = findViewById(R.id.profile_image)
            nameEditText = findViewById(R.id.name_edit_text)
            emailEditText = findViewById(R.id.email_edit_text)
            saveButton = findViewById(R.id.save_button)
            val deleteAccountButton: TextView = findViewById(R.id.delete_account_button)

            deleteAccountButton.setOnClickListener {
                try {
                    showDeleteAccountDialog()
                } catch (e: Exception) {
                    LogUtils.logError(this, "ProfileActivity", "Error in delete account button click", e)
                }
            }

            apiLoaderDetail(nameEditText, emailEditText, this)

            val backButton: ImageView = findViewById(R.id.backButton)
            backButton.setOnClickListener {
                try {
                    finish()
                } catch (e: Exception) {
                    LogUtils.logError(this, "ProfileActivity", "Error in back button click", e)
                }
            }

            profileImage.setOnClickListener {
                try {
                    showImagePickerOptions()
                } catch (e: Exception) {
                    LogUtils.logError(this, "ProfileActivity", "Error in profile image click", e)
                }
            }

            saveButton.setOnClickListener {
                try {
                    handleSaveButtonClick()
                } catch (e: Exception) {
                    LogUtils.logError(this, "ProfileActivity", "Error in save button click", e)
                }
            }

        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error in onCreate", e)
            showErrorDialog("初始化失敗，請重試")
        }
    }

    private fun handleSaveButtonClick() {
        val name = nameEditText.text.toString()
        val email = emailEditText.text.toString()

        if (name.isEmpty() || email.isEmpty()) {
            showErrorDialog("請填寫所有欄位")
            return
        }

        try {
            val encodedName = URLEncoder.encode(name, "UTF-8")
            val encodedEmail = URLEncoder.encode(email, "UTF-8")
            val url = "${ConfigIni.SERVER_URL}user/app/api/?mode=update&name=$encodedName&email=$encodedEmail&xid=$Xid"

            Log.d("url",url)
            val client = OkHttpClient()
            val request = Request.Builder().url(url).build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    LogUtils.logError(this@ProfileActivity, "ProfileActivity", "Network request failed", e)
                    runOnUiThread {
                        showErrorDialog("網絡錯誤: ${e.message ?: "未知錯誤"}")
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        if (!response.isSuccessful) {
                            throw IOException("Unexpected code $response")
                        }

                        val jsonString = response.body?.string() ?: throw IOException("Empty response")

                        Log.d("jsonString",jsonString)

                        val jsonObject = JSONObject(jsonString)
                        val status = jsonObject.getString("status")
                        val title = jsonObject.getString("title")
                        val message = jsonObject.getString("message")

                        runOnUiThread {
                            showAlertDialog(title, message)
                        }

                    } catch (e: Exception) {
                        LogUtils.logError(this@ProfileActivity, "ProfileActivity", "Error processing API response", e)
                        runOnUiThread {
                            showErrorDialog("處理回應時發生錯誤")
                        }
                    }
                }
            })
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error in save operation", e)
            showErrorDialog("保存時發生錯誤")
        }
    }

    private fun showDeleteAccountDialog() {
        try {
            AlertDialog.Builder(this).apply {
                setCustomTitle(
                    TextView(this@ProfileActivity).apply {
                        text = "警告"
                        setTextColor(Color.BLACK)
                        textSize = 26.0f
                        setPadding(32, 32, 32, 16)
                        setBackgroundColor(Color.RED)
                        gravity = Gravity.CENTER
                    }
                )
                setMessage("您確定要刪除帳號嗎？此操作無法撤銷。")
                setPositiveButton("是的") { _, _ ->
                    try {
                        deleteAccountFromServer()
                    } catch (e: Exception) {
                        LogUtils.logError(this@ProfileActivity, "ProfileActivity", "Error in delete account confirmation", e)
                    }
                }
                setNegativeButton("取消", null)
                setCancelable(false)
                create().apply {
                    window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)
                    show()
                    customizeDialogAppearance()
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error showing delete account dialog", e)
            throw e
        }
    }

    private fun deleteAccountFromServer() {
        try {
            val url = "${ConfigIni.SERVER_URL}user/app/api/?mode=delete&xid=$Xid"

            Log.d("url",url)

            val client = OkHttpClient()
            val request = Request.Builder().url(url).build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    LogUtils.logError(this@ProfileActivity, "ProfileActivity", "Delete account network error", e)
                    runOnUiThread {
                        showErrorDialog("網絡錯誤: ${e.message ?: "未知錯誤"}")
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        if (!response.isSuccessful) {
                            throw IOException("Unexpected code $response")
                        }

                        val jsonString = response.body?.string() ?: throw IOException("Empty response")

                        Log.d("jsonString",jsonString)
                        val jsonObject = JSONObject(jsonString)
                        val status = jsonObject.getString("status")
                        val message = jsonObject.getString("message")

                        runOnUiThread {
                            if (status == "succ") {
                                showAlertDialog("成功", message) { finish() }
                            } else {
                                showErrorDialog(message)
                            }
                        }
                    } catch (e: Exception) {
                        LogUtils.logError(this@ProfileActivity, "ProfileActivity", "Error processing delete response", e)
                        runOnUiThread {
                            showErrorDialog("處理回應時發生錯誤")
                        }
                    }
                }
            })
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error in delete account operation", e)
            showErrorDialog("刪除帳號時發生錯誤")
        }
    }

    private fun apiLoaderDetail(nameEditText: EditText, emailEditText: EditText, context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val apiUrl = "${ConfigIni.SERVER_URL}user/app/api/?mode=detail&xid=$Xid"
                val client = OkHttpClient()
                val request = Request.Builder().url(apiUrl).build()
                val response = client.newCall(request).execute()

                if (!response.isSuccessful) {
                    throw IOException("Unexpected code $response")
                }

                val responseBody = response.body?.string() ?: throw IOException("Empty response")
                val jsonObject = JSONObject(responseBody)
                val status = jsonObject.getString("status")

                if (status != "succ") {
                    throw IOException("API returned status: $status")
                }

                val dataObject = jsonObject.getJSONObject("data")
                val name = URLDecoder.decode(dataObject.getString("name"), "UTF-8")
                val email = dataObject.getString("email")

                withContext(Dispatchers.Main) {
                    nameEditText.setText(name)
                    emailEditText.setText(email)
                }
            } catch (e: Exception) {
                LogUtils.logError(context, "ProfileActivity", "Error loading profile details", e)
                withContext(Dispatchers.Main) {
                    showErrorDialog("加載資料時發生錯誤")
                }
            }
        }
    }

    private fun showImagePickerOptions() {
        try {
            val options = arrayOf("圖片檔", "拍照")
            AlertDialog.Builder(this).apply {
                setTitle("請選擇")
                setItems(options) { _, which ->
                    try {
                        when (which) {
                            0 -> pickImageFromGallery()
                            1 -> takePhoto()
                        }
                    } catch (e: Exception) {
                        LogUtils.logError(this@ProfileActivity, "ProfileActivity", "Error in image picker selection", e)
                    }
                }
                show()
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error showing image picker options", e)
        }
    }

    private fun pickImageFromGallery() {
        try {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            galleryLauncher.launch(intent)
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error picking image from gallery", e)
        }
    }

    private fun takePhoto() {
        try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            photoLauncher.launch(intent)
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error taking photo", e)
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        try {
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.data?.let { uri ->
                    selectedImageUri = uri
                    profileImage.setImageURI(uri)
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error in gallery result", e)
        }
    }

    private val photoLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        try {
            if (result.resultCode == Activity.RESULT_OK) {
                val imageUri = result.data?.data
                if (imageUri != null) {
                    contentResolver.openInputStream(imageUri)?.use { inputStream ->
                        val imageBitmap = BitmapFactory.decodeStream(inputStream)
                        profileImage.setImageBitmap(imageBitmap)
                        selectedImageUri = saveImageToCache(imageBitmap)
                    }
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error in photo result", e)
        }
    }

    private fun saveImageToCache(bitmap: android.graphics.Bitmap): Uri? {
        return try {
            val file = File(cacheDir, "profile_image.jpg")
            file.outputStream().use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 100, out)
            }
            Uri.fromFile(file)
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error saving image to cache", e)
            null
        }
    }

    private fun showAlertDialog(title: String, message: String, onDismiss: (() -> Unit)? = null) {
        try {
            AlertDialog.Builder(this).apply {
                setMessage(title)
                setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    onDismiss?.invoke()
                }
                create().apply {
                    window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)
                    show()
                    customizeDialogAppearance()
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error showing alert dialog", e)
        }
    }

    private fun showErrorDialog(message: String) {
        try {
            AlertDialog.Builder(this).apply {
                setTitle("錯誤")
                setMessage(message)
                setPositiveButton("OK", null)
                create().apply {
                    window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)
                    show()
                    customizeDialogAppearance()
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ProfileActivity", "Error showing error dialog", e)
        }
    }

    private fun AlertDialog.customizeDialogAppearance() {
        findViewById<TextView>(android.R.id.message)?.apply {
            setTextColor(Color.BLACK)
            textSize = 26.0f
        }
        getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
            setTextColor(ContextCompat.getColor(this@ProfileActivity, R.color.fr_yuka))
            textSize = 20.0f
        }
        getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            setTextColor(ContextCompat.getColor(this@ProfileActivity, R.color.fr_yuka))
            textSize = 20.0f
        }
    }
}