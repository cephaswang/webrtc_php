package tw.ibiz.yukachat

import android.os.Build
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.messages.MessageHolders
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import java.text.SimpleDateFormat
import java.util.Locale

class ChatActivity : AppCompatActivity() {
    private lateinit var messagesList: MessagesList
    lateinit var messagesAdapter: MessagesListAdapter<ChatMessage>
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var imageButton: ImageButton
    private lateinit var tvTitle: TextView

    private lateinit var userId: String
    private var targetXid = ""
    private var targetName = ""

    lateinit var chatManager: ChatManager
    private lateinit var imageHandler: ImageHandler

    private var currentDialog: AlertDialog? = null // 用於追蹤當前的對話框

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_chat)

            val sharedPref = getSharedPreferences("AppPrefs", MODE_PRIVATE)
            userId = sharedPref.getString("xid", "") ?: ""
            targetXid = intent.getStringExtra("targetXid").orEmpty()
            targetName = intent.getStringExtra("targetName").orEmpty()

            initUI()
            setupMessagesAdapter()

            chatManager = ChatManager(this, userId, targetXid, messagesAdapter) { title, message ->
                LogUtils.logError(this, "ChatManager", "Error: $title - $message")
                showAlert(title, message)
            }
            imageHandler = ImageHandler(this) { title, message ->
                LogUtils.logError(this, "ImageHandler", "Error: $title - $message")
                showAlert(title, message)
            }

            setupEventListeners()
            chatManager.fetchMessages()
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error in onCreate", e)
            showAlert("錯誤", "初始化聊天室失敗") {
                finish()
            }
        }
    }

    private fun initUI() {
        try {
            tvTitle = findViewById(R.id.tvTitle)
            tvTitle.text = targetName
            messagesList = findViewById(R.id.messagesList)
            messageInput = findViewById(R.id.messageInput)
            sendButton = findViewById(R.id.sendButton)
            imageButton = findViewById(R.id.imageButton)

            findViewById<ImageView>(R.id.backButton).setOnClickListener { finish() }
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error initializing UI", e)
            throw e
        }
    }

    private fun setupMessagesAdapter() {
        try {
            val imageLoader = ImageLoader { imageView, url, _ ->
                try {
                    if (!url.isNullOrEmpty()) {
                        Picasso.get().load(url).placeholder(R.drawable.default_avatar).into(imageView)
                    } else {
                        imageView.setImageResource(R.drawable.default_avatar)
                    }
                } catch (e: Exception) {
                    LogUtils.logError(this, "ChatActivity", "Error loading image", e)
                    imageView.setImageResource(R.drawable.default_avatar)
                }
            }

            val holders = MessageHolders().apply {
                setIncomingTextConfig(CustomIncomingTextMessageViewHolder::class.java, R.layout.item_custom_incoming_text_message)
                setOutcomingTextConfig(CustomOutcomingTextMessageViewHolder::class.java, R.layout.item_custom_outcoming_text_message)
                setIncomingImageConfig(CustomIncomingImageMessageViewHolder::class.java, R.layout.item_custom_incoming_image_message)
                setOutcomingImageConfig(CustomOutcomingImageMessageViewHolder::class.java, R.layout.item_custom_outcoming_image_message)
            }

            messagesAdapter = MessagesListAdapter(userId, holders, imageLoader)
            messagesAdapter.setDateHeadersFormatter { date ->
                SimpleDateFormat(
                    "yyyy-MM-dd",
                    Locale.getDefault()
                ).format(date)
            }
            messagesList.setAdapter(messagesAdapter)
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error setting up messages adapter", e)
            throw e
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setupEventListeners() {
        try {
            sendButton.setOnClickListener {
                try {
                    val text = messageInput.text.toString().trim()
                    if (text.isNotEmpty()) {
                        chatManager.sendTextMessage(text)
                        messageInput.setText("")
                    }
                } catch (e: Exception) {
                    LogUtils.logError(this, "ChatActivity", "Error sending message", e)
                    showAlert("錯誤", "發送訊息失敗")
                }
            }

            imageButton.setOnClickListener {
                try {
                    imageHandler.showImagePickerDialog()
                } catch (e: Exception) {
                    LogUtils.logError(this, "ChatActivity", "Error opening image picker", e)
                    showAlert("錯誤", "無法開啟圖片選擇器")
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error setting up event listeners", e)
            throw e
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        try {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            imageHandler.handlePermissionResult(requestCode, grantResults)
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error handling permission result", e)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onDestroy() {
        try {
            super.onDestroy()
            chatManager.cleanup()
            // 確保在 Activity 銷毀時關閉對話框
            currentDialog?.dismiss()
            currentDialog = null
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error in onDestroy", e)
        }
    }


    fun showAlert(title: String, message: String, onDismiss: (() -> Unit)? = null) {
        try {
            if (isFinishing || isDestroyed) return

            // 檢查是否有對話框正在顯示，若有則不重新生成
            if (currentDialog?.isShowing == true) return

            // 如果已有對話框存在，先銷毀它
            currentDialog?.dismiss()
            currentDialog = null

            runOnUiThread {
                val dialog = AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(message)
                    .setPositiveButton("確定") { _, _ ->
                        onDismiss?.invoke()
                    }
                    .setCancelable(true)
                    .create()

                // 將當前對話框賦值給 currentDialog
                currentDialog = dialog
                dialog.show()
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ChatActivity", "Error showing alert", e)
        }
    }

}