package tw.ibiz.yukachat

import com.stfalcon.chatkit.commons.models.IMessage
import java.util.Date

data class Message(
    private val id: String,
    private val user: User,
    private val text: String?,
    private val imageUrl: String?,
    private val createdAt: Date
) : IMessage {
    override fun getId() = id
    override fun getUser() = user
    override fun getText() = text
    override fun getCreatedAt() = createdAt

    fun getImage(): Image? {
        return imageUrl?.let { Image(it) }
    }

    data class Image(val url: String)
}
