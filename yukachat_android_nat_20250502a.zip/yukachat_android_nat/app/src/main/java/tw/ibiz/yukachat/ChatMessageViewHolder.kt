package tw.ibiz.yukachat

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import com.stfalcon.chatkit.messages.MessageHolders
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URLDecoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

// 自定義接收文本消息的 ViewHolder
class CustomIncomingTextMessageViewHolder(itemView: View) :
    MessageHolders.IncomingTextMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val avatarView: CircleImageView? = itemView.findViewById(R.id.messageUserAvatar)
    private val messageTextView: TextView? = itemView.findViewById(R.id.messageText)

    init {
        if (timeView == null) LogUtils.logError(itemView.context, "ViewHolder", "timeView 未找到")
        if (avatarView == null) LogUtils.logError(itemView.context, "ViewHolder", "avatarView 未找到")
        if (messageTextView == null) LogUtils.logError(itemView.context, "ViewHolder", "messageTextView 未找到")
    }

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK)
        }
        avatarView?.let {
            val avatarUrl = message.getUser().getAvatar()
            if (!avatarUrl.isNullOrEmpty() && avatarUrl.startsWith("http")) {
                imageLoader?.loadImage(it, avatarUrl, null)
            } else {
                it.setImageResource(R.drawable.default_avatar)
            }
        }
        messageTextView?.let {
            val text = message.getText() ?: ""
            it.text = URLDecoder.decode(text)
            it.setTextColor(android.graphics.Color.WHITE)
        }
    }
}

// 自定義發送文本消息的 ViewHolder
class CustomOutcomingTextMessageViewHolder(itemView: View) :
    MessageHolders.OutcomingTextMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val messageTextView: TextView? = itemView.findViewById(R.id.messageText)

    init {
        if (timeView == null) LogUtils.logError(itemView.context, "ViewHolder", "timeView 未找到")
        if (messageTextView == null) LogUtils.logError(itemView.context, "ViewHolder", "messageTextView 未找到")
    }

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK)
        }
        messageTextView?.let {
            val text = message.getText() ?: ""
            it.text = URLDecoder.decode(text)
            it.setTextColor(android.graphics.Color.WHITE)
        }
    }
}

fun getThumbnailFileName(imageUrl: String): String {
    val md5 = MessageDigest.getInstance("MD5")
    val bytes = md5.digest(imageUrl.toByteArray())
    return bytes.joinToString("") { "%02x".format(it) } + "_thumb.jpg"
}

fun getThumbnailFile(context: Context, imageUrl: String): File {
    val fileName = getThumbnailFileName(imageUrl)
    return File(context.cacheDir, fileName)
}

class CustomIncomingImageMessageViewHolder(itemView: View) :
    MessageHolders.IncomingImageMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val avatarView: CircleImageView? = itemView.findViewById(R.id.messageUserAvatar)
    private val imageView: ImageView? = itemView.findViewById(R.id.image)

    init {
        if (timeView == null) LogUtils.logError(itemView.context, "ViewHolder", "timeView 未找到")
        if (avatarView == null) LogUtils.logError(itemView.context, "ViewHolder", "avatarView 未找到")
        if (imageView == null) LogUtils.logError(itemView.context, "ViewHolder", "imageView 未找到")
    }

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK)
        }
        avatarView?.let {
            val avatarUrl = message.getUser().getAvatar()
            if (!avatarUrl.isNullOrEmpty() && avatarUrl.startsWith("http")) {
                imageLoader?.loadImage(it, avatarUrl, null)
            } else {
                it.setImageResource(R.drawable.default_avatar)
            }
        }

        imageView?.let { imgView ->
            val imageUrl = message.getImageUrl()
            if (imageUrl.isNullOrEmpty() || !imageUrl.startsWith("http")) {
                imgView.setImageResource(R.drawable.default_avatar)
                return@let
            }

            val thumbnailFile = getThumbnailFile(itemView.context, imageUrl)
            if (thumbnailFile.exists()) {
                Picasso.get().load(thumbnailFile).into(imgView)
            } else {
                Picasso.get().load(imageUrl).into(imgView, object : com.squareup.picasso.Callback {
                    override fun onSuccess() {
                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                generateAndSaveThumbnail(itemView.context, imageUrl, imgView)
                            } catch (e: Exception) {
                                LogUtils.logError(itemView.context, "ChatActivity", "生成縮略圖失敗", e)
                            }
                        }
                    }

                    override fun onError(e: Exception?) {
                        LogUtils.logError(itemView.context, "ChatActivity", "圖片加載失敗", e)
                        imgView.setImageResource(R.drawable.default_avatar)
                    }
                })
            }

            imgView.setOnClickListener {
                showFullImage(itemView.context, imageUrl)
            }
        }
    }

    private fun showFullImage(context: Context, imageUrl: String?) {
        val intent = Intent(context, FullImageActivity::class.java)
        intent.putExtra("imageUrl", imageUrl)
        context.startActivity(intent)
    }
}

private suspend fun generateAndSaveThumbnail(context: Context, imageUrl: String, imageView: ImageView) {
    try {
        val drawable = imageView.drawable as? BitmapDrawable
        if (drawable == null || drawable.bitmap == null) {
            throw IllegalStateException("無法從 ImageView 獲取 Bitmap")
        }
        val bitmap = drawable.bitmap

        val thumbnail = Bitmap.createScaledBitmap(bitmap, 200, 200, true)
        val thumbnailFile = getThumbnailFile(context, imageUrl)
        withContext(Dispatchers.IO) {
            FileOutputStream(thumbnailFile).use { out ->
                thumbnail.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
        }
        thumbnail.recycle()

        withContext(Dispatchers.Main) {
            if (imageView.isAttachedToWindow) {
                Picasso.get().load(thumbnailFile).into(imageView)
            }
        }
    } catch (e: Exception) {
        LogUtils.logError(context, "ChatActivity", "生成縮略圖失敗", e)
        throw e // 重新拋出異常以便上層處理
    }
}

class CustomOutcomingImageMessageViewHolder(itemView: View) :
    MessageHolders.OutcomingImageMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val imageView: ImageView? = itemView.findViewById(R.id.image)

    init {
        if (timeView == null) LogUtils.logError(itemView.context, "ViewHolder", "timeView 未找到")
        if (imageView == null) LogUtils.logError(itemView.context, "ViewHolder", "imageView 未找到")
    }

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK)
        }

        imageView?.let {
            it.setOnClickListener {
                showFullImage(itemView.context, message.getImageUrl())
            }
        }
    }

    private fun showFullImage(context: Context, imageUrl: String?) {
        val intent = Intent(context, FullImageActivity::class.java)
        intent.putExtra("imageUrl", imageUrl)
        context.startActivity(intent)
    }
}