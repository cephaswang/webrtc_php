package tw.ibiz.yukachat

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class LauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)

        val userAButton = findViewById<Button>(R.id.btn_user_a)
        val userBButton = findViewById<Button>(R.id.btn_user_b)

        userAButton.setOnClickListener {
            startMainActivity("User A")
        }

        userBButton.setOnClickListener {
            startMainActivity("User B")
        }
    }

    private fun startMainActivity(userId: String) {
        val intent = Intent(this, VoiceMainActivity::class.java)
        intent.putExtra("USER_ID", userId)
        startActivity(intent)
    }
}