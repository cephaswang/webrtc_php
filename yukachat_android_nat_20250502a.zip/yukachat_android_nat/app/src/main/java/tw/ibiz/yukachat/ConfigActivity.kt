package tw.ibiz.yukachat

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

class ConfigActivity : AppCompatActivity() {

    private lateinit var languageLabel: TextView
    private lateinit var languageField: TextView
    private lateinit var translateLabel: TextView
    private lateinit var translateField: TextView
    private lateinit var submitButton: Button

    private val languageDic = mapOf(
        "tw" to "繁體中文",
        "en" to "英文",
        "cn" to "簡體中文",
        "" to ""
    )

    private val translateDic = mapOf(
        "0" to "否",
        "1" to "是",
        "" to ""
    )

    private var xid: String = ""
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_config)

            val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            xid = sharedPref.getString("xid", "") ?: ""

            title = "翻譯設定"

            val backButton: ImageView = findViewById(R.id.backButton)
            backButton.setOnClickListener {
                finish()
            }

            supportActionBar?.setDisplayHomeAsUpEnabled(true)

            initViews()
            setupListeners()
            loadSettingsFromAPI()
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in onCreate", e)
            throw e
        }
    }

    private fun initViews() {
        try {
            languageLabel = findViewById(R.id.languageLabel)
            languageField = findViewById(R.id.languageField)
            translateLabel = findViewById(R.id.translateLabel)
            translateField = findViewById(R.id.translateField)
            submitButton = findViewById(R.id.submitButton)

            languageField.setText("  繁體中文")
            translateField.setText("  否")
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in initViews", e)
            throw e
        }
    }

    private fun setupListeners() {
        try {
            languageField.setOnClickListener { selectLanguage() }
            translateField.setOnClickListener { selectTranslation() }
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in setupListeners", e)
            throw e
        }
    }

    @SuppressLint("SetTextI18n")
    private fun selectLanguage() {
        try {
            showSelectionDialog("選擇語言", languageDic.values.toList()) { selected ->
                try {
                    if (selected.isEmpty()) return@showSelectionDialog

                    languageField.setText("  $selected")
                    val languageKey = languageDic.entries.firstOrNull { it.value == selected }?.key ?: "tw"
                    val translateKey = translateDic.entries.firstOrNull {
                        it.value == translateField.text.toString().trim()
                    }?.key ?: "0"

                    val apiUrl =
                        "${ConfigIni.SERVER_URL}user/app/api/?mode=setting_update&language=$languageKey&translate=$translateKey&xid=$xid"

                    val request = Request.Builder()
                        .url(apiUrl)
                        .build()

                    client.newCall(request).enqueue(object : Callback {
                        @SuppressLint("ShowToast")
                        override fun onFailure(call: Call, e: IOException) {
                            LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Language API request failed", e)
                            runOnUiThread {
                                showAlert("錯誤", "網絡錯誤：${e.message}")
                            }
                        }

                        override fun onResponse(call: Call, response: Response) {
                            try {
                                response.body?.string()?.let { responseBody ->
                                    try {
                                        val json = JSONObject(responseBody)
                                        val status = json.getString("status")
                                        val message = json.optString(
                                            "title",
                                            if (status == "succ") "語言設置更新成功" else "語言設置更新失敗"
                                        )
                                        runOnUiThread {
                                            if (status == "succ") {
                                                showAlert("成功", message)
                                            } else {
                                                showAlert("錯誤", message)
                                            }
                                        }
                                    } catch (e: Exception) {
                                        LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Failed to parse Language API response", e)
                                        runOnUiThread {
                                            showAlert("錯誤", "解析回應失敗")
                                        }
                                    }
                                } ?: run {
                                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Language API response body is null")
                                    runOnUiThread {
                                        showAlert("錯誤", "無回應內容")
                                    }
                                }
                            } catch (e: Exception) {
                                LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error processing Language API response", e)
                                runOnUiThread {
                                    showAlert("錯誤", "處理回應時發生錯誤")
                                }
                            }
                        }
                    })
                } catch (e: Exception) {
                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error in selectLanguage callback", e)
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in selectLanguage", e)
            throw e
        }
    }

    @SuppressLint("SetTextI18n")
    private fun selectTranslation() {
        try {
            showSelectionDialog("自動翻譯", translateDic.values.toList()) { selected ->
                try {
                    translateField.setText("  $selected")
                    val translateKey = translateDic.entries.firstOrNull { it.value == selected }?.key ?: "0"
                    val languageKey = languageDic.entries.firstOrNull {
                        it.value == languageField.text.toString().trim()
                    }?.key ?: "tw"

                    val apiUrl =
                        "${ConfigIni.SERVER_URL}user/app/api/?mode=setting_update&language=$languageKey&translate=$translateKey&xid=$xid"

                    val request = Request.Builder()
                        .url(apiUrl)
                        .build()

                    client.newCall(request).enqueue(object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                            LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Translation API request failed", e)
                            runOnUiThread {
                                showAlert("錯誤", "網絡錯誤：${e.message}")
                            }
                        }

                        override fun onResponse(call: Call, response: Response) {
                            try {
                                response.body?.string()?.let { responseBody ->
                                    try {
                                        val json = JSONObject(responseBody)
                                        val status = json.getString("status")
                                        val message = json.optString(
                                            "title",
                                            if (status == "succ") "翻譯設置更新成功" else "翻譯設置更新失敗"
                                        )
                                        runOnUiThread {
                                            if (status == "succ") {
                                                showAlert("成功", message)
                                            } else {
                                                showAlert("錯誤", message)
                                            }
                                        }
                                    } catch (e: Exception) {
                                        LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Failed to parse Translation API response", e)
                                        runOnUiThread {
                                            showAlert("錯誤", "解析回應失敗")
                                        }
                                    }
                                } ?: run {
                                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Translation API response body is null")
                                    runOnUiThread {
                                        showAlert("錯誤", "無回應內容")
                                    }
                                }
                            } catch (e: Exception) {
                                LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error processing Translation API response", e)
                                runOnUiThread {
                                    showAlert("錯誤", "處理回應時發生錯誤")
                                }
                            }
                        }
                    })
                } catch (e: Exception) {
                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error in selectTranslation callback", e)
                }
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in selectTranslation", e)
            throw e
        }
    }

    private fun loadSettingsFromAPI() {
        try {
            val url = "${ConfigIni.SERVER_URL}app/api/?mode=setting&xid=$xid"

            val request = Request.Builder()
                .url(url)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Failed to load settings", e)
                    setDefaultSettings()
                }

                @SuppressLint("SetTextI18n")
                override fun onResponse(call: Call, response: Response) {
                    try {
                        response.body?.string()?.let { responseBody ->
                            try {
                                val json = JSONObject(responseBody)

                                if (json.getString("status") == "succ") {
                                    val data = json.getJSONObject("data")

                                    val languageKey = data.getString("language")
                                    val translateKey = data.getString("translate")

                                    runOnUiThread {
                                        languageField.setText("  ${languageDic[languageKey] ?: languageDic["tw"]}")
                                        translateField.setText("  ${translateDic[translateKey] ?: translateDic["0"]}")
                                    }
                                } else {
                                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "API returned error status")
                                    setDefaultSettings()
                                }
                            } catch (e: Exception) {
                                LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Failed to parse settings response", e)
                                setDefaultSettings()
                            }
                        } ?: run {
                            LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Settings API response body is null")
                            setDefaultSettings()
                        }
                    } catch (e: Exception) {
                        LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error processing settings response", e)
                        setDefaultSettings()
                    }
                }
            })
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in loadSettingsFromAPI", e)
            setDefaultSettings()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setDefaultSettings() {
        try {
            runOnUiThread {
                languageField.setText("  ${languageDic["tw"]}")
                translateField.setText("  ${translateDic["0"]}")
            }
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in setDefaultSettings", e)
        }
    }

    private fun updateSettings(
        language: String,
        translate: String,
        xid: String,
        callback: (Boolean, String?) -> Unit
    ) {
        try {
            val url =
                "${ConfigIni.SERVER_URL}user/app/api/?mode=setting_update&language=$language&translate=$translate&xid=$xid"

            val request = Request.Builder()
                .url(url)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Failed to update settings", e)
                    callback(false, "Network error: ${e.message}")
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        response.body?.string()?.let { responseBody ->
                            try {
                                val json = JSONObject(responseBody)
                                if (json.getString("status") == "succ") {
                                    val title = json.optString("title", "Settings updated successfully")
                                    callback(true, title)
                                } else {
                                    val title = json.optString("title", "Update failed")
                                    callback(false, title)
                                }
                            } catch (e: Exception) {
                                LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Failed to parse update response", e)
                                callback(false, "Failed to parse response")
                            }
                        } ?: run {
                            LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Update API response body is null")
                            callback(false, "No response body")
                        }
                    } catch (e: Exception) {
                        LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error processing update response", e)
                        callback(false, "Error processing response")
                    }
                }
            })
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in updateSettings", e)
            callback(false, "Error in updateSettings: ${e.message}")
        }
    }

    @SuppressLint("ResourceAsColor")
    private fun showSelectionDialog(
        title: String,
        options: List<String>,
        callback: (String) -> Unit
    ) {
        try {
            val customTitle = TextView(this).apply {
                text = title
                setTextColor(Color.BLACK)
                textSize = 20f
                setPadding(32, 32, 32, 16)
                typeface = Typeface.DEFAULT_BOLD
            }

            val dialog = AlertDialog.Builder(this)
                .setItems(options.toTypedArray()) { _, which ->
                    try {
                        val selectedOption = options[which]
                        if (selectedOption.isNotEmpty()) {
                            callback(selectedOption)
                        }
                    } catch (e: Exception) {
                        LogUtils.logError(this@ConfigActivity, "ConfigActivity", "Error in dialog selection", e)
                    }
                }
                .setNegativeButton("Done") { dialog, _ ->
                    dialog.dismiss()
                }
                .create()
                .apply {
                    window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)

                    listView?.apply {
                        divider = ColorDrawable(Color.parseColor("#EEEEEE"))
                        dividerHeight = 6

                        setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                            override fun onChildViewAdded(parent: View?, child: View?) {
                                if (child is TextView) {
                                    child.setTextColor(Color.BLACK)
                                }
                            }
                            override fun onChildViewRemoved(parent: View?, child: View?) {}
                        })
                    }
                }

            dialog.show()
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in showSelectionDialog", e)
            throw e
        }
    }

    @SuppressLint("ShowToast")
    private fun showAlert(title: String, message: String) {
        try {
            Toast.makeText(this@ConfigActivity, "$title \n $message", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in showAlert", e)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        try {
            finish()
            return true
        } catch (e: Exception) {
            LogUtils.logError(this, "ConfigActivity", "Error in onSupportNavigateUp", e)
            return false
        }
    }
}