package tw.ibiz.yukachat

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

class MenuDialogFragment : DialogFragment() {

    private lateinit var closeButton: ImageButton
    private lateinit var menuItemsContainer: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_menu, container, false)

        // 初始化视图
        closeButton = view.findViewById(R.id.closeButton)
        menuItemsContainer = view.findViewById(R.id.menuItemsContainer)

        // 设置右侧透明区域的点击事件（通过XML的android:onClick已绑定）
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupMenuItems()
    }

    // 处理右侧透明区域的点击事件（与XML中的android:onClick对应）
    fun closeMenu(view: View) {
        dismiss()
    }

    private fun setupUI() {
        // 设置透明背景
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        closeButton.setOnClickListener { dismiss() }
    }

    private fun setupMenuItems() {
        // 添加菜单项（根据当前页面动态显示）
        if (activity !is ChatActivity) {
            println("對話")
            addMenuItem(R.drawable.ic_message, "對話") { openChat() }
        }
        if (activity !is AddFriendPage) {
            addMenuItem(R.drawable.ic_plus, "加好友") { openNewConversation() }
        }
        if (activity !is AddFriendPage) {
            addMenuItem(R.drawable.ic_person_circle, "帳號") { openAccount() }
        }
        if (activity !is SettingsActivity) {
            addMenuItem(R.drawable.ic_settings, "設定") { openSettings() }
        }
        addMenuItem(R.drawable.ic_logout, "登出") { logout() }

        // 添加 40sp 空白
        View(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (40 * resources.displayMetrics.scaledDensity).toInt() // Convert 40sp to pixels
            )
            menuItemsContainer.addView(this)
        }

        // 添加标题和版本信息
        addTitle("YuKa AI", 18f, R.color.gray)
        addTitle("version 1.0", 14f, R.color.gray)
    }

    @SuppressLint("UseGetLayoutInflater")
    private fun addMenuItem(iconRes: Int, title: String, action: () -> Unit) {
        val itemView = LayoutInflater.from(requireContext())
            .inflate(R.layout.menu_item, menuItemsContainer, false)

        itemView.findViewById<ImageView>(R.id.menu_item_icon).setImageResource(iconRes)
        itemView.findViewById<TextView>(R.id.menu_item_text).text = title
        itemView.setOnClickListener { action() }

        menuItemsContainer.addView(itemView)
    }

    private fun addTitle(text: String, textSize: Float, colorRes: Int = R.color.black) {
        TextView(requireContext()).apply {
            this.text = text
            this.textSize = textSize
            setTextColor(ContextCompat.getColor(requireContext(), colorRes))
            menuItemsContainer.addView(this)
        }
    }

    // 菜单项动作
    private fun openChat() {
        // startActivity(Intent(activity, ChatActivity::class.java))
        // dismiss()
    }

    private fun openNewConversation() {
        startActivity(Intent(activity, AddFriendPage::class.java))
        dismiss()
    }

    //
    private fun openAccount() {
        startActivity(Intent(activity, ProfileActivity::class.java))
        dismiss()
    }

    private fun openSettings() {
        startActivity(Intent(activity, ConfigActivity::class.java))
        dismiss()
    }

    private fun logout() {

        AlertDialog.Builder(requireContext()).apply {
            // Set message with black text
            setMessage("確定登出？")
            // Positive button (default style)
            setPositiveButton("確定") { _, _ ->
                logoutApi()
            }
            // Negative button with blue text
            setNegativeButton("取消", null)
            // Create and show the dialog
            create().apply {
                // Set white background with rounded corners
                window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)
                show()
                val tvMessage = findViewById<TextView>(android.R.id.message)
                tvMessage.setTextColor(Color.BLACK)
                tvMessage.textSize = 26.0f
                // Customize button colors after showing
                val btCancel = getButton(AlertDialog.BUTTON_NEGATIVE)
                btCancel.setTextColor(ContextCompat.getColor(context, R.color.fr_yuka))
                btCancel.textSize = 20.0f
                val btOk = getButton(AlertDialog.BUTTON_POSITIVE)
                btOk.setTextColor(ContextCompat.getColor(context, R.color.fr_yuka))
                btOk.textSize = 20.0f
            }
        }

    }

    private fun logoutApi() {
        val client = OkHttpClient()
        val sharedPref = activity?.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val xid = sharedPref?.getString("xid", "") ?: ""
        val url = "${ConfigIni.SERVER_URL}/user/app/api/?mode=sign_out&xid=$xid"
        Log.d("ConversationsActivity", url)

        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // 網絡失敗處理
                activity?.runOnUiThread {
                    AlertDialog.Builder(requireContext())
                        .setTitle("網絡錯誤")
                        .setMessage("無法連接到服務器")
                        .setPositiveButton("確定", null)
                        .show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val jsonString = response.body?.string()
                Log.d("ConversationsActivity", jsonString.toString())
                val jsonObject = jsonString?.let { JSONObject(it) }
                val status = jsonObject?.getString("status")
                val title = jsonObject?.getString("title")

                activity?.runOnUiThread {
                    if (status == "succ") {

                        println("succ 199")

                        AlertDialog.Builder(requireContext()).apply {
                            setMessage(title)
                            setPositiveButton("確定") { _, _ ->
                                println("成功")

                                val sharedPreferences by lazy {
                                    activity?.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                                }
                                val editor = sharedPreferences?.edit()
                                if (editor != null) {
                                    editor.putString("account", null)
                                    editor.putString("password", null)
                                    editor.apply()
                                }

                                requireActivity().finish()
                                startActivity(Intent(activity, LoginActivity::class.java))
                            }

                            create().apply {
                                window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)
                                show()

                                // Customize message text
                                val tvMessage = findViewById<TextView>(android.R.id.message)
                                tvMessage?.let {
                                    it.setTextColor(Color.BLACK)
                                    it.textSize = 26.0f
                                }

                                // Customize buttons
                                getButton(AlertDialog.BUTTON_NEGATIVE)?.let {
                                    it.setTextColor(ContextCompat.getColor(context, R.color.fr_yuka))
                                    it.textSize = 20.0f
                                }

                                getButton(AlertDialog.BUTTON_POSITIVE)?.let {
                                    it.textSize = 20.0f
                                }
                            }
                        }


                    } else {

                        println("succ 229")

                        AlertDialog.Builder(requireContext()).apply {
                            setMessage(title)
                            setPositiveButton("確定") { _, _ ->
                                println("成功")
                            }

                            create().apply {
                                window?.setBackgroundDrawableResource(R.drawable.bg_rounded_white)
                                show()

                                // Customize message text
                                val tvMessage = findViewById<TextView>(android.R.id.message)
                                tvMessage?.let {
                                    it.setTextColor(Color.BLACK)
                                    it.textSize = 26.0f
                                }

                                // Customize buttons
                                getButton(AlertDialog.BUTTON_NEGATIVE)?.let {
                                    it.setTextColor(ContextCompat.getColor(context, R.color.fr_yuka))
                                    it.textSize = 20.0f
                                }

                                getButton(AlertDialog.BUTTON_POSITIVE)?.let {
                                    it.textSize = 20.0f
                                }
                            }
                        }

                    }
                }
            }
        })
    }

}