package tw.ibiz.yukachat

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.URL

class AddFriendPage : AppCompatActivity() {

    private lateinit var titleLabel: TextView
    private lateinit var descriptionLabel: TextView
    private lateinit var inputTitleLabel: TextView
    private lateinit var inputTextField: EditText
    private lateinit var submitButton: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            println("AddFriendPage")
            setContentView(R.layout.activity_add_friend)

            // Initialize views
            titleLabel = findViewById(R.id.titleLabel)
            descriptionLabel = findViewById(R.id.descriptionLabel)
            inputTitleLabel = findViewById(R.id.inputTitleLabel)
            inputTextField = findViewById(R.id.inputTextField)
            submitButton = findViewById(R.id.submitButton)

            // 返回按鈕點擊事件
            val backButton: ImageView = findViewById(R.id.backButton)
            backButton.setOnClickListener {
                Log.d("AddFriendPage", "返回按鈕被點擊")
                finish()
            }

            setupUI()
            setupListeners()
        } catch (e: Exception) {
            LogUtils.logError(this, "AddFriendPage", "初始化失敗: ${e.message}")
            showAlert("錯誤", "頁面加載失敗")
        }
    }

    private fun setupUI() {
        try {
            // Set title and description text
            titleLabel.text = "與好友保持聯繫，讓交流更便利！"
            descriptionLabel.text = "在這裡，你可以透過輸入好友的電話或 Email 來發送好友邀請。無論是家人、朋友，還是工作夥伴，輕鬆建立你的專屬聯絡網。接受邀請後，即可開始聊天、分享訊息，讓溝通變得更加即時與順暢！立即邀請好友，一起享受便捷的對話體驗吧！"

            // Set input title with red asterisk
            val inputTitleText = "好友的帳號 / email / 行動電話 "
            val asterisk = "*"
            val spannableString = android.text.SpannableString(inputTitleText + asterisk)
            spannableString.setSpan(
                android.text.style.ForegroundColorSpan(resources.getColor(android.R.color.holo_red_light)),
                inputTitleText.length,
                inputTitleText.length + asterisk.length,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            inputTitleLabel.text = spannableString

            // Set input field hint
            inputTextField.hint = "請填寫帳號或 email 或 行動電話"

            // Set submit button text
            submitButton.text = "送出"
        } catch (e: Exception) {
            LogUtils.logError(this, "AddFriendPage", "UI設置失敗: ${e.message}")
        }
    }

    private fun setupListeners() {
        submitButton.setOnClickListener {
            submitButtonTapped()
        }
    }

    private fun submitButtonTapped() {
        try {
            // Handle empty input case
            val input = inputTextField.text.toString()
            if (input.isEmpty()) {
                showAlert("輸入為空", "請輸入內容後再試")
                return
            }

            // Get xid from SharedPreferences
            val sharedPref = getSharedPreferences("AppPrefs", MODE_PRIVATE)
            val xid = sharedPref.getString("xid", null)
            if (xid == null) {
                showAlert("錯誤", "無法獲取用戶ID")
                LogUtils.logError(this, "AddFriendPage", "無法獲取xid")
                return
            }

            // Create URL with parameters
            val jsonUrlString = "${ConfigIni.SERVER_URL}im/app/api/?mode=invite&keyword=$input&xid=$xid"

            println(jsonUrlString)
            // Show loading indicator
            val loadingDialog = AlertDialog.Builder(this)
                .setTitle("請稍候")
                .setMessage("處理中...")
                .setCancelable(false)
                .create()
            loadingDialog.show()

            // Execute network request in background thread
            Thread {
                try {
                    val url = URL(jsonUrlString)
                    val connection = url.openConnection() as java.net.HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 10000 // 10秒超時
                    connection.readTimeout = 10000

                    val responseCode = connection.responseCode
                    if (responseCode == 200) {
                        val inputStream = connection.inputStream
                        val response = inputStream.bufferedReader().use { it.readText() }

                        runOnUiThread {
                            loadingDialog.dismiss()
                            try {
                                val json = JSONObject(response)
                                println(json)
                                val status = json.getString("status")
                                val title = json.getString("title")

                                if (status == "succ") {
                                    showAlert("成功", title)
                                } else {
                                    showAlert("提示", title)
                                }
                            } catch (e: Exception) {
                                LogUtils.logError(this, "AddFriendPage", "JSON解析失敗: ${e.message}")
                                showAlert("錯誤", "無法解析伺服器回應")
                            }
                        }
                    } else {
                        runOnUiThread {
                            loadingDialog.dismiss()
                            LogUtils.logError(this, "AddFriendPage", "HTTP錯誤碼: $responseCode")
                            showAlert("請求失敗", "HTTP錯誤碼: $responseCode")
                        }
                    }
                    connection.disconnect()
                } catch (e: Exception) {
                    runOnUiThread {
                        loadingDialog.dismiss()
                        LogUtils.logError(this, "AddFriendPage", "網絡請求失敗: ${e.message}")
                        showAlert("請求失敗", "網絡錯誤")
                    }
                }
            }.start()
        } catch (e: Exception) {
            LogUtils.logError(this, "AddFriendPage", "提交按鈕處理失敗: ${e.message}")
            showAlert("錯誤", "操作失敗")
        }
    }

    private fun showAlert(title: String, message: String) {
        runOnUiThread {
            try {
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(message)
                    .setPositiveButton("確定", null)
                    .show()
            } catch (e: Exception) {
                LogUtils.logError(this, "AddFriendPage", "顯示對話框失敗: ${e.message}")
            }
        }
    }
}