package tw.ibiz.yukachat

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

class ConversationsActivity : AppCompatActivity() {

    private var sharedPref: SharedPreferences? = null
    private var handler: Handler? = null
    private var isAlertShowing = false
    private var alertDialog: AlertDialog? = null
    private val CHECK_INTERVAL = 10000L // 網路檢查間隔 10 秒
    private var lastAlertTime = 0L // 用於防抖顯示對話框

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversations)

        sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        handler = Handler(Looper.getMainLooper())

        // 設定按鈕點擊事件
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            Log.d("ConversationsActivity", "設定按鈕被點擊")
            val menuDialog = MenuDialogFragment()
            menuDialog.show(supportFragmentManager, "MenuDialog")
        }

        // 新增好友按鈕點擊事件
        findViewById<ImageButton>(R.id.btnAddFriend).setOnClickListener {
            Log.d("ConversationsActivity", "新增好友按鈕被點擊")
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            } else {
                // 初始化語音通話（假設 VoiceCallClient 存在）
                // voiceCallClient = VoiceCallClient(this, "ws://192.168.0.12:8080")
            }
        }

        // 搜尋按鈕點擊事件
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            val searchText = findViewById<EditText>(R.id.etSearch).text.toString()
            Log.d("ConversationsActivity", "搜尋按鈕被點擊，搜尋內容：$searchText")
        }

        // 開始網絡檢查
        startNetworkCheck()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permissions", "錄音權限已授予")
                // 初始化語音通話（假設 VoiceCallClient 存在）
                // voiceCallClient = VoiceCallClient(this, "ws://192.168.0.12:8080")
            } else {
                val errorMsg = "錄音權限被拒絕，無法進行語音通話"
                LogUtils.logToFile(this, errorMsg)
                Log.e("Permissions", errorMsg)
                if (!isFinishing && !isDestroyed) {
                    AlertDialog.Builder(this)
                        .setMessage("需要錄音權限以進行語音通話")
                        .setPositiveButton("確定", null)
                        .show()
                }
            }
        }
    }

    private fun startNetworkCheck() {
        val checkRunnable = object : Runnable {
            override fun run() {
                checkNetworkConnection()
                handler?.postDelayed(this, CHECK_INTERVAL)
            }
        }
        handler?.post(checkRunnable)
    }

    private fun checkNetworkConnection() {
        CoroutineScope(Dispatchers.IO).launch {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(ConfigIni.SERVER_URL)
                connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 3000
                connection.readTimeout = 3000
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    runOnUiThread {
                        if (isAlertShowing) {
                            isAlertShowing = false
                            alertDialog?.dismiss()
                            checkLoginStatus()
                        }
                    }
                } else {
                    val errorMsg = "網路檢查失敗，HTTP 狀態碼: $responseCode"
                    LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                    Log.e("NetworkCheck", errorMsg)
                    showNetworkAlert()
                }
            } catch (e: SocketTimeoutException) {
                val errorMsg = "網路檢查超時: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("NetworkCheck", errorMsg)
                showNetworkAlert()
            } catch (e: IOException) {
                val errorMsg = "網路檢查失敗: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("NetworkCheck", errorMsg)
                showNetworkAlert()
            } catch (e: Exception) {
                val errorMsg = "網路檢查未知錯誤: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("NetworkCheck", errorMsg)
                showNetworkAlert()
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun showNetworkAlert() {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastAlertTime < 10000) return // 10秒內不重複顯示
        lastAlertTime = currentTime
        runOnUiThread {
            if (!isFinishing && !isDestroyed && !isAlertShowing) {
                isAlertShowing = true
                alertDialog = AlertDialog.Builder(this)
                    .setTitle("網絡連線問題")
                    .setMessage("無法連接到網絡，請檢查您的網絡設置")
                    .setPositiveButton("確定") { dialog, _ ->
                        isAlertShowing = false
                        dialog.dismiss()
                    }
                    .setCancelable(true)
                    .show()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        checkLoginStatus()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler?.removeCallbacksAndMessages(null)
        alertDialog?.dismiss()
        alertDialog = null
    }

    private fun apiLoaderList() {
        val pref = sharedPref ?: return
        val xid = pref.getString("xid", "") ?: ""
        val apiUrl = "${ConfigIni.SERVER_URL}im/app/api/?mode=target_list&xid=$xid"
        Log.d("apiLoaderList", apiUrl)

        CoroutineScope(Dispatchers.IO).launch {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(apiUrl)
                connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    Log.d("API_RESPONSE", response)

                    try {
                        val jsonObject = JSONObject(response)
                        val status = jsonObject.optString("status", "")
                        if (status == "succ") {
                            val dataArray = jsonObject.optJSONArray("data") ?: return@launch
                            val type = object : TypeToken<List<Friend>>() {}.type
                            val friendList: List<Friend> = Gson().fromJson(dataArray.toString(), type)

                            runOnUiThread {
                                findViewById<RecyclerView>(R.id.rvFriendList).apply {
                                    layoutManager = LinearLayoutManager(this@ConversationsActivity)
                                    adapter = FriendAdapter(friendList) { friend ->
                                        Log.d("ConversationsActivity", "點擊好友：${friend.targetName}")
                                        val intent = Intent(this@ConversationsActivity, ChatActivity::class.java)
                                        intent.putExtra("targetXid", friend.targetXid)
                                        intent.putExtra("targetName", friend.targetName)
                                        intent.putExtra("targetFigure", friend.targetFigure)
                                        startActivity(intent)
                                    }
                                }
                            }
                        } else {
                            val errorMsg = "API 回應狀態無效: $status"
                            LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                            Log.e("API_ERROR", errorMsg)
                        }
                    } catch (e: Exception) {
                        val errorMsg = "JSON 解析錯誤: ${e.message}"
                        LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                        Log.e("JSON_ERROR", errorMsg)
                        runOnUiThread { showErrorDialog("資料解析失敗") }
                    }
                } else {
                    val errorMsg = "API 請求失敗，HTTP 狀態碼: $responseCode"
                    LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                    Log.e("API_ERROR", errorMsg)
                    runOnUiThread { showErrorDialog("伺服器回應錯誤") }
                }
            } catch (e: SocketTimeoutException) {
                val errorMsg = "API 請求超時: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("API_ERROR", errorMsg)
                runOnUiThread { showErrorDialog("網路超時，請稍後重試") }
            } catch (e: IOException) {
                val errorMsg = "API 請求網路錯誤: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("API_ERROR", errorMsg)
                runOnUiThread { showErrorDialog("網路錯誤，請檢查連線") }
            } catch (e: Exception) {
                val errorMsg = "API 請求未知錯誤: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("API_ERROR", errorMsg)
                runOnUiThread { showErrorDialog("發生未知錯誤") }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun checkLoginStatus() {
        val pref = sharedPref ?: return
        val xid = pref.getString("xid", "") ?: ""
        if (xid.isEmpty()) {
            Log.d("LoginStatus", "xid 未定義")
            navigateToLogin()
            return
        }

        val account = pref.getString("account", null)
        val password = pref.getString("password", null)
        if (!account.isNullOrEmpty() && !password.isNullOrEmpty()) {
            val apiUrl = "${ConfigIni.SERVER_URL}user/app/api/?mode=log_in&is_uu=$account&is_pp=$password&xid=$xid"
            Log.d("checkLoginStatus", apiUrl)
            loginResult(apiUrl)
        } else {
            val errorMsg = "帳號或密碼未存儲"
            LogUtils.logToFile(this, errorMsg)
            Log.d("LoginStatus", errorMsg)
            runOnUiThread { navigateToLogin() }
        }
    }

    private fun loginResult(apiUrl: String) {
        CoroutineScope(Dispatchers.IO).launch {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(apiUrl)
                connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    Log.d("LoginResult", response)

                    try {
                        val jsonObject = JSONObject(response)
                        val status = jsonObject.optString("status", "")
                        val title = jsonObject.optString("title", "")
                        Log.d("LoginResult", "title: $title")

                        if (status == "succ") {
                            Log.d("LoginResult", "登入成功")
                            val dataObject = jsonObject.optJSONObject("data") ?: return@launch
                            val sid = dataObject.optString("sid", "")
                            Log.d("LoginResult", "sid: $sid")

                            sharedPref?.edit()?.putString("sid", sid)?.apply()
                            apiLoaderList()
                        } else {
                            val errorMsg = "登入失敗，狀態: $status, 標題: $title"
                            LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                            Log.d("LoginResult", errorMsg)
                            runOnUiThread { navigateToLogin() }
                        }
                    } catch (e: Exception) {
                        val errorMsg = "登入 JSON 解析錯誤: ${e.message}"
                        LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                        Log.e("JSON_ERROR", errorMsg)
                        runOnUiThread { showErrorDialog("登入資料解析失敗") }
                    }
                } else {
                    val errorMsg = "登入 API 請求失敗，HTTP 狀態碼: $responseCode"
                    LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                    Log.e("LoginResult", errorMsg)
                    runOnUiThread { showErrorDialog("伺服器回應錯誤") }
                }
            } catch (e: SocketTimeoutException) {
                val errorMsg = "登入 API 請求超時: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("LoginResult", errorMsg)
                runOnUiThread { showErrorDialog("網路超時，請稍後重試") }
            } catch (e: IOException) {
                val errorMsg = "登入 API 請求網路錯誤: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("LoginResult", errorMsg)
                runOnUiThread { showErrorDialog("網路錯誤，請檢查連線") }
            } catch (e: Exception) {
                val errorMsg = "登入 API 請求未知錯誤: ${e.message}"
                LogUtils.logToFile(this@ConversationsActivity, errorMsg)
                Log.e("LoginResult", errorMsg)
                runOnUiThread { showErrorDialog("發生未知錯誤") }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun showErrorDialog(message: String) {
        if (!isFinishing && !isDestroyed) {
            AlertDialog.Builder(this)
                .setTitle("錯誤")
                .setMessage(message)
                .setPositiveButton("確定", null)
                .show()
        }
    }
}