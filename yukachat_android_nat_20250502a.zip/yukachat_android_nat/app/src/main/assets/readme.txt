a0970523635@icloud.com
Seanjan02

yukaaiservice@gmail.com
Service1234

Send Android Push Notifications Using Firebase Cloud Messaging | Android Studio (With Source Code)
https://www.youtube.com/watch?v=M7z2MFoI6MQ


建新推播
yukachat
Package name
tw.ibiz.yukachat


https://www.youtube.com/watch?v=QqQ83qK6_rk
How to Generate Signed APK File using Android Studio 2022 | Build Signed APK for Google Play Store

https://www.youtube.com/watch?v=vi5Ns2R4ImI
How to Make a Free Android app - Publish in play store - Step by Step

android webview在弹出软键盘时，布局没有上移的解决办法
https://blog.csdn.net/qq_43278826/article/details/90211583
