<?php

function apiRequest($url, $postData = null) {
    echo "訪問伺服器 URL: $url\n"; // 打印完整請求網址

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    if ($postData) {
        $jsonData = json_encode($postData);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        echo "發送的 JSON 參數: $jsonData\n"; // 打印請求的 JSON 參數
    }

    $response = curl_exec($ch);
    curl_close($ch);

    echo "伺服器回應: $response\n\n"; // 打印回應 JSON
    return json_decode($response, true);
}

$token_str = "dXhCJG_fTTOt2Pj4xI_KqK:APA91bH0ufd0AJjW9cvRym3NKhkRhqgc8T_YyI8u_qGr7iMyPnk_oB9hpzbts1ZDf9cxGppa4kKvziZuJQcUka7GjDbfHMLrn8lBujwmI92wue2jVYUHOSg";

// 生成與原始 $token_str 長度相同的亂數字串
function generateRandomToken($length) {
    $bytes = random_bytes($length);
    return substr(base64_encode($bytes), 0, $length);
}

$token_str = generateRandomToken(88); // 原始 $token_str 的長度為 88

// 1. 訪問 Token API
$tokenUrl = "https://ims.yukaai.com/app/api/?mode=token&device=android&xid=".urlencode($xid)."&token=".urlencode($token_str)."=&language=tw";
$tokenPayload = ""; // ["xid" => "PB1ZRjJN0GLDMu250307081912", "verify_code" => "vbna"];

$response1 = apiRequest($tokenUrl, $tokenPayload);
usleep(100000); // 100ms 延遲

if (isset($response1['xid'])) {
    $xid = $response1['xid'];

    // 2. 訪問登入 API
    $loginUrl = "https://ims.yukaai.com/user/app/api/?mode=log_in&is_uu=0921000111&is_pp=qaWS12&xid=".urlencode($xid);
    $response2 = apiRequest($loginUrl);
    usleep(100000); // 100ms 延遲

    // 3. 取得好友名單
    if (isset($response2['status']) && $response2['status'] === 'succ') {
        // 3. 訪問目標列表 API
        $targetListUrl = "https://ims.yukaai.com/im/app/api/?mode=target_list&xid=".urlencode($xid);
        $response3 = apiRequest($targetListUrl);

        // 4. 取得第一個好友的對話記錄
        if (isset($response3['data']) && is_array($response3['data'])) {
            // 只取第一個好友
            $firstTarget = $response3['data'][0];
            $target_sid = $firstTarget['target_sid'];
            $target_name = $firstTarget['target_name'];

            // 呼叫取得對話記錄的 API
            $messageUrl = "https://ims.yukaai.com/im/app/api/?mode=target_message&xid=".urlencode($xid)."&target_sid=".urlencode($target_sid)."&property=all";
            $response4 = apiRequest($messageUrl);

            // 解析並打印對話記錄
            if (isset($response4['status']) && $response4['status'] === 'succ') {
                $targetName = $response4['data']['target']['name'];
                $messages = $response4['data']['message'];

                echo "與 $targetName 的對話記錄：\n";
                foreach ($messages as $message) {
                    $type = ($message['type'] === 's') ? '發送' : '接收';
                    $time = $message['time_add'];
                    $content = $message['message'];
                    $translatedContent = $message['message_translate'];

                    echo "時間: $time\n";
                    echo "類型: $type\n";
                    echo "內容: $content\n";
                    if (!empty($translatedContent)) {
                        echo "翻譯: $translatedContent\n";
                    }
                    echo "----------------------------\n";
                }
            } else {
                echo "無法取得與 $target_name 的對話記錄。\n";
            }
        } else {
            echo "好友名單為空。\n";
        }
    }
}
?>