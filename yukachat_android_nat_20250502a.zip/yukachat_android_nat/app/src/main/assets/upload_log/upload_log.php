<?php
// upload_log.php
// Saves uploaded log file as app_log/log_$xid.txt and returns JSON with log URL

// Set content type to JSON
header('Content-Type: application/json; charset=utf-8');

// Ensure the upload directory exists
$uploadDir = 'app_log/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Get xid from query parameter
$xid = isset($_GET['xid']) ? trim($_GET['xid']) : '';
if (empty($xid)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'title' => '缺少 xid 參數']);
    exit;
}

// Sanitize xid to prevent directory traversal
$xid = preg_replace('/[^a-zA-Z0-9_-]/', '', $xid);
if (empty($xid)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'title' => '無效的 xid']);
    exit;
}

// Check if a file was uploaded
if (!isset($_FILES['log_file']) || $_FILES['log_file']['error'] == UPLOAD_ERR_NO_FILE) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'title' => '未上傳檔案']);
    exit;
}

// Validate file upload
$file = $_FILES['log_file'];
if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'title' => '檔案上傳錯誤: ' . $file['error']]);
    exit;
}

// Validate file type (expecting text/plain)
$allowedTypes = ['text/plain'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);
if (!in_array($mime, $allowedTypes)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'title' => '無效的檔案類型']);
    exit;
}

// Define destination path
$filename = 'log_' . $xid . '.txt';
$destination = $uploadDir . $filename;

// Move uploaded file to destination
if (move_uploaded_file($file['tmp_name'], $destination)) {
    // Generate the log URL
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $basePath = dirname($_SERVER['REQUEST_URI']) === '/' ? '' : dirname($_SERVER['REQUEST_URI']);
    $logUrl = $protocol . '://' . $host . $basePath . '/' . $uploadDir . $filename;

    http_response_code(200);
    echo json_encode([
        'status' => 'succ',
        'title' => '上傳成功',
        'logUrl' => $logUrl
    ]);
} else {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'title' => '儲存檔案失敗']);
}

?>
