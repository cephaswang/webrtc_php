<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';

class VoiceCallServer implements MessageComponentInterface {
    private $clients;
    private $users;
    private $db;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->users = [];

        // 數據庫連接
        try {
            $this->db = new PDO(
                "mysql:host=localhost;dbname=voice_call",
                "your_username",
                "your_password",
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
        } catch (PDOException $e) {
            echo "Database connection failed: " . $e->getMessage();
            exit;
        }
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        $userId = $conn->resourceId;

        // 為新用戶生成臨時用戶名
        $username = "Guest_" . time();

        $this->users[$userId] = [
            'conn' => $conn,
            'username' => $username,
            'inCall' => false,
            'partnerId' => null,
            'muted' => false
        ];

        // 保存用戶到數據庫
        $this->saveUser($userId, $username);

        $conn->send(json_encode([
            'type' => 'init',
            'userId' => $userId,
            'username' => $username
        ]));

        $this->broadcastOnlineUsers();
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        if ($data === null || !isset($data['type'])) return;

        $fromId = $from->resourceId;

        switch ($data['type']) {
            case 'call_request':
                $this->handleCallRequest($fromId, $data['targetId']);
                break;
            case 'call_response':
                $this->handleCallResponse($fromId, $data['callerId'], $data['accepted']);
                break;
            case 'audio_data':
                $this->handleAudioData($fromId, $data['data']);
                break;
            case 'end_call':
                $this->handleEndCall($fromId);
                break;
            case 'mute_mic':
                $this->handleMicStatus($fromId, true);
                break;
            case 'unmute_mic':
                $this->handleMicStatus($fromId, false);
                break;
            case 'change_username':
                $this->handleChangeUsername($fromId, $data['newUsername']);
                break;
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $userId = $conn->resourceId;

        if (isset($this->users[$userId]) && $this->users[$userId]['inCall']) {
            $this->handleEndCall($userId);
        }

        $this->clients->detach($conn);
        unset($this->users[$userId]);

        // 從數據庫中移除用戶
        $this->removeUser($userId);

        $this->broadcastOnlineUsers();
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "Error: {$e->getMessage()}\n";
        $conn->close();
    }

    private function handleCallRequest($fromId, $targetId) {
        if (!isset($this->users[$fromId]) || !isset($this->users[$targetId])) {
            $this->users[$fromId]['conn']->send(json_encode([
                'type' => 'error',
                'message' => '用戶不存在'
            ]));
            return;
        }

        if ($this->users[$targetId]['inCall']) {
            $this->users[$fromId]['conn']->send(json_encode([
                'type' => 'error',
                'message' => '用戶正在通話中'
            ]));
            return;
        }

        $this->users[$targetId]['conn']->send(json_encode([
            'type' => 'incoming_call',
            'fromId' => $fromId,
            'fromUsername' => $this->users[$fromId]['username']
        ]));
    }

    private function handleCallResponse($fromId, $callerId, $accepted) {
        if (!isset($this->users[$fromId]) || !isset($this->users[$callerId])) return;

        if ($accepted) {
            $this->users[$fromId]['inCall'] = true;
            $this->users[$fromId]['partnerId'] = $callerId;
            $this->users[$callerId]['inCall'] = true;
            $this->users[$callerId]['partnerId'] = $fromId;

            $this->users[$fromId]['conn']->send(json_encode([
                'type' => 'call_accepted',
                'partner' => $this->users[$callerId]['username']
            ]));
            $this->users[$callerId]['conn']->send(json_encode([
                'type' => 'call_accepted',
                'partner' => $this->users[$fromId]['username']
            ]));

            // 記錄通話歷史
            $this->logCall($fromId, $callerId);
        }
    }

    private function handleAudioData($fromId, $audioData) {
        if (isset($this->users[$fromId]) && $this->users[$fromId]['inCall']) {
            $partnerId = $this->users[$fromId]['partnerId'];
            if (isset($this->users[$partnerId]) && !$this->users[$fromId]['muted']) {
                $this->users[$partnerId]['conn']->send(json_encode([
                    'type' => 'audio_data',
                    'data' => $audioData
                ]));
            }
        }
    }

    private function handleEndCall($fromId) {
        if (isset($this->users[$fromId]) && $this->users[$fromId]['inCall']) {
            $partnerId = $this->users[$fromId]['partnerId'];

            $this->users[$fromId]['inCall'] = false;
            $this->users[$fromId]['partnerId'] = null;

            if (isset($this->users[$partnerId])) {
                $this->users[$partnerId]['inCall'] = false;
                $this->users[$partnerId]['partnerId'] = null;