CREATE DATABASE voice_call;
USE voice_call;

CREATE TABLE users (
    user_id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE call_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id1 VARCHAR(50) NOT NULL,
    user_id2 VARCHAR(50) NOT NULL,
    call_time DATETIME NOT NULL,
    FOREIGN KEY (user_id1) REFERENCES users(user_id),
    FOREIGN KEY (user_id2) REFERENCES users(user_id)
);