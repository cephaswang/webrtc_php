<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

error_reporting(E_ALL & ~E_DEPRECATED);
ini_set('display_errors', '1');

require __DIR__ . '/vendor/autoload.php';

class VideoCallServer implements MessageComponentInterface {
    private $clients;
    private $users;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->users = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);

        $userId = $conn->resourceId;
        $username = "User_" . time();
        $this->users[$userId] = [
            'conn' => $conn,
            'username' => $username,
            'inCall' => false,
            'partnerId' => null,
            'muted' => false,
            'videoEnabled' => true // 預設啟用視訊
        ];

        echo "New connection! User ID: {$userId}\n";

        $conn->send(json_encode([
            'type' => 'username',
            'username' => $username
        ]));

        $this->broadcastOnlineUsers();
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        if ($data === null || !isset($data['type'])) {
            return;
        }

        $fromId = $from->resourceId;
        echo "Received message type: " . $data['type'] . "\n";

        switch ($data['type']) {
            case 'call_request':
                $this->handleCallRequest($fromId, $data['targetId'] ?? '');
                break;

            case 'call_response':
                $this->handleCallResponse($fromId, $data['callerId'] ?? '', $data['accepted'] ?? false);
                break;

            case 'offer':
                $this->handleOffer($fromId, $data['targetId'] ?? '', $data['sdp'] ?? '');
                break;

            case 'answer':
                $this->handleAnswer($fromId, $data['targetId'] ?? '', $data['sdp'] ?? '');
                break;

            case 'ice_candidate':
                $this->handleIceCandidate($fromId, $data['targetId'] ?? '', $data['candidate'] ?? '');
                break;

            case 'audio_data':
                $this->handleAudioData($fromId, $data['data'] ?? '');
                break;

            case 'video_data':
                $this->handleVideoData($fromId, $data['data'] ?? '');
                break;

            case 'end_call':
                $this->handleEndCall($fromId);
                break;

            case 'mute_mic':
                $this->handleMicStatus($fromId, true);
                break;

            case 'unmute_mic':
                $this->handleMicStatus($fromId, false);
                break;

            case 'disable_video':
                $this->handleVideoStatus($fromId, false);
                break;

            case 'enable_video':
                $this->handleVideoStatus($fromId, true);
                break;

            case 'change_username':
                $this->handleChangeUsername($fromId, $data['newUsername'] ?? '');
                break;

            case 'ping':
                $from->send(json_encode(['type' => 'pong']));
                break;

            default:
                echo "Unknown message type: " . $data['type'] . "\n";
                break;
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $userId = $conn->resourceId;

        if (isset($this->users[$userId]) && $this->users[$userId]['inCall']) {
            $this->endCallForUser($userId);
        }

        $this->clients->detach($conn);
        unset($this->users[$userId]);
        echo "Connection closed! User ID: {$userId}\n";

        $this->broadcastOnlineUsers();
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    private function handleCallRequest($fromId, $targetId) {
        if (!isset($this->users[$fromId]) || !isset($this->users[$targetId])) {
            $this->users[$fromId]['conn']->send(json_encode([
                'type' => 'call_rejected',
                'message' => '目標用戶不存在'
            ]));
            return;
        }

        if ($this->users[$targetId]['inCall']) {
            $this->users[$fromId]['conn']->send(json_encode([
                'type' => 'call_rejected',
                'message' => '目標用戶正在通話中'
            ]));
            return;
        }

        $this->users[$targetId]['conn']->send(json_encode([
            'type' => 'incoming_call',
            'fromId' => $fromId,
            'fromUsername' => $this->users[$fromId]['username']
        ]));
    }

    private function handleCallResponse($fromId, $callerId, $accepted) {
        if (!isset($this->users[$fromId]) || !isset($this->users[$callerId])) {
            return;
        }

        if ($accepted) {
            $this->users[$fromId]['inCall'] = true;
            $this->users[$fromId]['partnerId'] = $callerId;
            $this->users[$callerId]['inCall'] = true;
            $this->users[$callerId]['partnerId'] = $fromId;

            $this->users[$fromId]['conn']->send(json_encode([
                'type' => 'call_accepted',
                'partner' => $this->users[$callerId]['username']
            ]));
            $this->users[$callerId]['conn']->send(json_encode([
                'type' => 'call_accepted',
                'partner' => $this->users[$fromId]['username']
            ]));

            $this->broadcastOnlineUsers();
        } else {
            $this->users[$callerId]['conn']->send(json_encode([
                'type' => 'call_rejected',
                'message' => '對方拒絕了您的通話請求'
            ]));
        }
    }

    private function handleOffer($fromId, $targetId, $sdp) {
        if (isset($this->users[$targetId])) {
            $this->users[$targetId]['conn']->send(json_encode([
                'type' => 'offer',
                'fromId' => $fromId,
                'sdp' => $sdp
            ]));
        }
    }

    private function handleAnswer($fromId, $targetId, $sdp) {
        if (isset($this->users[$targetId])) {
            $this->users[$targetId]['conn']->send(json_encode([
                'type' => 'answer',
                'fromId' => $fromId,
                'sdp' => $sdp
            ]));
        }
    }

    private function handleIceCandidate($fromId, $targetId, $candidate) {
        if (isset($this->users[$targetId])) {
            $this->users[$targetId]['conn']->send(json_encode([
                'type' => 'ice_candidate',
                'fromId' => $fromId,
                'candidate' => $candidate
            ]));
        }
    }

    private function handleAudioData($fromId, $audioData) {
        if (isset($this->users[$fromId]) && $this->users[$fromId]['inCall'] && !$this->users[$fromId]['muted']) {
            $partnerId = $this->users[$fromId]['partnerId'];
            if (isset($this->users[$partnerId])) {
                $this->users[$partnerId]['conn']->send(json_encode([
                    'type' => 'audio_data',
                    'data' => $audioData
                ]));
            }
        }
    }

    private function handleVideoData($fromId, $videoData) {
        if (isset($this->users[$fromId]) && $this->users[$fromId]['inCall'] && $this->users[$fromId]['videoEnabled']) {
            $partnerId = $this->users[$fromId]['partnerId'];
            if (isset($this->users[$partnerId])) {
                $this->users[$partnerId]['conn']->send(json_encode([
                    'type' => 'video_data',
                    'data' => $videoData
                ]));
            }
        }
    }

    private function handleEndCall($fromId) {
        if (isset($this->users[$fromId]) && $this->users[$fromId]['inCall']) {
            $this->endCallForUser($fromId);
            $this->broadcastOnlineUsers();
        }
    }

    private function handleMicStatus($userId, $isMuted) {
        if (isset($this->users[$userId])) {
            $this->users[$userId]['muted'] = $isMuted;
            if ($this->users[$userId]['inCall']) {
                $partnerId = $this->users[$userId]['partnerId'];
                if (isset($this->users[$partnerId])) {
                    $this->users[$partnerId]['conn']->send(json_encode([
                        'type' => 'mic_status',
                        'userId' => $userId,
                        'isMuted' => $isMuted
                    ]));
                }
            }
        }
    }

    private function handleVideoStatus($userId, $isEnabled) {
        if (isset($this->users[$userId])) {
            $this->users[$userId]['videoEnabled'] = $isEnabled;
            if ($this->users[$userId]['inCall']) {
                $partnerId = $this->users[$userId]['partnerId'];
                if (isset($this->users[$partnerId])) {
                    $this->users[$partnerId]['conn']->send(json_encode([
                        'type' => 'video_status',
                        'userId' => $userId,
                        'isEnabled' => $isEnabled
                    ]));
                }
            }
        }
    }

    private function handleChangeUsername($userId, $newUsername) {
        if (isset($this->users[$userId]) && !empty($newUsername)) {
            $this->users[$userId]['username'] = $newUsername;
            $this->users[$userId]['conn']->send(json_encode([
                'type' => 'username_changed',
                'username' => $newUsername
            ]));
            $this->broadcastOnlineUsers();
        }
    }

    private function endCallForUser($userId) {
        if (!isset($this->users[$userId])) return;

        $partnerId = $this->users[$userId]['partnerId'];

        $this->users[$userId]['inCall'] = false;
        $this->users[$userId]['partnerId'] = null;
        $this->users[$userId]['conn']->send(json_encode([
            'type' => 'disconnected',
            'message' => '通話已結束'
        ]));

        if (isset($this->users[$partnerId])) {
            $this->users[$partnerId]['inCall'] = false;
            $this->users[$partnerId]['partnerId'] = null;
            $this->users[$partnerId]['conn']->send(json_encode([
                'type' => 'disconnected',
                'message' => '對方已結束通話'
            ]));
        }
    }

    private function broadcastOnlineUsers() {
        $onlineUsers = [];
        foreach ($this->users as $userId => $user) {
            $onlineUsers[] = [
                'id' => $userId,
                'username' => $user['username'],
                'inCall' => $user['inCall']
            ];
        }

        $message = json_encode([
            'type' => 'online_users',
            'users' => $onlineUsers
        ]);

        foreach ($this->clients as $client) {
            $client->send($message);
        }
    }
}

$server = \Ratchet\Server\IoServer::factory(
    new \Ratchet\Http\HttpServer(
        new \Ratchet\WebSocket\WsServer(
            new VideoCallServer()
        )
    ),
    8080
);

$server->run();
