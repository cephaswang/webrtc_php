-- Create database
CREATE DATABASE video_call_app;
USE video_call_app;

-- Create users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- Store hashed passwords
    email VARCHAR(100) UNIQUE NOT NULL,
    is_online TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert a sample user (password: 'test123' hashed with bcrypt)
INSERT INTO users (username, email, password, is_online)
VALUES (
    'testuser',
    'testuser@example.com',
    '$2y$10$8q9Qz4z4z4z4z4z4z4z4zu8q9Qz4z4z4z4z4z4z4z4z4z4z4z4z4z', -- Replace with actual hashed password
    0
);