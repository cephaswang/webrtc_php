-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 07, 2023 at 04:08 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fb-messenger`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `sentBy` int(11) NOT NULL,
  `sentTo` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `type` enum('message','image','voice','like') NOT NULL DEFAULT 'message',
  `image` varchar(255) DEFAULT NULL,
  `voice` varchar(255) DEFAULT NULL,
  `status` enum('notseen','seen') NOT NULL DEFAULT 'notseen'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageID`, `message`, `sentBy`, `sentTo`, `created_at`, `type`, `image`, `voice`, `status`) VALUES
(97, 'Hi', 3, 1, '2021-11-15 00:05:41', 'message', NULL, '', 'seen'),
(98, 'Hello', 1, 3, '2023-06-05 00:37:01', 'message', NULL, '', 'seen'),
(99, '', 3, 1, '2023-06-05 00:37:36', 'image', 'content/1ea50a95c7baaf305fcaf4447d20bf62.jpg', '', 'seen'),
(100, '', 1, 3, '2023-06-05 13:13:16', 'image', 'content/2c0e9609ea234ec232ae6a3b97539d1b.jpg', '', 'seen'),
(101, '', 1, 3, '2023-06-05 13:13:33', 'image', 'content/a7560b0bb0bf545ee45b26b8c60c2a23.jpg', '', 'seen'),
(102, '', 1, 3, '2023-06-05 13:30:40', 'image', 'content/img-KKe6noSrjlhgrWvVIq40wxNe.png', '', 'seen'),
(206, '', 1, 3, '2023-06-07 18:47:45', 'like', NULL, NULL, 'notseen'),
(207, '', 1, 3, '2023-06-07 18:53:35', 'voice', '', 'content/recordings/e5469a690563289fe5846f6bf45fece0.wav', 'notseen'),
(208, '', 1, 3, '2023-06-07 18:56:34', 'image', 'content/6ec83e3816b91e6d89efe11c25131ed6.png', '', 'notseen');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profileImage` varchar(255) NOT NULL DEFAULT 'assets/images/defaultImage.png',
  `sessionID` varchar(255) NOT NULL,
  `connectionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `name`, `username`, `email`, `password`, `profileImage`, `sessionID`, `connectionID`) VALUES
(1, 'Aizaz Dinho', 'aizazdinho', 'aizaz.dinho@meralesson.com', '$2y$10$A7qcK/mHFueJtHJjAHnhuefCOMjuEX3vMxxgxHyx1EbYBrdgVy9u6', 'assets/images/defaultImage.png', '8q7n6svj1adjpun4c3vi24q97k', 110),
(3, 'Dany', 'dany', 'dany@example.com', '$2y$10$sZMmvvwnMNBnvTZnoqf5PuwaO7vg5AzFQcNq4yob.vzSDa0ZxG4n6', 'assets/images/defaultImage.png', 'lrhtqifsm9cdabehq1el3ba4fa', 131),
(7, 'Meezan', 'meezan', 'meezan@example.com', '$2y$10$sZMmvvwnMNBnvTZnoqf5PuwaO7vg5AzFQcNq4yob.vzSDa0ZxG4n6', 'assets/images/defaultImage.png', '0', 0),
(8, 'John', 'john', 'john@example.com', '$2y$10$sZMmvvwnMNBnvTZnoqf5PuwaO7vg5AzFQcNq4yob.vzSDa0ZxG4n6', 'assets/images/defaultImage.png', '0', 0),
(9, 'Mike', 'mike', 'mike@example.com', '$2y$10$sZMmvvwnMNBnvTZnoqf5PuwaO7vg5AzFQcNq4yob.vzSDa0ZxG4n6', 'assets/images/defaultImage.png', '0', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
