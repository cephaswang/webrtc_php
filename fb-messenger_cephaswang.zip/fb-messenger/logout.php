<?php 
	include 'core/init.php';
	$userObj->logout();