<?php
	// Start the session
	session_start();
	 
	// Define constant for thebase URL, and be used throughout the application
	define("BASE_URL", "http://localhost/fb-messenger/");
  
  	// Require the necessary class files
	require 'classes/DB.php';
	require 'classes/User.php';
	require 'classes/Messenger.php';
	
	// Create instances of the User and Messenger classes from the MyApp namespace
	// These instances can be used to access the methods and properties of the classes
	$userObj       = new \MyApp\User;
	$messageObj    = new \MyApp\Messenger;