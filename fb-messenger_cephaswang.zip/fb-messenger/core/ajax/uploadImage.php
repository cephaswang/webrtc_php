<?php 
	include '../init.php';

	if($_SERVER['REQUEST_METHOD'] === "POST"){
		if(isset($_FILES['file'])){
			if(!empty($_FILES['file']['name'][0])){
				$userID   = $userObj->userID;
				$sentTo   = $userObj->userData($_POST['sentTo']);

				if(!empty($sentTo)){
					$file   = $userObj->upload($_FILES['file']);

					if($file){
						//send message
						$messageObj->sendMessage('',$userID, $sentTo->userID, $file, 'image', '');
 
						echo '{"status": "success", "message":"'.BASE_URL.$file.'"}';
					}else{
						echo '{"status": "error", "message":"'.$userObj->errors().'"}';
					}
				}
			}
		}
	}