<?php
/**
	Define the namespace for the current code file as MyApp.
*/
namespace MyApp;

/**
	Import the PDO class from the PHP Standard Library.
*/
use PDO;
/**
	Class DB represents a database connection.
*/
class DB {
	/**
    	Establishes a database connection and returns the PDO object.
  	    @return PDO The PDO object representing the database connection.
    */
    public function connect() {
        $db = new PDO("mysql:host=127.0.0.1; dbname=fb-messenger", "root", "");
        return $db;
        }
    }
