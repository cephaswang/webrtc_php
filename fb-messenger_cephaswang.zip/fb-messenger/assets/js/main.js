$(function(){
    // This is a jQuery document ready function

    const receiver = $("#textarea").data("receiver");
    const chat = $("#messages");
    const recentList = $("#recentMessages");

    // Handle the WebSocket connection open event
    conn.onopen = function (e) {
        console.log("Connection established!");
    };

    // Handle the WebSocket message event
    conn.onmessage = function (e) {
        const data = JSON.parse(e.data);
        const date = new Date();
        console.log(data);

        // Check if the message is received from the receiver
        if (data.sentBy === receiver) {
            // Generate the appropriate HTML content based on the message type
            let text = '';
            if (data.type === 'image') {
                // If the message is an image
                text = `<img class="m-2 min-w-4 max-w-xs rounded-3xl" src="${data.message}"/>`;
            } else if (data.type === 'voice') {
                // If the message is a voice recording
                text = `<audio class="m-2 min-w-4 max-w-xs pt-1 rounded-3xl" controls><source src="${data.message}" type="audio/ogg"></audio>`;
            } else if (data.type === 'like') {
                // If the message is a like
                text = '<span class="text-lg text-gray-700 text-5xl"><i class="fb-color fas fa-thumbs-up"></i></span>';
            } else {
                // If the message is a text message
                text = `<span class="rounded-2xl bg-gray-200 text-gray-800 text-white py-2 px-4 m-1 rounded-full text-sm">${data.message}</span>`;
            }

            // Generate the HTML for the received message
            let message = `
                <div class="message flex w-full">
                    <div class="flex items-end">
                        <div class="px-1 py-1">
                            <img class="w-8 h-8 object-cover border-gray-400 border rounded-full" src="${baseURL}${data.profileImage}"/>
                        </div>
                        <div class="flex items-center max-w-xs">${text}</div>
                        <div class="flex self-center hover:flex">
                            <div>
                                <ul class="flex gap-x-1 text-gray-400 text-sm flex-row-reverse hidden">
                                    <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="fas fa-ellipsis-v"></i></span></li>
                                    <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="p-1 fas fa-reply"></i></span></li>
                                    <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="p-1 far fa-smile"></i></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Prepend the received message to the chat window
            chat.prepend(message);
            scrollDown(); // Scroll down to the latest message
        } else {
            // Check if the sender's recent message is already displayed
            if ($(`#recent[data-user="${data.sentBy}"]`).length !== 0) {
                // Update the existing recent message entry
                const recentMessage = $(`#recent[data-user="${data.sentBy}"] #recentText`);
                const recentTime = $(`#recent[data-user="${data.sentBy}"] #recentTime`);
                const badge = $(`#recent[data-user="${data.sentBy}"] #badge`);
                const reTime = date.toLocaleString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric' });

                let message = '';
                if (data.type === 'image') {
                    message = '[image]';
                } else if (data.type === 'voice') {
                    message = '[voice]';
                } else if (data.type === 'like') {
                    message = '<span class="text-lg text-gray-400 text-2xl"><i class="fb-color fas fa-thumbs-up"></i></span>';
                } else {
                    message = data.message;
                }

                // Update the recent message details
                recentMessage.text(message);
                recentTime.text(reTime);
                badge.html('<i class="fas fa-circle"></i>');
            } else {
                // Create a new entry for the sender's recent message
                let time = date.toLocaleString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric' });
                let recentUser = `
                    <li id="recent" data-user="${data.sentBy}" class="fb-li-active overflow-hidden flex select-none items-center cursor-pointer rounded-lg p-3">
                        <a class="flex-1" href="${baseURL}${data.username}/messages">
                            <div class="flex-1 flex">
                                <div class="flex relative gap-x-2 items-center flex-1 flex-wrap ">
                                    <div>
                                        <img class="w-12 h-12 object-cover border-gray-400 border rounded-full" src="${baseURL}${data.profileImage}">
                                    </div>
                                    <div class="flex overflow-hidden flex-wrap">
                                        <div class="mx-auto">
                                            <div class="text-gray-800">
                                                <span style="font-size: .9375rem;">${data.username}</span>
                                            </div>
                                            <div class="text-gray-500 text-xs mx-auto">
                                                <span class="text-xs">${data.message}</span>
                                            </div>
                                        </div>
                                        <div class="time-stamp text-gray-500 text-xs self-end mx-1 mx-auto">
                                            <span class="self-start tracking-wide pl-2">${time}</span>
                                        </div>
                                    </div>
                                    <span id="badge" class="fb-color absolute right-1">
                                        <i class="fas fa-circle"></i>
                                    </span>
                                </div>
                            </div>
                        </a>
                    </li>
                `;
                
                // Append the new recent message entry to the recent messages list
                recentList.append(recentUser);
            }
        }
    };
});
