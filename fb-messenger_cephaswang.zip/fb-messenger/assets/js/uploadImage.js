$(function(){
	$(':file').on('change', function(event){
		const file   = this.files[0];
 		let chat = $('#messages');
		let sentTo = $("#textarea").data('receiver');
		
		if(file.size > 	5000000){
			alert('max image size is 5mb');
		}

		const formData = new FormData();

		formData.append('file', file);
		formData.append('sentTo', sentTo);

		$.ajax({
			url: baseURL+'core/ajax/uploadImage.php',
			type: 'POST',	
			data: formData,
			success: function(image){
				const data = JSON.parse(image);
				if(data.status === "error"){
					alert(data.message);
				}else{
					let send = {sentTo:sentTo, message:data.message,type:"image"};

					let chat    = $('#messages');
					let message = '<div class="message flex w-full h-auto justify-end"><div class="flex flex-row-reverse"><div class="flex items-center"><img class="m-2 min-w-4 max-w-xs rounded-3xl" src="'+data.message+'"/></div><div class="flex items-center"><div><ul class="flex gap-x-1 text-gray-400 text-sm hidden"><li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="fas fa-ellipsis-v"></i></span></li></ul></div></div></div></div>'; 
					chat.prepend(message);
					scrollDown();
					conn.send(JSON.stringify(send));

				}
			},
			cache: false,
			contentType: false,
			processData: false
		})
	});
});