$(document).ready(function() {
  const recBtn = $('#audioRecBtn');
  const stopButton = $('#audioStopBtn');
  const sendTo = recBtn.data('to');
  const cancelBtn = $('#audioCancelBtn');
  const audioInput = $('#voiceBtnDiv')
  let chat = $('#messages');
  var recorder; // Audio recorder object
  var audioChunks = []; // Array to store recorded audio chunks

  // Start recording when recBtn is clicked
  recBtn.click(function() {
    navigator.mediaDevices.getUserMedia({ audio: true })
      .then(function(stream) {
        const options = { mimeType: 'audio/ogg' };
        recorder = new MediaRecorder(stream, options);

        recorder.addEventListener('dataavailable', function(e) {
          audioChunks.push(e.data);
        });
        $('#audioTimer').timer({ format: '%m:%s' });
        audioInput.removeClass('hidden');
        recorder.start();
      })
      .catch(function(err) {
        console.error('Error accessing microphone:', err);
      });
  });

  // Stop recording when stopBtn is clicked
  stopButton.click(function(event) {
    event.stopPropagation();
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
      recorder.addEventListener('stop', function() {
        // Combine recorded audio chunks into a single Blob
        var audioBlob = new Blob(audioChunks, { type: 'audio/ogg' });

        // Create a FormData object to send the audio file via AJAX
        var formData = new FormData();
        formData.append('file', audioBlob, 'recorded_audio.wav');
        formData.append('sendTo',sendTo);

        // Send the audio file to the server via AJAX
         $.ajax({
              url: baseURL+"core/ajax/uploadVoiceMsg.php",
              type: 'POST',
              data: formData,
              contentType: false,
              processData: false,
              success: function(voice) {
                let data = JSON.parse(voice);
                let send = { sentTo: sendTo, message: data.message, type: "voice" };
                let chat = $('#messages');
                let message = `<div class="message flex w-full h-auto justify-end">
                  <div class="flex flex-row-reverse">
                    <div class="flex items-center">
                      <audio controls class="m-2 min-w-4 max-w-xs rounded-3xl">
                        <source src="${data.message}" type="audio/ogg">
                      </audio>
                    </div>
                    <div class="flex items-center">
                      <div>
                        <ul class="flex gap-x-1 text-gray-400 text-sm hidden">
                          <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer">
                            <span><i class="fas fa-ellipsis-v"></i></span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>`;
                chat.prepend(message);

                scrollDown();
                audioInput.addClass('hidden');
                $('#audioTimer').timer('remove');
                conn.send(JSON.stringify(send));
                audioChunks = []; // Clear the recorded audio chunks

              },
              error: function() {
                alert("Something went wrong during voice message");
              }
            });
      });
    }
  });

  // Cancel recording when cancelBtn is clicked
  cancelBtn.click(function() {
    if (recorder && recorder.state !== 'inactive') {
      //recorder.stop();
      audioChunks = []; // Clear the recorded audio chunks
      audioInput.addClass('hidden');
      $('#audioTimer').timer('remove');
      console.log('Recording canceled.');
    }
  });
});