$(function(){
	$('#search').keyup(function(event){
		const search       = $(this).val();
		const userListDiv  = $('#recentMessages');
		const resultDiv    = $('.result');

		$.post(baseURL+'core/ajax/search.php',{search:search}, function(data){
			userListDiv.hide();
			resultDiv.html(data);
			resultDiv.show();
			
			if(search === ""){
				resultDiv.hide();
				userListDiv.show();
			}
		});
	});
});