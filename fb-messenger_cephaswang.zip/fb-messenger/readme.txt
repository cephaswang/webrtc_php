To set up this application, please follow the steps below:

    Create a new database named 'fb-messenger' in PHPMyAdmin.
    Import the 'fb-messenger.sql' file into your 'fb-messenger' database. In PHPMyAdmin, navigate to 'fb-messenger' -> 'Import' tab. Choose the SQL file and click on the 'Go' button.
    Open the 'init.php' file located in the 'core' directory. Set your localhost URL within the file.
    Open the 'db.php' file located in the 'core/classes' directory. Set your database name, MySQL user, and password within the file.
    If you are not using localhost, modify the WebSocket URL in the 'home.php' and 'messenger.php' files.

By following these steps, you will be able to successfully configure the application for your desired environment.
