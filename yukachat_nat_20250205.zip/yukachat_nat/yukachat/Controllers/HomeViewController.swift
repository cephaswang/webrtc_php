//
//  HomeViewController.swift
//  yukachat
//
//  Created by admin on 2024/8/8.
//

/*
https://www.youtube.com/watch?v=JafGypqFvs4
Create WebView in App (Swift 5, Xcode 12, 2023) - iOS Development
 
yukachat.85.ibiz.tw
tw.ibiz.yukachat


 yuka01 / MPrdSe6g
 yuka02 / 5ys7EaeS

 0921000111 / qaWS12

 https://www.youtube.com/watch?v=WmKRWoqdC_Y
 iOS Tutorial: Push Notifications with Firebase Cloud Messaging (Swift, SPM, APNs, etc.)

 
 https://www.youtube.com/watch?v=GDxj8KTmLrI
 How to send Android Push Notifications with Firebase Cloud Messaging
 
 AuthKey_YNRZTWLK5Y.p8

 https://www.youtube.com/watch?v=fXeDe9tafG8
 How to Submit an App to the App Store! (2021 | Xcode)

 
*/

import UIKit
import WebKit
import Toast
import VideoToolbox

class HomeViewController: UIViewController ,UIScrollViewDelegate, WKUIDelegate, WKScriptMessageHandler, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    let home_address:String = "https://ims.yukaai.com/";
//    let home_address:String = "https://ims.yukaai.com/upload.php";


    //    let home_address:String = "https://192.168.0.21/fb-messenger/";

   // String homeAddress = "https://ims.yukaai.com/";

   // String homeAddress = "https://ims.yukaai.com/upload.php";
 /*
    var webView:WKWebView = {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        prefs.preferredContentMode = .mobile
        
        let webConfiguration = WKWebViewConfiguration()
        webConfiguration.userContentController.add(self, name: "cameraHandler")
        webConfiguration.defaultWebpagePreferences = prefs
        let webView = WKWebView(frame: .zero,
            configuration: webConfiguration
        )
        return webView
    }();
*/
    
    var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("HomeViewController")
        
        // 啟用受限解碼功能
      //  VTRestrictVideoDecoders(true)
        
/*
https://www.youtube.com/watch?v=OZ6ixE2yIlw
Subview and SuperView Functions in Swift4
*/
        // 初始化 WKWebView

        let webConfiguration = WKWebViewConfiguration()
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        prefs.preferredContentMode = .mobile
        
        webConfiguration.userContentController.add(self, name: "cameraHandler")
        webConfiguration.defaultWebpagePreferences = prefs
        
        webView = WKWebView(frame: self.view.frame, configuration: webConfiguration)
        webView.uiDelegate = self

        view.addSubview(webView)
        
        // ios swift view addsubview wkwebview 佔滿版面 範例
        // 禁用自動調整遮罩，準備使用 Auto Layout
        webView.translatesAutoresizingMaskIntoConstraints = false
        
        // 設定 Auto Layout，讓 WKWebView 佔滿整個畫面
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor, constant:0),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant:0),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant:0),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant:0)
        ])

        // Do any additional setup after loading the view.
        
        guard let url = URL(string: home_address) else {
            return
        }
        print(home_address)
        
        webView.load(URLRequest(url: url))
        
        webView.navigationDelegate = self // as? WKNavigationDelegate
        
        self.webView.scrollView.delegate = self
        // Cannot assign value of type 'HomeViewController' to type '(any UIScrollViewDelegate)?'
        

    }

    // 接收來自 JavaScript 的訊息
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "cameraHandler" {
            openCamera()
        }
    }
    
    // 打開相機
    func openCamera() {
        guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
            print("相機不可用")
            return
        }
        
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .camera
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    // 處理拍攝後的圖片
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let image = info[.originalImage] as? UIImage {
            dismiss(animated: true) {
                self.uploadImageToWebView(image: image)
            }
        }
    }

    // 將圖片轉換為 Base64，並傳回 WebView
    func uploadImageToWebView(image: UIImage) {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else { return }
        let base64String = imageData.base64EncodedString()
        
        let jsCode = "handleImage('\(base64String)')"
        webView.evaluateJavaScript(jsCode, completionHandler: nil)
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        //webView.frame = view.bounds
        print(webView.frame)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    //MARK: - UIScrollViewDelegate
/*
https://stackoverflow.com/questions/40452034/disable-zoom-in-wkwebview
Disable zoom in WKWebView?
*/
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
             scrollView.pinchGestureRecognizer?.isEnabled = false
    }
}


//  MARK: navigationDelegate
extension HomeViewController: WKNavigationDelegate {
    
    
    func apiCall(iuc:String,  fCMToken:String){
        guard let url = URL(string: "\(home_address)im/push/?iuc=\(iuc)&token=\(fCMToken)&os=ios") else {
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Check if Error took place
            if let error = error {
                print("Error took place \(error)")
                return
            }
            // Read HTTP Response Status code
            if let response = response as? HTTPURLResponse {
                print("Response HTTP Status code: \(response.statusCode)")
            }
        }

        print (url)
        task.resume()
        
        // self.view.makeToast("\(url)")
        
    }
    
    
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        webView.evaluateJavaScript("window.document.head.querySelector(\"[name~=iuc][content]\").content;"){ result, error in
//            self.webView.evaluateJavaScript("window.document.getElementsByTagName('html')[0].outerHTML;"){ result, error in
            guard let iuc = result as? String, error == nil else {
                return
            }
            print(iuc)
/*
https://stackoverflow.com/questions/51772152/xcode-how-to-call-function-in-appdelegate-from-another-viewcontroller
Xcode; How to call function in AppDelegate from another ViewController [duplicate]
*/
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let fCMToken = appDelegate._fCMToken
            self.apiCall(iuc: iuc,fCMToken: fCMToken)
        }
        
    }
    
    
    
}
