//
//  LoginViewController.swift
//  yukachat
//
//  Created by admin on 2025/2/3.
//

import UIKit

class LoginViewController: UIViewController {
    
    var activeTextField: UITextField?  // 記錄當前聚焦的 TextField
    
    private let scrollView:UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.clipsToBounds = true
        return scrollView
    }()
    
    private let imageView:UIImageView = {
       let imageView = UIImageView()
        imageView.image = UIImage(named: "yuka_logo")
        imageView.contentMode = .scaleAspectFit
        imageView.layer.masksToBounds = true
        
        // https://youtu.be/CftU33ZNjAU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=985
        imageView.layer.borderWidth = 0
        imageView.layer.borderColor = UIColor.lightGray.cgColor
        return imageView
    }()

    private let welcomeLabel:UILabel = {
        let label = UILabel()
        label.text="歡迎使用Yuka AI Chat"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .center
        return label
    }()

    // Account
    private let accountLabel:UILabel = {
        let label = UILabel()
        label.text="帳號*"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()

    // https://www.youtube.com/watch?v=g7ipElQVpgU&list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=318s
    private let accountField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.returnKeyType = .continue
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "請輸入帳號"
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        return field
    }()
    
    private let passwordLabel:UILabel = {
        let label = UILabel()
        label.text="密碼*"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    // https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=1203
    private let passwordField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.returnKeyType = .done
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "請輸入密碼"
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        field.isSecureTextEntry = true
        return field
    }()
    
    private let loginButton: UIButton = {
        let button = UIButton()
        button.setTitle("登入", for: .normal)
        button.backgroundColor = .link
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius=12
        button.layer.masksToBounds = true
        button.titleLabel?.font = .systemFont(ofSize: 20,weight: .bold)
        return button
    }()
    
    private let registerLabel:UILabel = {
        let label = UILabel()
        label.text="註冊帳號"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .gray
        label.textAlignment = .left
        return label
    }()

    private let forgetLabel:UILabel = {
        let label = UILabel()
        label.text="忘記密碼"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .gray
        label.textAlignment = .left
        return label
    }()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "登入"
//        view.backgroundColor = .green

        view.backgroundColor = .white

        // 設定背景色
        navigationController?.navigationBar.backgroundColor = .systemBlue
        // 設定標題文字顏色
       // navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
       // navigationItem.rightBarButtonItem = UIBarButtonItem(title: "註冊", style: .done, target: self, action: #selector(didTapRegister))
       // navigationItem.rightBarButtonItem?.tintColor = .white
        
        /*
        // 建立右上角按鈕
        let rightButton = UIBarButtonItem(title: "註冊帳號", style: .plain, target: self, action: #selector(didTapRegister))
        
        // 設定按鈕顏色為白色
        rightButton.tintColor = UIColor.white
        
        // 加入到導航列
        self.navigationItem.rightBarButtonItem = rightButton
        */
        
        // 設定導航列標題文字顏色
        let textAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.white,  // 設定紅色標題
            .font: UIFont.boldSystemFont(ofSize: 20) // 設定字體大小
        ]
        navigationController?.navigationBar.titleTextAttributes = textAttributes

        loginButton.addTarget(self, action: #selector(loginButtonTapped), for: .touchUpInside)
        
        accountField.delegate = self
        passwordField.delegate = self
        
        // Add subbiews
        view.addSubview(scrollView)
        scrollView.addSubview(imageView)
        scrollView.addSubview(welcomeLabel)
        
        scrollView.addSubview(accountLabel)
        scrollView.addSubview(accountField)
        
        scrollView.addSubview(passwordLabel)
        scrollView.addSubview(passwordField)
        scrollView.addSubview(loginButton)
        
        scrollView.addSubview(registerLabel)
        scrollView.addSubview(forgetLabel)
        
        // 添加點擊手勢
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(didTapRegister))
        // 確保 UIImageView 可以接收手勢
        registerLabel.isUserInteractionEnabled = true
        registerLabel.addGestureRecognizer(tapGesture1)
        
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(didTapRegister))
        // 確保 UIImageView 可以接收手勢
        forgetLabel.isUserInteractionEnabled = true
        forgetLabel.addGestureRecognizer(tapGesture2)

        let tapVGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapVGesture)
        
        // 監聽鍵盤顯示與隱藏
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    // https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=595
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        scrollView.frame = view.bounds
        let size = scrollView.width/3
        imageView.frame = CGRect(x: (scrollView.width - size)/2, y: 20, width: size, height: size)
        
        // https://youtu.be/CftU33ZNjAU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=955
        imageView.layer.cornerRadius = imageView.width/2.0
        
        welcomeLabel.frame = CGRect(x: 30, y: imageView.bottom, width: scrollView.width-60, height: 40)
        
        accountLabel.frame = CGRect(x: 30, y: welcomeLabel.bottom, width: scrollView.width-60, height: 40)
        accountField.frame = CGRect(x: 30, y: accountLabel.bottom, width: scrollView.width-60, height: 52)
        
        passwordLabel.frame = CGRect(x: 30, y: accountField.bottom, width: scrollView.width-60, height: 40)
        passwordField.frame = CGRect(x: 30, y: passwordLabel.bottom, width: scrollView.width-60, height: 52)
        
        loginButton.frame = CGRect(x: 30, y: passwordField.bottom+10, width: scrollView.width-60, height: 52)
        
        registerLabel.frame = CGRect(x: 30, y: loginButton.bottom, width: scrollView.width-60, height: 40)
        forgetLabel.frame = CGRect(x: 30, y: registerLabel.bottom, width: scrollView.width-60, height: 40)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    @objc private func loginButtonTapped(){
        
        accountField.resignFirstResponder()
        passwordField.resignFirstResponder()
        
        guard let email = accountField.text, let password = passwordField.text,!email.isEmpty,!password.isEmpty, password.count >= 6 else {
            alertUserLoginError()
         return
        }
        
        
    }
    
    func alertUserLoginError() {
        let alert = UIAlertController(title: "Woops", message: "Please enter all information to log in.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel,handler: nil))
        
        present(alert,animated: true)
    }
    
    @objc private func didTapRegister(){
        let vc = RegisterViewController()
        vc.title = "Create Account"
        navigationController?.pushViewController(vc, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


// https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=1701
extension LoginViewController: UITextFieldDelegate{
    
    /*
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == accountField {
            passwordField.becomeFirstResponder()
        } else if textField == passwordField {
            loginButtonTapped()
        }
        
        return true
    }
    */
    
    // 監聽鍵盤事件，自動調整版面
    // 當鍵盤顯示時，讓畫面上移
    @objc func keyboardWillShow(notification: Notification) {
        print("keyboardWillShow")
        guard let userInfo = notification.userInfo,
              let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
              let activeTextField = activeTextField else { return }
        
        let keyboardTop = keyboardFrame.origin.y
        let textFieldBottom = activeTextField.frame.origin.y + activeTextField.frame.height + 20  // 加 20 讓輸入框不會太貼近鍵盤
        print("\(textFieldBottom)-\(keyboardTop)")
        if textFieldBottom > keyboardTop {
            let moveUp = textFieldBottom - keyboardTop
            self.view.frame.origin.y = -moveUp-60  // 讓畫面往上移
        }
    }
    
    // 當鍵盤隱藏時，恢復原來位置
    @objc func keyboardWillHide(notification: Notification) {
        print("keyboardWillHide")
        self.view.frame.origin.y = 0
    }
    
    // 當點擊 TextField 時，記錄當前輸入框
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
    }
    
    // 當輸入結束後，清除記錄
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeTextField = nil
    }

}

