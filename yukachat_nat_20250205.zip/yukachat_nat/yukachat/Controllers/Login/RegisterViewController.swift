//
//  RegisterViewController.swift
//  yukachat
//
//  Created by admin on 2025/2/3.
//

import UIKit

class RegisterViewController: UIViewController {
    
    var activeTextField: UITextField?  // 記錄當前聚焦的 TextField
    
    private let scrollView:UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.clipsToBounds = true
        return scrollView
    }()
    
    private let triangleImageView:UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "triangle.fill")
        imageView.tintColor = .systemBlue
        imageView.contentMode = .scaleAspectFit
        imageView.layer.masksToBounds = true
        return imageView
    }()
    


    private let firstNameLabel:UILabel = {
        let label = UILabel()
        label.text="名稱"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    // https://www.youtube.com/watch?v=g7ipElQVpgU&list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=318s
    
    private let firstNameField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        //field.returnKeyType = .done
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "請填寫名稱"
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        return field
    }()
    
    private let genderLabel:UILabel = {
        let label = UILabel()
        label.text="性別"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    //性別
    private let genderField:UILabel = {
        let label = UILabel()
        label.text="先生"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .darkGray
        label.textAlignment = .left
        return label
    }()
    
    // Account
    
    private let accountLabel:UILabel = {
        let label = UILabel()
        label.text="帳號"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    // https://www.youtube.com/watch?v=g7ipElQVpgU&list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=318s
    
    private let accountField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.returnKeyType = .done
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "請填寫行動電話號碼"
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        return field
    }()
    
    
    private let lastNameField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.returnKeyType = .done
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "Last Name..."
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        return field
    }()
    
    private let passwordLabel:UILabel = {
        let label = UILabel()
        label.text="密碼"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    // https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=1203
    private let passwordField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.returnKeyType = .done
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "請填寫密碼..."
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        field.isSecureTextEntry = true
        return field
    }()
    
    private let emailLabel:UILabel = {
        let label = UILabel()
        label.text="Email"
        label.font = UIFont.systemFont(ofSize: 20)
        label.textColor = .black
        label.textAlignment = .left
        return label
    }()
    
    // https://www.youtube.com/watch?v=g7ipElQVpgU&list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=318s
    private let emailField:UITextField = {
        let field = UITextField()
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.returnKeyType = .done
        field.layer.cornerRadius = 12
        field.layer.borderWidth = 1
        field.layer.borderColor = UIColor.lightGray.cgColor
        field.placeholder = "請填寫email ..."
        field.leftView = UIView(frame: CGRect(x:0,y:0,width:5,height:0))
        field.leftViewMode = .always
        field.backgroundColor = .white
        return field
    }()
    
    
    private let registerButton: UIButton = {
        let button = UIButton()
        button.setTitle("註冊", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius=12
        button.layer.masksToBounds = true
        button.titleLabel?.font = .systemFont(ofSize: 20,weight: .bold)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "註冊帳號"
        view.backgroundColor = .white
        // 設定返回按鈕與其他導航列按鈕的顏色為黃色
        navigationController?.navigationBar.tintColor = UIColor.white
        // 設定背景色
        //  navigationController?.navigationBar.backgroundColor = .systemGray
        // 設定標題文字顏色
        // navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        
        // navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Register", style: .done, target: self, action: #selector(didTapRegister))
        
        registerButton.addTarget(self, action: #selector(registerButtonTapped), for: .touchUpInside)
        
        firstNameField.delegate = self
        accountField.delegate = self
        passwordField.delegate = self
        emailField.delegate = self

        
        // Add subbiews
        view.addSubview(scrollView)
        scrollView.addSubview(firstNameLabel)
        scrollView.addSubview(firstNameField)
        
        scrollView.addSubview(accountLabel)
        scrollView.addSubview(accountField)
        
        scrollView.addSubview(genderLabel)
        scrollView.addSubview(genderField)
        
        scrollView.addSubview(triangleImageView)
        triangleImageView.transform = CGAffineTransform(rotationAngle: .pi)

        scrollView.addSubview(passwordLabel)
        scrollView.addSubview(passwordField)

        scrollView.addSubview(emailLabel)
        scrollView.addSubview(emailField)
        
        scrollView.addSubview(registerButton)
        
        // 確保 UIImageView 可以接收手勢
        // imageView.isUserInteractionEnabled = true
        scrollView.isUserInteractionEnabled = true
        
        
        // 添加點擊手勢
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapChangeGenderLabel))
        // 確保 UIImageView 可以接收手勢
        triangleImageView.isUserInteractionEnabled = true
        triangleImageView.addGestureRecognizer(tapGesture)
        
        // how to use addTarget with labels, imageview or uiview?
        // https://stackoverflow.com/questions/60333186/how-to-use-addtarget-with-labels-imageview-or-uiview
        // 創建 Tap Gesture Recognizer（點擊手勢）
        // let gesture = UITapGestureRecognizer(target: self, action: #selector(didTapChangeProfilePic))
        
        // 添加手勢到 UIImageView
        // imageView.addGestureRecognizer(gesture)
        
        let tapVGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapVGesture)
        
        // 監聽鍵盤顯示與隱藏
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)

    }
    
    deinit {
        // 移除通知監聽
        NotificationCenter.default.removeObserver(self)
    }
    

    
    @objc private func didTapChangeGenderLabel() {
        print("選取性別")
        presentGenderActionSheet()
    }
    
    @objc private func didTapChangeProfilePic() {
        print("Change pic called")
        presentPhotoActionSheet()
    }
    
    // https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=595
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        scrollView.frame = view.bounds
        // let size = scrollView.width/3
        //imageView.frame = CGRect(x: (scrollView.width - size)/2, y: 20, width: size, height: size)
        //imageView.layer.cornerRadius = imageView.width/2.0
        
        firstNameLabel.frame = CGRect(x: 30, y: 20, width: scrollView.width-60, height: 30)
        firstNameField.frame = CGRect(x: 30, y: firstNameLabel.bottom, width: scrollView.width-60, height: 52)

        genderLabel.frame = CGRect(x: 30, y: firstNameField.bottom+10, width: scrollView.width-60, height: 30)
        genderField.frame = CGRect(x: 30, y: genderLabel.bottom, width: scrollView.width-40-60, height: 52)
        triangleImageView.frame = CGRect(x: 30 + genderField.width, y: genderLabel.bottom+10, width: 40, height: 40)
 
        accountLabel.frame = CGRect(x: 30, y: genderField.bottom+10, width: scrollView.width-60, height: 30)
        accountField.frame = CGRect(x: 30, y: accountLabel.bottom, width: scrollView.width-60, height: 52)
 
        passwordLabel.frame = CGRect(x: 30, y: accountField.bottom+10, width: scrollView.width-60, height: 30)
        passwordField.frame = CGRect(x: 30, y: passwordLabel.bottom, width: scrollView.width-60, height: 52)
        
        emailLabel.frame = CGRect(x: 30, y: passwordField.bottom+10, width: scrollView.width-60, height: 30)
        emailField.frame = CGRect(x: 30, y: emailLabel.bottom, width: scrollView.width-60, height: 52)

        registerButton.frame = CGRect(x: 30, y: emailField.bottom+10, width: scrollView.width-60, height: 52)
    }
    
    
    @objc private func registerButtonTapped(){
        
        emailField.resignFirstResponder()
        passwordField.resignFirstResponder()
        firstNameField.resignFirstResponder()
        //lastNameField.resignFirstResponder()
        
        guard
            let firstName = firstNameField.text,
            //let lastName = lastNameField.text,
            let email = emailField.text, let password = passwordField.text,
            !firstName.isEmpty,//!lastName.isEmpty,
            !email.isEmpty,!password.isEmpty,
            password.count >= 6 else {
            alertUserLoginError()
            return
        }
        
        
    }
    
    func alertUserLoginError() {
        let alert = UIAlertController(title: "發生錯誤", message: "請填寫完整正確的資料", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "關閉", style: .cancel,handler: nil))
        
        present(alert,animated: true)
    }
    /*
     @objc private func didTapRegister(){
     let vc = RegisterViewController()
     vc.title = "Create Account"
     navigationController?.pushViewController(vc, animated: true)
     }
     */
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}


// https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=1701
extension RegisterViewController: UITextFieldDelegate{

    // 監聽鍵盤事件，自動調整版面
    // 當鍵盤顯示時，讓畫面上移
    @objc func keyboardWillShow(notification: Notification) {
        print("keyboardWillShow")
        guard let userInfo = notification.userInfo,
              let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect,
              let activeTextField = activeTextField else { return }
        
        let keyboardTop = keyboardFrame.origin.y
        let textFieldBottom = activeTextField.frame.origin.y + activeTextField.frame.height + 20  // 加 20 讓輸入框不會太貼近鍵盤
        print("\(textFieldBottom)-\(keyboardTop)")
        if textFieldBottom > keyboardTop {
            let moveUp = textFieldBottom - keyboardTop
            self.view.frame.origin.y = -moveUp-60  // 讓畫面往上移
        }
    }
    
    // 當鍵盤隱藏時，恢復原來位置
    @objc func keyboardWillHide(notification: Notification) {
        print("keyboardWillHide")
        self.view.frame.origin.y = 0
    }
    
    // 當點擊 TextField 時，記錄當前輸入框
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
    }
    
    // 當輸入結束後，清除記錄
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeTextField = nil
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

}

//  Swift: Firebase Chat App Part 3 - Taking or Choosing Profile Picture (Real-time) - Xcode 11 - 2020
// https://youtu.be/CftU33ZNjAU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=172
extension RegisterViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func presentGenderActionSheet(){
        // https://itisjoe.gitbooks.io/swiftgo/content/uikit/uialertcontroller.html
        let actionSheet =  UIAlertController(
            title: "性別",
            message: nil,
            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "取消", style: .cancel,handler: nil))
        actionSheet.addAction(UIAlertAction(title: "先生", style: .default,handler: {[weak self] _ in
            self?.genderField.text = "先生"
        }))
        actionSheet.addAction(UIAlertAction(title: "小姐", style: .default,handler: {[weak self] _ in
            self?.genderField.text = "小姐"
        }))
        actionSheet.addAction(UIAlertAction(title: "未定", style: .default,handler: {[weak self] _ in
            self?.genderField.text = "未定"
        }))
        present(actionSheet,animated: true)
    }
    
    func presentPhotoActionSheet(){
        // https://itisjoe.gitbooks.io/swiftgo/content/uikit/uialertcontroller.html
        let actionSheet =  UIAlertController(
            title: "頭像",
            message: "請選取頭像照片",
            preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "取消", style: .cancel,handler: nil))
        actionSheet.addAction(UIAlertAction(title: "拍照", style: .default,handler: {[weak self] _ in
            self?.presentCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "選取照片", style: .default,handler: {[weak self] _ in
            self?.presentPhotoPicker()
        }))
        present(actionSheet,animated: true)
    }
    
    
    func presentCamera(){
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.delegate = self
        vc.allowsEditing = true
        present(vc,animated: true)
    }
    
    func presentPhotoPicker(){
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc,animated: true)
    }
    
    // 當用戶選擇圖片後的處理
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // https://youtu.be/CftU33ZNjAU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=608
        picker.dismiss(animated: true, completion: nil)
        print(info)
        
        // https://youtu.be/CftU33ZNjAU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=915
        guard let selectedmage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else {
            return
        }
        self.triangleImageView.image = selectedmage
    }
    
    /// 當用戶取消選擇時
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
}
