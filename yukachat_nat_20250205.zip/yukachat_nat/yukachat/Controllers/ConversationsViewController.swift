//
//  ConversationsViewController.swift
//  yukachat
//
//  Created by admin on 2025/2/3.
//

import UIKit

class ConversationsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.red

        // Do any additional setup after loading the view.
    }


    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        /*
         UserDefaults 的預設值
         https://medium.com/%E5%BD%BC%E5%BE%97%E6%BD%98%E7%9A%84-swift-ios-app-%E9%96%8B%E7%99%BC%E5%95%8F%E9%A1%8C%E8%A7%A3%E7%AD%94%E9%9B%86/userdefaults-%E7%9A%84%E9%A0%90%E8%A8%AD%E5%80%BC-7117cc173fcc
        */
        //let logged_in = ["logged_in": true]
        //UserDefaults.standard.register(defaults: logged_in)
        
        let isLoggedIn = UserDefaults.standard.bool(forKey: "logged_in")
        //isLoggedIn = true
        
        if !isLoggedIn    {
            let vc = LoginViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            present(nav,animated: true)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
