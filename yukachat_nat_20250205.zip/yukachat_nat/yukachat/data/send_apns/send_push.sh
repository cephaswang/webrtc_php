#!/bin/bash

# Variables
AUTH_KEY_FILE="./AuthKey_YNRZTWLK5Y.p8"    # .p8 文件的路径
KEY_ID="YNRZTWLK5Y"                  # 从 Apple Developer 获取的 Key ID
TEAM_ID="7QYC352SBM"                # 从 Apple Developer 获取的 Team ID
BUNDLE_ID="com.yukaai.ims"   # 应用程序的 Bundle ID
DEVICE_TOKEN="2a80fefc2eb53d21e34ee5e2e3921c4dc72e344e7205fb6ca06b709231b16b03"           # 目标设备的设备令牌
APNS_HOST="https://api.sandbox.push.apple.com"  # 生产环境使用 https://api.push.apple.com
#APNS_HOST="https://api.push.apple.com"  # 生产环境使用 https://api.push.apple.com

URL="$APNS_HOST/3/device/$DEVICE_TOKEN"

# JWT Header
header="{\"alg\":\"ES256\",\"kid\":\"$KEY_ID\"}"
header_base64=$(echo -n $header | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')

# JWT Payload
current_time=$(date +%s)
payload="{\"iss\":\"$TEAM_ID\",\"iat\":$current_time}"
payload_base64=$(echo -n $payload | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')

# JWT Signature
signing_input="$header_base64.$payload_base64"
signature=$(echo -n $signing_input | openssl dgst -sha256 -sign $AUTH_KEY_FILE | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')

# JWT Token
jwt="$header_base64.$payload_base64.$signature"

# Notification Payload
notification_payload='{
  "aps": {
    "alert": {
      "title": "Hello 123",
      "body": "Hello, world! 456"
    },
    "sound": "default"
  }
}'

# Send Push Notification
curl -v \
  --header "authorization: bearer $jwt" \
  --header "apns-topic: $BUNDLE_ID" \
  --header "apns-push-type: alert" \
  --header "apns-priority: 10" \
  --header "apns-expiration: 0" \
  --http2 \
  --data "$notification_payload" \
  $URL


