<?php

// 請問 ios 用 php 發送推播
// APNS settings
$authKey = file_get_contents('AuthKey_YNRZTWLK5Y.p8'); // Your .p8 file
$keyId = 'YNRZTWLK5Y'; // Your key ID from Apple Developer Account
$teamId = '7QYC352SBM'; // Your team ID from Apple Developer Account
$bundleId = 'com.yukaai.ims'; // Your app's bundle ID
$deviceToken = 'fa777aa4f8f51d84af083d57e6fbfd56695891eabf59e2d7ff1f586b30de6294'; // The device token for the target device
$url = "https://api.sandbox.push.apple.com/3/device/$deviceToken"; // Use sandbox or production URL

// JWT creation
$header = ['alg' => 'ES256', 'kid' => $keyId];
$claims = ['iss' => $teamId, 'iat' => time()];
$header_encoded = base64_encode(json_encode($header));
$claims_encoded = base64_encode(json_encode($claims));
$signature = '';
openssl_sign("$header_encoded.$claims_encoded", $signature, $authKey, 'sha256');
$jwt = "$header_encoded.$claims_encoded." . base64_encode($signature);

// Payload
$payload = json_encode([
    'aps' => [
        'alert' => [
            'title' => 'Hello',
            'body' => 'Hello, world!'
        ],
        'sound' => 'default'
    ]
]);

// cURL setup to send push notification
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_PORT, 443);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "authorization: bearer $jwt",
    "apns-topic: $bundleId",
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);

// Execute cURL
$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($httpcode == 200) {
    echo "Push sent successfully!";
} else {
    echo "Failed to send push notification, status code: $httpcode\n";
    echo "Response: $response\n";
}

curl_close($ch);
?>
