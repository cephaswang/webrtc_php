//
//  Extensions.swift
//  yukachat
//
//  Created by admin on 2025/2/3.
//

import Foundation
import UIKit

// https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=724
// Swift: Firebase Chat App Part 2 - Log In & Register Screens (Real-time) - Xcode 12 - 2023

extension UIView{
    
    public var width:CGFloat{
        return self.frame.size.width
    }
    public var height:CGFloat{
        return self.frame.size.height
    }
    public var top:CGFloat{
        return self.frame.origin.y
    }
    public var bottom:CGFloat{
        return self.frame.size.height + self.frame.origin.y
    }
    public var left:CGFloat{
        return self.frame.origin.x
    }
    public var right:CGFloat{
        return self.frame.size.width + self.frame.origin.x
    }
}
