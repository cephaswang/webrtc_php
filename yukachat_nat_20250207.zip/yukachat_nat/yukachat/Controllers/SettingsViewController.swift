//
//  SettingsViewController.swift
//  yukachat
//
//  Created by admin on 2025/2/7.
//

/*
ios swift 按鍵，左側圖示arrow.right.circle.fill，文字靠左：登出，事件，登出

*/

import UIKit

class SettingsViewController: UIViewController {

    private let scrollView:UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.clipsToBounds = true
        return scrollView
    }()
    
    /*
    private let loginOutButton: UIButton = {
        let button = UIButton()
        button.setTitle("登出", for: .normal)
        button.backgroundColor = .link
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius=12
        button.layer.masksToBounds = true
        button.titleLabel?.font = .systemFont(ofSize: 20,weight: .bold)
        return button
    }()
    */
    private let logoutButton: UIButton = {
        let button = UIButton(type: .system)
        
        // 設置圖示和文字
        var config = UIButton.Configuration.plain()
        config.image = UIImage(systemName: "arrow.right.circle.fill")
        config.title = "登出"
        
        // 設置圖示與文字的間距
        config.imagePadding = 20  // 圖示與文字之間的間距
        config.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0)  // 可以控制內邊距

        // 設置按鈕的配置
        button.configuration = config

        // 設置圖示與文字的間距
        button.semanticContentAttribute = .forceLeftToRight

        // 設置按鈕的樣式
        button.tintColor = .black
        // 設置按鈕的大小和位置
        button.frame = CGRect(x: 100, y: 200, width: 200, height: 44) // 調整位置與大小

        button.backgroundColor = .link
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius=12
        button.layer.masksToBounds = true
        button.titleLabel?.font = .systemFont(ofSize: 20,weight: .bold)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print ("/yukachat/Controllers/SettingsViewController")
        
        setupNavigationBar()
        
        logoutButton.addTarget(self, action: #selector(logoutButtonTapped), for: .touchUpInside)
        
        // Add subbiews
        view.addSubview(scrollView)
        scrollView.addSubview(logoutButton)
    }
    
    private func setupButton() {
        
        // 創建一個 UIButton
        let logoutButton = UIButton(type: .system)
        
        // 設置按鈕圖示 (左側圖示)
        let icon = UIImage(systemName: "arrow.right.circle.fill")
        logoutButton.setImage(icon, for: .normal)
        
        // 設置按鈕文字
        logoutButton.setTitle("登出", for: .normal)
        
        // 設置圖示與文字的間距
        logoutButton.semanticContentAttribute = .forceLeftToRight
       // logoutButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -8, bottom: 0, right: 8)
      //  logoutButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 8, bottom: 0, right: -8)
        
        // 設置按鈕的樣式
        logoutButton.tintColor = .black
        
        // 設置按鈕的大小和位置
        logoutButton.frame = CGRect(x: 100, y: 200, width: 200, height: 44) // 調整位置與大小
        
        // 添加按鈕的點擊事件
        //logoutButton.addTarget(self, action: #selector(logoutTapped), for: .touchUpInside)
        
        // 將按鈕添加到視圖中
        self.view.addSubview(logoutButton)
        
    }
    
    // https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=595
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        scrollView.frame = view.bounds
        logoutButton.frame = CGRect(x: 30, y: 20, width: scrollView.width-60, height: 52)
    }
    

    // 登入按鍵事件
    @objc private func logoutButtonTapped(){
        let alert = UIAlertController(title: "提示", message: "確定要登出？", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            print("使用者按了 OK")  // 執行 OK 按鈕的動作
            // 如果要登出（設為 false）
            UserDefaults.standard.set(false, forKey: "logged_in")
            
            // 清空導航歷史，回到根視圖控制器
            self.navigationController?.popToRootViewController(animated: true)
            
            let vc = LoginViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav,animated: true)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            print("使用者按了 Cancel") // 取消動作
        }
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    

    
    func setupNavigationBar() {
        print("setupNavigationBar")
        
        // 設置導航條背景顏色為藍色
        navigationController?.navigationBar.backgroundColor = .systemBlue
        
        // 設置導航條返回圖示顏色為白色
        let backImage = UIImage(systemName: "arrow.left")?.withTintColor(.white, renderingMode: .alwaysOriginal)
        navigationController?.navigationBar.backIndicatorImage = backImage
        navigationController?.navigationBar.backIndicatorTransitionMaskImage = backImage

        // 設置導航條標題
        let titleLabel = UILabel()
        titleLabel.text = "設定"
        titleLabel.textColor = .white
        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.textAlignment = .left
        titleLabel.frame = CGRect(x: 0, y: 0, width: 200, height: 40) // 設定合適的寬度
        
        // 設置 titleView
        navigationItem.titleView = titleLabel
    }
    

}
