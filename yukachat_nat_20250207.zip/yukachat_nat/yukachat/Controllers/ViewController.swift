//
//  ViewController.swift
//  yukachat
//
//  Created by admin on 2024/8/18.
//

import UIKit




class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 設定標題
        self.title = "主頁面"
        
        // 設定左上角按鈕（個人頭像）
        let leftButton = UIBarButtonItem(
            image: UIImage(systemName: "person.circle"),
            style: .plain,
            target: self,
            action: #selector(personButtonTapped)
        )
        
        // 設定右上角按鈕（工具 + 新增）
        let wrenchButton = UIBarButtonItem(
            image: UIImage(systemName: "wrench.adjustable.fill"),
            style: .plain,
            target: self,
            action: #selector(wrenchButtonTapped)
        )
        
        let plusButton = UIBarButtonItem(
            image: UIImage(systemName: "plus"),
            style: .plain,
            target: self,
            action: #selector(plusButtonTapped)
        )
        
        // 設置按鈕到導航條
        navigationItem.leftBarButtonItem = leftButton
        navigationItem.rightBarButtonItems = [plusButton, wrenchButton]
    }
    
    @objc func personButtonTapped() {
        print("個人按鈕被點擊")
    }
    
    @objc func wrenchButtonTapped() {
        print("工具按鈕被點擊")
    }
    
    @objc func plusButtonTapped() {
        print("新增按鈕被點擊")
    }
}

