//
//  ConversationsViewController.swift
//  yukachat
//
//  Created by admin on 2025/2/3.
//

/*

ios swift 設定導航條，底色藍，右上兩個按鍵，圓圖示 plus，圓圖示 wrench.adjustable.fill，底色白 ，底色白，左上 圓圖示 person.circle，底色白，標題：主頁面
導航條，藍底，字白色
導航條標題字，靠左，粗體
 
*/

import UIKit

class ConversationsViewController: BaseViewController {
    
    private let scrollView:UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.clipsToBounds = true
        return scrollView
    }()
    
    private let loginOutButton: UIButton = {
        let button = UIButton()
        button.setTitle("登出", for: .normal)
        button.backgroundColor = .link
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius=12
        button.layer.masksToBounds = true
        button.titleLabel?.font = .systemFont(ofSize: 20,weight: .bold)
        return button
    }()
    
    // wrench.adjustable.fill 設定圖示
    // plus 加好友圖示

    override func viewDidLoad() {
        super.viewDidLoad()
        print ("/yukachat/Controllers/ConversationsViewController")
        
        
        view.backgroundColor = .white

        
        setupNavigationBar()

        // 延遲 1 秒執行函式
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            // Do any additional setup after loading the view.
            let queue = DispatchQueue(label: "sync.run")
            queue.sync {
                // 取得 AppDelegate 物件
                if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                    // let value = appDelegate._fCMToken
                    // print("從 AppDelegate 讀取的值：\(value)")
                    self.apiLodaer_cmark(fCMToken: appDelegate._fCMToken)
                }
            }
        }

        loginOutButton.addTarget(self, action: #selector(loginOutButtonTapped), for: .touchUpInside)
        
        // Add subbiews
        view.addSubview(scrollView)
        scrollView.addSubview(loginOutButton)
        
    }
    
    func setupNavigationBar() {
        print("setupNavigationBar")
        
        // 設置導航條背景顏色為藍色
        navigationController?.navigationBar.backgroundColor = .systemBlue
        
        // 設置導航條文字顏色為白色
        navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: UIColor.white
        ]
        

        // 設置導航條標題
        let titleLabel = UILabel()
        titleLabel.text = "聊天主頁面"
        titleLabel.textColor = .white
        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.textAlignment = .left
        titleLabel.frame = CGRect(x: 0, y: 0, width: 200, height: 40) // 設定合適的寬度
        
        // 設置 titleView
        navigationItem.titleView = titleLabel
        
        
        // 設置右上角兩個按鈕
        let plusButton = createBarButton(imageName: "plus", action: #selector(plusButtonTapped))
        let wrenchButton = createBarButton(imageName: "wrench.adjustable.fill", action: #selector(settingsTapped))
        
        // 將兩個按鈕放入右邊的導航欄
        navigationItem.rightBarButtonItems = [plusButton, wrenchButton]
        
        // 設置左上角的圖示為 person.circle
        let personButton = createBarButton(imageName: "person.circle", action: #selector(personButtonTapped))
        navigationItem.leftBarButtonItem = personButton
        
    }
    
    // 創建帶有白色背景的 UIBarButtonItem
    func createBarButton(imageName: String, action: Selector) -> UIBarButtonItem {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: imageName), for: .normal)
        button.backgroundColor = .white
        button.tintColor = .blue  // 設置圖示顏色
        button.frame = CGRect(x: 0, y: 0, width: 30, height: 30) // 設置按鈕大小
        
        // 設置圓角
        button.layer.cornerRadius = button.frame.size.width / 2
        button.layer.masksToBounds = true
        
        button.addTarget(self, action: action, for: .touchUpInside)
        
        // 將 UIButton 作為 UIBarButtonItem 的視圖
        return UIBarButtonItem(customView: button)
    }
    
    
    
    @objc func settingsTapped() {
        print("設定按鈕被點擊")
        let settingVC = SettingsViewController()
        navigationController?.pushViewController(settingVC, animated: true) // 使用 push 進行導航
    }
    
    @objc func plusButtonTapped() {
        print("新增按鈕被點擊")
    }
    
    @objc func personButtonTapped() {
        print("頭像按鈕被點擊")
    }
    

    // https://youtu.be/g7ipElQVpgU?list=PL5PR3UyfTWvdlk-Qi-dPtJmjTj-2YIMMf&t=595
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        scrollView.frame = view.bounds
        //loginOutButton.frame = CGRect(x: 30, y: 20, width: scrollView.width-60, height: 52)
    }
    
    
    // 登入按鍵事件
    @objc private func loginOutButtonTapped(){
        let alert = UIAlertController(title: "提示", message: "確定要登出？", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            print("使用者按了 OK")  // 執行 OK 按鈕的動作
            // 如果要登出（設為 false）
            UserDefaults.standard.set(false, forKey: "logged_in")
            
            let vc = LoginViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            self.present(nav,animated: true)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            print("使用者按了 Cancel") // 取消動作
        }
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    

    
/*
 先取得 cmark，後面會用到
 https://ims.yukaai.com/user/app/api/?mode=app&device=ios&token=test&language=tw
 */
    func apiLodaer_cmark (fCMToken:String){
        let jsonUrlSting = "\(BaseViewController.self.ServerAddress)user/app/api/?mode=app&device=ios&token=\(fCMToken)&language=\(BaseViewController.self.language)"
        print(jsonUrlSting)
        super.getJsonBase(JsonUrlSting: jsonUrlSting,actionFunc: #selector(self.read_cmark))
    }

    @objc func read_cmark (){
        // print(BaseViewController.self.srcDictBase)
        let cmark:String = BaseViewController.self.srcDictBase.object(forKey: "cmark") as! String
        BaseViewController.self.cmark = cmark
        print("cmark:\(cmark)")
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        /*
         UserDefaults 的預設值
         https://medium.com/%E5%BD%BC%E5%BE%97%E6%BD%98%E7%9A%84-swift-ios-app-%E9%96%8B%E7%99%BC%E5%95%8F%E9%A1%8C%E8%A7%A3%E7%AD%94%E9%9B%86/userdefaults-%E7%9A%84%E9%A0%90%E8%A8%AD%E5%80%BC-7117cc173fcc
        */
        //let logged_in = ["logged_in": true]
        //UserDefaults.standard.register(defaults: logged_in)
        

        
        validateAuth()
        
    }
    
    // 檢查是否巳登入
    private  func  validateAuth() {
        let isLoggedIn = UserDefaults.standard.bool(forKey: "logged_in")
        if !isLoggedIn    {
            let vc = LoginViewController()
            let nav = UINavigationController(rootViewController: vc)
            nav.modalPresentationStyle = .fullScreen
            present(nav,animated: true)
        }
    }
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
