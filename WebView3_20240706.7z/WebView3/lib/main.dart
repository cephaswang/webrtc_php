/*

https://www.youtube.com/watch?v=FrqGGw9DYfs
Adding WebView to your Flutter app

*/
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview3/utils/user_simple_preferences.dart';
import 'package:webview3/webView.dart';

Future main() async {
  /*
  UserSimplePreferences.init().then((s1) {
    UserSimplePreferences.setUsername("name7890").then((s2) {

    });
  });
*/
  runApp(const WebView());
  //await
  //SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //await sharedPreferences.setString(
//      "username", "_textFieldController.value.text.toString()");
}
