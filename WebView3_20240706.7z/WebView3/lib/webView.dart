import 'dart:async';
import 'package:flutter/material.dart';
import 'package:webview3/utils/user_simple_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

/*

https://www.youtube.com/watch?v=B1VKTniLEGk
How to Make Web View widget in Flutter

https://stackoverflow.com/questions/55592392/how-to-fix-neterr-cleartext-not-permitted-in-flutter
How to fix 'net::ERR_CLEARTEXT_NOT_PERMITTED' in flutter

https://juejin.cn/post/7204480721435082807
在 Flutter 中使用 webview_flutter 4.0 | 基础用法与事件处理

*/

class WebView extends StatefulWidget {
  const WebView({super.key});

  @override
  _WebView_State createState() => _WebView_State();
}

class _WebView_State extends State<WebView> {
  late String html3;

  static String urlAddress = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    UserSimplePreferences.init();
  }


/*
作者：loongwind
链接：https://juejin.cn/post/7056353175900520462
来源：稀土掘金
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
*/

  Future<String> get_html3() async {
    await UserSimplePreferences.init();
    await UserSimplePreferences.setUsername("name12346");
    String message = UserSimplePreferences.getUsername().toString() ?? '';

    return Future.value("""
<!DOCTYPE html>
<html>
<meta http-equiv="refresh" content="3;url=http://www.slackware.com/" />
<head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body>
<H1>$message</H1>
<p> Hello WebView 掘金</p>
</body>
</html>
""");
  }

  final controller = WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted);

  @override
  Widget build(BuildContext context) {
/*
https://blog.csdn.net/shulianghan/article/details/119920313
【Flutter】Future 异步编程 ( 简介 | then 方法 | 异常捕获 | async、await 关键字 | whenComplete 方法 | timeout 方法 )

*/
    get_html3().then((onValue) {
      controller.loadHtmlString(onValue, baseUrl: "http://www.slackware.com/");
    });

    controller.setNavigationDelegate(NavigationDelegate(
      onPageFinished: (url) {
        if (urlAddress != url.toString()) {
          urlAddress = url.toString();
          print(urlAddress);
          controller
              .runJavaScriptReturningResult(
                  "encodeURIComponent(window.document.getElementsByTagName('html')[0].outerHTML);")
              .then((onValue) {
            print("abcdefg");
            String data = Uri.decodeComponent(onValue as String);
            print(data);
          });
        }
      },
    ));

    return SafeArea(child: WebViewWidget(controller: controller));
  }
}
