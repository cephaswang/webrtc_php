import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview41/util.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
/*
  https://www.youtube.com/watch?v=q_dsgjGRBsw
  InAppBrowser - Flutter Snippet Series - EP 02
  https://github.com/pichillilorenzo/flutter_inappwebview/issues/1669
*/

  String url = "";
  double _progress = 0;
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  late InAppWebViewController _InAppWebViewController;
  late TextEditingController _controller;
  late Future<SharedPreferences> prefs;
  late WebUri _WebUri;

  @override
  void initState() {
    super.initState();
    requestPermission(permission: Permission.microphone);
    _controller = TextEditingController();
// 網址請包： http://yukachat.85.ibiz.tw/
// https://192.168.106.129/fb-messenger/
    final prefs = SharedPreferences.getInstance();
    prefs.then((SharedPreferences prefs) {
      setState(() {
        _controller.text = prefs.getString('ServerAddress') ??
            "http://yukachat.85.ibiz.tw/";
        _WebUri = WebUri.uri(Uri.parse(_controller.text));
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        key: scaffoldKey,
        appBar: AppBar(
          title: InkWell(
            child: TextField(
              controller: _controller,
              onSubmitted: (String value) {
                setState(() async {
                  final prefs = await SharedPreferences.getInstance();
                  prefs.setString('ServerAddress', value);
                  _controller.text = value;
                  _WebUri = WebUri.uri(Uri.parse(_controller.text));
                  _InAppWebViewController.loadUrl(urlRequest: URLRequest(
                    url: _WebUri,
                  ));
                });
              },
            ),
          ),
        ),
        body: Stack(
          children: [
            InAppWebView(
              initialUrlRequest: URLRequest(
                url: _WebUri,
              ),
              onWebViewCreated: (InAppWebViewController controller) {
                _InAppWebViewController = controller;
              },
              onProgressChanged:
                  (InAppWebViewController controller, int progress) {
                setState(() {
                  _progress = progress / 100;
                });
              },
              onReceivedServerTrustAuthRequest: (_, challenge) async {
                return ServerTrustAuthResponse(
                    action: ServerTrustAuthResponseAction.PROCEED);
              },
              onPermissionRequest: (controller, request) async {
                return PermissionResponse(
                    resources: request.resources,
                    action: PermissionResponseAction.GRANT);
              },
            ),
            _progress < 1
                ? SizedBox(
                    height: 3,
                    child: LinearProgressIndicator(
                      value: _progress,
                      backgroundColor:
                          Theme.of(context).primaryColor.withOpacity(0.2),
                    ),
                  )
                : const SizedBox()
          ],
        ),
      ),
    );
  }
}
