package com.example.webview41;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
