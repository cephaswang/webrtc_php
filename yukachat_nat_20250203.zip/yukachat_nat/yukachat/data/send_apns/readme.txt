chatgpt  提問
請問 ios apns swift step by step
請問 ios 用 php 發送推播

macos curl http2 install
macos push notification using curl
