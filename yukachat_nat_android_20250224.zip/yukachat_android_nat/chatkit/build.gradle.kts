plugins {
  //  alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    id("com.android.library")
    id("maven-publish")
    //id("java")
    // kotlin("android")
}

android {
    namespace = "com.stfalcon.chatkit"
    compileSdk = 35

    defaultConfig {
        // applicationId = "com.stfalcon.chatkit"
        minSdk = 24
        // targetSdk = 35
        // versionCode = 1
        // versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.flexbox:flexbox:3.0.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
}

publishing {
    publications {
        create<MavenPublication>("maven") {
            groupId = "com.github.cephaswang"
            artifactId = "chatkit"
            version = "0.0.2"
        }
    }
    repositories {
        maven {
            url = uri("https://maven.pkg.github.com/cephaswang/chatkit")
           // url = uri("https://github.com/cephaswang/chatkit")
            credentials {
              //  username =  System.getenv("USERNAME1").toString()
               // password =  System.getenv("TOKEN").toString()

                username = "cephaswang"
                password = "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"
            }
        }
    }
}


tasks.named("publishMavenPublicationToMavenRepository") {
    outputs.upToDateWhen { false } // 防止緩存使任務不執行
}


