package tw.ibiz.yukachat

/*

iOS 16 swift. MessageKit  呈現聊天列表，用戶頭像圖示，發送時間
頭像來自網址，頭像若不存在，則用系統頭像圖示
隨機生成三天，12筆記錄，含文字，圖片，各半

將同一日歸類在同一區塊
以日期為標簽
focus 到最後一筆記錄

改為 android 13 kotlin com.stfalcon.chatkit
完整 import 檔名

 */
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import java.util.*

class ChatActivity : AppCompatActivity() {

    private lateinit var messagesListAdapter: MessagesListAdapter<Message>
    private lateinit var messagesList: MessagesList

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        messagesList = findViewById(R.id.messagesList)

        // 設置訊息適配器
        messagesListAdapter = MessagesListAdapter("user_1", imageLoader)
        messagesList.setAdapter(messagesListAdapter)

        // 生成隨機訊息
        generateRandomMessages()
    }

    private fun generateRandomMessages() {
        val users = listOf(
            User("user_1", "Alice", "https://example.com/avatar1.png"),
            User("user_2", "Bob", "https://example.com/avatar2.png"),
            User("user_3", "Charlie", null) // 無頭像
        )

        val messages = mutableListOf<Message>()
        val calendar = Calendar.getInstance()

        for (i in 0 until 12) {
            val user = users.random()

            // 設定三天內的隨機時間
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_MONTH, -Random().nextInt(3))
            val date = calendar.time

            val message = if (i % 2 == 0) {
                // 文字訊息
                Message(UUID.randomUUID().toString(), user, "這是訊息 $i", null, date)
            } else {
                // 圖片訊息
                Message(UUID.randomUUID().toString(), user, null, "https://example.com/image$i.jpg", date)
            }
            messages.add(message)
        }

        // 依時間排序
        messages.sortBy { it.getCreatedAt() }

        // 插入訊息到適配器
        messages.forEach { messagesListAdapter.addToStart(it, true) }

        // 自動滾動到最後一筆
        messagesList.scrollToPosition(messagesListAdapter.itemCount - 1)
    }

    // 圖片加載器
    private val imageLoader = ImageLoader { imageView, url, _ ->
        Glide.with(this@ChatActivity)
            .load(url)
            .placeholder(R.drawable.default_avatar) // 預設頭像
            .error(R.drawable.default_avatar)
            .into(imageView)
    }
}
