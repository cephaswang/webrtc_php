package tw.ibiz.yukachat


import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import java.io.File


/*
ProfileActivity
Android 12 kotlin 帳號頁
由上而下，居中

方型照片：頭像，從網址取得檔案，若取得失敗則用系統頭像
點擊事件，
從檔案選取照片，返回更換頭像
拍照，返回更換頭像

標簽∶名稱，文字靠左
編輯框名稱∶文字框底色∶灰，圓角 10

標簽∶Email，文字靠左
編輯框Email∶文字框底色∶灰，圓角 10

按鍵∶存檔，底色藍
點擊事件，打印 編輯框名稱的值 編輯框Email值
上傳頭像到服務器，編輯框名稱的值 編輯框Email的值
底色∶#2196F3，圓角 10


*/



class ProfileActivity : AppCompatActivity() {

    private lateinit var profileImage: ImageView
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var saveButton: Button

    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        profileImage = findViewById(R.id.profile_image)
        nameEditText = findViewById(R.id.name_edit_text)
        emailEditText = findViewById(R.id.email_edit_text)
        saveButton = findViewById(R.id.save_button)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("SettingsActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        // 加載頭像
        loadProfileImage("https://ims.yukaai.com/archive/user/thumbnail/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg")

        // 頭像點擊事件
        profileImage.setOnClickListener {
            showImagePickerOptions()
        }

        // 存檔按鈕點擊事件
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val email = emailEditText.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty()) {
                // 打印名稱和 Email
                println("Name: $name, Email: $email")

                // 上傳頭像到服務器（這裡需要實現上傳邏輯）
                uploadProfileImage(selectedImageUri)

                // 顯示成功消息
                Toast.makeText(this, "Profile saved successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadProfileImage(imageUrl: String) {
        Glide.with(this)
            .load(imageUrl)
            .error(R.drawable.default_avatar) // 如果加載失敗，使用默認頭像
            .into(profileImage)
    }

    private fun showImagePickerOptions() {
        val options = arrayOf("圖片檔", "拍照")
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("請選擇")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> pickImageFromGallery()
                1 -> takePhoto()
            }
        }
        builder.show()
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    private fun takePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        photoLauncher.launch(intent)
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                selectedImageUri = uri
                profileImage.setImageURI(uri)
            }
        }
    }

    private val photoLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val imageBitmap = result.data?.extras?.get("data") as android.graphics.Bitmap
            profileImage.setImageBitmap(imageBitmap)
            selectedImageUri = saveImageToCache(imageBitmap)
        }
    }

    private fun saveImageToCache(bitmap: android.graphics.Bitmap): Uri? {
        val file = File(cacheDir, "profile_image.jpg")
        return try {
            file.outputStream().use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 100, out)
            }
            Uri.fromFile(file)
        } catch (e: Exception) {
            null
        }
    }

    private fun uploadProfileImage(imageUri: Uri?) {
        // 實現上傳邏輯
        if (imageUri != null) {
            // 上傳圖像到服務器
        }
    }
}