package tw.ibiz.yukachat


import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/* deepseek

ConfigActivity
Android 12 kotlin 語言設定

標題∶設定

第一列：底色#2196F3
由左而右
按鍵，返回，藍色圓型圖示，底色白
文字：設定，靠左

返回 事件，
打印返回

四個視圖元件
文字 languageLabel：使用的語言
按鍵 languageField：繁體中文 ，背景灰色，下底線
文字 translateLabel：自動翻譯
按鍵 translateField：否 ，背景灰色，下底線

languageField 事件，
下側選項框∶繁體中文，English
選取後傳入 languageField

translateField 事件，
下側選項框∶否，是
選取後傳入 translateField

*/


class ConfigActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("ConfigActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        // 語言按鈕點擊事件
        val languageField = findViewById<TextView>(R.id.languageField)
        languageField.setOnClickListener {
            showLanguageDialog()
        }

        // 翻譯按鈕點擊事件
        val translateField = findViewById<TextView>(R.id.translateField)
        translateField.setOnClickListener {
            showTranslateDialog()
        }
    }

    // 顯示語言選擇對話框
    private fun showLanguageDialog() {
        val languages = arrayOf("繁體中文", "English")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("選擇語言")
            .setItems(languages) { _, which ->
                findViewById<TextView>(R.id.languageField).text = languages[which]
            }
            .create()
            .show()
    }

    // 顯示翻譯選擇對話框
    private fun showTranslateDialog() {
        val options = arrayOf("否", "是")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("自動翻譯")
            .setItems(options) { _, which ->
                findViewById<TextView>(R.id.translateField).text = options[which]
            }
            .create()
            .show()
    }
}