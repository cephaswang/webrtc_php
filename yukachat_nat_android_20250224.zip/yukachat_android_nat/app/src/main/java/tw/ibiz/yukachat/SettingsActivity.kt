package tw.ibiz.yukachat

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/*
SettingsActivity
Android 12 kotlin 設定頁

標題∶設定

第一列：底色#2196F3
由左而右
按鍵，返回，藍色圓型圖示，底色白
文字：設定，靠左

四個按鍵，由上而下，用 MaterialButton 建置
帳號，設定，登出，加好友
版面∶圖示，文字靠左。

按鍵事件，打印訊息

*/


class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("SettingsActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        // 帳號按鈕點擊事件
        val accountButton: Button = findViewById(R.id.accountButton)
        accountButton.setOnClickListener {
            Log.d("SettingsActivity", "帳號按鈕被點擊")
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        // 設定按鈕點擊事件
        val settingsButton: Button = findViewById(R.id.settingsButton)
        settingsButton.setOnClickListener {
            Log.d("SettingsActivity", "設定按鈕被點擊")
            val intent = Intent(this, ConfigActivity::class.java)
            startActivity(intent)
        }

        // 登出按鈕點擊事件
        val logoutButton: Button = findViewById(R.id.logoutButton)
        logoutButton.setOnClickListener {
            Log.d("SettingsActivity", "登出按鈕被點擊")
            val sharedPref: SharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            with(sharedPref.edit()) {
                putString("", "account")
                putString("", "password")
                putString("", "xid")
                apply()
            }

            // android 12 kotlin 清空頁面記錄 跳轉到下一頁  LoginActivity
            // 創建跳轉到下一個 Activity 的 Intent
            val intent = Intent(this, LoginActivity::class.java)
            // 清除Activity堆疊並啟動新頁面
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish() // 結束當前的 LoginActivity
        }

        // 加好友按鈕點擊事件
        val addFriendButton: Button = findViewById(R.id.addFriendButton)
        addFriendButton.setOnClickListener {
            Log.d("SettingsActivity", "加好友按鈕被點擊")
        }
    }
}