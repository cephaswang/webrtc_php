<?php
header('Content-Type: application/json');

// 設定上傳目錄和支援的檔案類型
$uploadConfig = [
    'images' => [
        'dir' => 'images/',
        'extensions' => ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg']
    ],
    'documents' => [
        'dir' => 'documents/',
        'extensions' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'csv']
    ],
    'archives' => [
        'dir' => 'archives/',
        'extensions' => ['zip', 'rar', '7z', 'tar', 'gz']
    ],
    'executables' => [
        'dir' => 'executables/',
        'extensions' => ['exe', 'msi', 'dmg', 'pkg']
    ],
    'design' => [
        'dir' => 'design/',
        'extensions' => ['psd', 'ai', 'xd', 'sketch']
    ],
    'videos' => [
        'dir' => 'videos/',
        'extensions' => ['mp4', 'mov', 'avi', 'mkv', 'webm']
    ],
    'audio' => [
        'dir' => 'audio/',
        'extensions' => ['mp3', 'wav', 'ogg', 'm4a']
    ]
];

// 最大檔案大小 (50MB)
$maxFileSize = 50 * 1024 * 1024;

// 確保所有上傳目錄存在
foreach ($uploadConfig as $type => $config) {
    if (!file_exists($config['dir'])) {
        mkdir($config['dir'], 0777, true);
    }
}

// 檢查是否有檔案上傳
if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['error' => '沒有檔案上傳']);
    exit;
}

$file = $_FILES['file'];

// 檢查上傳錯誤
if ($file['error'] !== UPLOAD_ERR_OK) {
    $errorMessages = [
        UPLOAD_ERR_INI_SIZE => '檔案大小超過伺服器限制',
        UPLOAD_ERR_FORM_SIZE => '檔案大小超過表單限制',
        UPLOAD_ERR_PARTIAL => '檔案只有部分被上傳',
        UPLOAD_ERR_NO_FILE => '沒有檔案被上傳',
        UPLOAD_ERR_NO_TMP_DIR => '找不到臨時目錄',
        UPLOAD_ERR_CANT_WRITE => '寫入檔案失敗',
        UPLOAD_ERR_EXTENSION => 'PHP擴展停止了檔案上傳'
    ];
    
    $errorMessage = $errorMessages[$file['error']] ?? '未知上傳錯誤';
    http_response_code(400);
    echo json_encode(['error' => $errorMessage]);
    exit;
}

// 驗證檔案大小
if ($file['size'] > $maxFileSize) {
    http_response_code(400);
    echo json_encode(['error' => '檔案大小超過 50MB 限制']);
    exit;
}

// 取得檔案資訊
$filename = $file['name'];
$fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$fileType = 'file'; // 預設類型

// 決定儲存目錄
$uploadDir = null;
foreach ($uploadConfig as $type => $config) {
    if (in_array($fileExtension, $config['extensions'])) {
        $uploadDir = $config['dir'];
        $fileType = $type;
        break;
    }
}

// 如果沒有匹配的類型，使用預設的 documents 目錄
if ($uploadDir === null) {
    $uploadDir = $uploadConfig['documents']['dir'];
}

// 生成安全的檔案名稱
$safeFilename = preg_replace('/[^a-zA-Z0-9\-\._]/', '', $filename);
$newFilename = uniqid() . '_' . $safeFilename;
$filePath = $uploadDir . $newFilename;

// 移動上傳的檔案
if (move_uploaded_file($file['tmp_name'], $filePath)) {
    // 成功上傳，回傳檔案訪問網址和內容類型
    $fileUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/GO/' . $filePath;
    
    $response = [
        'url' => $fileUrl,
        'contentType' => $fileType,
        'originalName' => $filename,
        'fileSize' => $file['size']
    ];
    
    echo json_encode($response);
} else {
    http_response_code(500);
    echo json_encode(['error' => '移動上傳檔案失敗']);
}
?>