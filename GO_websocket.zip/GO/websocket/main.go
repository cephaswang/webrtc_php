package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true // 允許所有來源（僅用於測試）
	},
}

// 存儲所有活躍的連線
var (
	clients   = make(map[*websocket.Conn]bool)
	broadcast = make(chan Message)
	mutex     = &sync.Mutex{}
)

// Message 結構體用於存儲消息
type Message struct {
	Content     []byte          // 消息內容（文字或 URL）
	Sender      *websocket.Conn // 發送者
	MessageType int             // WebSocket 消息類型（僅 TextMessage）
	ContentType string          // 內容類型（text, image, file）
}

// ClientMessage 用於解析客戶端發送的元數據
type ClientMessage struct {
	ContentType string `json:"contentType"` // text, image, file
	Content     string `json:"content"`     // 文字或 URL
}

func handleConnections(w http.ResponseWriter, r *http.Request) {
	// 將 HTTP 請求升級為 WebSocket
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println("升級失敗:", err)
		return
	}

	// 將新連線加入 clients 地圖
	mutex.Lock()
	clients[conn] = true
	mutex.Unlock()

	defer func() {
		// 連線關閉時移除
		mutex.Lock()
		delete(clients, conn)
		mutex.Unlock()
		conn.Close()
	}()

	// 處理接收到的消息
	for {
		messageType, msg, err := conn.ReadMessage()
		if err != nil {
			log.Println("讀取錯誤:", err)
			break
		}

		// 只處理文字消息
		if messageType != websocket.TextMessage {
			log.Println("不支持的消息類型:", messageType)
			continue
		}

		// 解析 JSON 消息
		var clientMsg ClientMessage
		err = json.Unmarshal(msg, &clientMsg)
		if err != nil {
			log.Println("解析消息失敗:", err)
			continue
		}

		// 驗證內容類型
		if clientMsg.ContentType != "text" && clientMsg.ContentType != "image" && clientMsg.ContentType != "file" {
			log.Println("無效的內容類型:", clientMsg.ContentType)
			continue
		}

		// 準備廣播的消息
		broadcastMsg := Message{
			Sender:      conn,
			MessageType: websocket.TextMessage,
			ContentType: clientMsg.ContentType,
			Content:     []byte(clientMsg.Content),
		}

		fmt.Printf("收到%s訊息: %s\n", clientMsg.ContentType, clientMsg.Content)

		// 將消息發送到廣播通道
		broadcast <- broadcastMsg
	}
}

// 處理廣播消息
func handleBroadcast() {
	for {
		// 從廣播通道接收消息
		msg := <-broadcast

		// 將消息序列化為 JSON，包含 contentType 和 content
		broadcastData, err := json.Marshal(ClientMessage{
			ContentType: msg.ContentType,
			Content:     string(msg.Content),
		})
		if err != nil {
			log.Println("序列化廣播消息失敗:", err)
			continue
		}

		// 發送給所有客戶端
		mutex.Lock()
		for client := range clients {
			err := client.WriteMessage(msg.MessageType, broadcastData)
			if err != nil {
				log.Println("寫入錯誤:", err)
				client.Close()
				delete(clients, client)
			}
		}
		mutex.Unlock()
	}
}

func main() {
	http.HandleFunc("/ws", handleConnections)

	// 啟動廣播處理 goroutine
	go handleBroadcast()

	fmt.Println("伺服器啟動於 :8080")
	err := http.ListenAndServe(":8080", nil)
	if err != nil {
		log.Fatal("伺服器啟動失敗:", err)
	}
}