//
//  HomeViewController.swift
//  yukachat
//
//  Created by admin on 2024/8/8.
//

/*
https://www.youtube.com/watch?v=JafGypqFvs4
Create WebView in App (Swift 5, Xcode 12, 2023) - iOS Development
*/

import UIKit
import WebKit

class HomeViewController: UIViewController ,UIScrollViewDelegate {
    
    let webView:WKWebView = {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        prefs.preferredContentMode = .mobile
        
        let configuartion = WKWebViewConfiguration()
        configuartion.defaultWebpagePreferences = prefs
        let webView = WKWebView(frame: .zero,
            configuration: configuartion
        )
        return webView
    }();

    override func viewDidLoad() {
        super.viewDidLoad()

/*
https://www.youtube.com/watch?v=OZ6ixE2yIlw
Subview and SuperView Functions in Swift4
*/
        webView.frame = view.bounds
        view.addSubview(webView)

        // Do any additional setup after loading the view.
        
        guard let url = URL(string: "http://yukachat.85.ibiz.tw/") else {
            return
        }
        webView.load(URLRequest(url: url))
        
        webView.navigationDelegate = self as? WKNavigationDelegate
        
        self.webView.scrollView.delegate = self
        // Cannot assign value of type 'HomeViewController' to type '(any UIScrollViewDelegate)?'
        
        DispatchQueue.main.asyncAfter(deadline: .now()+5) {

        }
    }

    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        //webView.frame = view.bounds
        print(webView.frame)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    //MARK: - UIScrollViewDelegate
/*
https://stackoverflow.com/questions/40452034/disable-zoom-in-wkwebview
Disable zoom in WKWebView?
*/
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
             scrollView.pinchGestureRecognizer?.isEnabled = false
    }
}


//  MARK: navigationDelegate
extension HomeViewController: WKNavigationDelegate {
    
    
    func apiCall(iuc:String,  fCMToken:String){
        guard let url = URL(string: "http://yukachat.85.ibiz.tw/im/push/?iuc=\(iuc)&token=\(fCMToken)") else {
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Check if Error took place
            if let error = error {
                print("Error took place \(error)")
                return
            }
            // Read HTTP Response Status code
            if let response = response as? HTTPURLResponse {
                print("Response HTTP Status code: \(response.statusCode)")
            }
        }

        print (url)
        task.resume()
        
    }
    
    
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        webView.evaluateJavaScript("window.document.head.querySelector(\"[name~=iuc][content]\").content;"){ result, error in
//            self.webView.evaluateJavaScript("window.document.getElementsByTagName('html')[0].outerHTML;"){ result, error in
            guard let iuc = result as? String, error == nil else {
                return
            }
            print(iuc)
/*
https://stackoverflow.com/questions/51772152/xcode-how-to-call-function-in-appdelegate-from-another-viewcontroller
Xcode; How to call function in AppDelegate from another ViewController [duplicate]
*/
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let fCMToken = appDelegate._fCMToken
            self.apiCall(iuc: iuc,fCMToken: fCMToken)
        }
        
    }
    
    
    
}
