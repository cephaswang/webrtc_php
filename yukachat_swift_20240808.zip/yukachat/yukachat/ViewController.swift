//
//  ViewController.swift
//  yukachat
//
//  Created by admin on 2024/8/8.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

