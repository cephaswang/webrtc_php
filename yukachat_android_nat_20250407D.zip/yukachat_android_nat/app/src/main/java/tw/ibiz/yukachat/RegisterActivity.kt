package tw.ibiz.yukachat

import android.app.AlertDialog
import android.app.ProgressDialog
import android.os.Bundle
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.URLEncoder
import java.util.regex.Pattern

class RegisterActivity : AppCompatActivity() {

    private lateinit var scrollView: ScrollView
    private lateinit var firstNameLabel: TextView
    private lateinit var firstNameField: EditText
    private lateinit var genderLabel: TextView
    private lateinit var genderField: TextView
    private lateinit var triangleImageView: ImageView
    private lateinit var usernameLabel: TextView
    private lateinit var usernameField: EditText
    private lateinit var passwordLabel: TextView
    private lateinit var passwordField: EditText
    private lateinit var emailLabel: TextView
    private lateinit var emailField: EditText
    private lateinit var registerButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        println("RegisterActivity")

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("RegisterActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        title = "註冊帳號"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_chevron_left)

        // Initialize views
        scrollView = findViewById(R.id.scrollView)
        firstNameLabel = findViewById(R.id.firstNameLabel)
        firstNameField = findViewById(R.id.firstNameField)
        genderLabel = findViewById(R.id.genderLabel)
        genderField = findViewById(R.id.genderField)
        triangleImageView = findViewById(R.id.triangleImageView)
        usernameLabel = findViewById(R.id.usernameLabel)
        usernameField = findViewById(R.id.usernameField)
        passwordLabel = findViewById(R.id.passwordLabel)
        passwordField = findViewById(R.id.passwordField)
        emailLabel = findViewById(R.id.emailLabel)
        emailField = findViewById(R.id.emailField)
        registerButton = findViewById(R.id.registerButton)

        // Set up listeners
        registerButton.setOnClickListener { registerButtonTapped() }

        // Gender selection
        genderField.setOnClickListener { didTapChangeGenderLabel() }
        triangleImageView.setOnClickListener { didTapChangeGenderLabel() }

        // Input validation
        setupTextFields()
    }

    private fun setupTextFields() {
        firstNameField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                usernameField.requestFocus()
                true
            } else {
                false
            }
        }

        usernameField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                passwordField.requestFocus()
                true
            } else {
                false
            }
        }

        passwordField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                emailField.requestFocus()
                true
            } else {
                false
            }
        }

        emailField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                registerButtonTapped()
                true
            } else {
                false
            }
        }
    }

    private fun isValidPhoneNumber(phoneNumber: String): Boolean {
        val phoneRegex = "^09[0-9]{8}$"
        return Pattern.matches(phoneRegex, phoneNumber)
    }

    private fun isValidEmail(email: String): Boolean {
        val emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return Pattern.matches(emailRegex, email)
    }

    private fun showAlert(message: String, completion: (() -> Unit)? = null) {
        AlertDialog.Builder(this)
            .setTitle("提示")
            .setMessage(message)
            .setPositiveButton("確定") { _, _ -> completion?.invoke() }
            .show()
    }

    private fun alertUserLoginError(message: String = "請填寫完整正確的資料") {
        showAlert(message)
    }

    private fun registerUser(username: String, password: String, name: String, email: String, gender: String) {
        if (!isValidEmail(email)) {
            alertUserLoginError(message = "請輸入有效的電子郵件地址")
            return
        }

        if (password.length < 6) {
            alertUserLoginError(message = "密碼長度至少需要6位")
            return
        }

        // Show loading spinner
        val progressDialog = ProgressDialog(this).apply {
            setMessage("處理中...")
            setCancelable(false)
            show()
        }

        val xid = getSharedPreferences("YukaChat", MODE_PRIVATE).getString("xid", "") ?: ""

        val encodedUsername = URLEncoder.encode(username, "UTF-8")
        val encodedPassword = URLEncoder.encode(password, "UTF-8")
        val encodedName = URLEncoder.encode(name, "UTF-8")
        val encodedEmail = URLEncoder.encode(email, "UTF-8")
        val encodedGender = URLEncoder.encode(gender, "UTF-8")

        val urlString = "${ConfigIni.SERVER_URL}user/app/api/?mode=insert&username=$encodedUsername&password=$encodedPassword&name=$encodedName&email=$encodedEmail&gender=$encodedGender&xid=$xid"

        println("Register URL: $urlString")

        Thread {
            try {
                val url = java.net.URL(urlString)
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "GET"

                val responseCode = connection.responseCode
                val inputStream = if (responseCode == 200) connection.inputStream else connection.errorStream
                val response = inputStream.bufferedReader().use { it.readText() }

                runOnUiThread {
                    progressDialog.dismiss()

                    try {
                        val json = JSONObject(response)
                        println(json.toString())

                        if (json.has("status") && json.getString("status") == "succ") {
                            showAlert(message = "註冊成功") {
                                finish()
                            }
                        } else {
                            showAlert(message = json.toString())
                        }
                    } catch (e: Exception) {
                        showAlert(message = "JSON解析失敗: ${e.localizedMessage}")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progressDialog.dismiss()
                    showAlert(message = "連線失敗: ${e.localizedMessage}")
                }
            }
        }.start()
    }

    private fun backButtonTapped() {
        finish()
    }

    private fun didTapChangeGenderLabel() {
        val options = arrayOf("先生", "小姐", "未定")

        AlertDialog.Builder(this)
            .setTitle("性別")
            .setItems(options) { _, which ->
                genderField.text = options[which]
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun registerButtonTapped() {
        val firstName = firstNameField.text.toString()
        val username = usernameField.text.toString()
        val email = emailField.text.toString()
        val password = passwordField.text.toString()
        val gender = genderField.text.toString()

        if (firstName.isEmpty() || username.isEmpty() || email.isEmpty() || password.isEmpty() || gender.isEmpty()) {
            alertUserLoginError()
            return
        }

        registerUser(username, password, firstName, email, gender)
    }

    override fun onSupportNavigateUp(): Boolean {
        backButtonTapped()
        return true
    }
}