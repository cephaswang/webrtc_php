package tw.ibiz.yukachat

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment

class MenuDialogFragment : DialogFragment() {

    private lateinit var closeButton: ImageButton
    private lateinit var menuItemsContainer: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_menu, container, false)

        // 初始化视图
        closeButton = view.findViewById(R.id.closeButton)
        menuItemsContainer = view.findViewById(R.id.menuItemsContainer)

        // 设置右侧透明区域的点击事件（通过XML的android:onClick已绑定）
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupMenuItems()
    }

    // 处理右侧透明区域的点击事件（与XML中的android:onClick对应）
    fun closeMenu(view: View) {
        dismiss()
    }

    private fun setupUI() {
        // 设置透明背景
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        closeButton.setOnClickListener { dismiss() }
    }

    private fun setupMenuItems() {
        // 添加菜单项（根据当前页面动态显示）
        if (activity !is ChatActivity) {
            println("對話")
           // addMenuItem(R.drawable.ic_message, "對話") { openChat() }
        }
        if (activity !is AddFriendPage) {
            addMenuItem(R.drawable.ic_person_add, "加好友") { openNewConversation() }
        }
        if (activity !is SettingsActivity) {
            addMenuItem(R.drawable.ic_settings, "設定") { openSettings() }
        }
        addMenuItem(R.drawable.ic_logout, "登出") { logout() }

        // 添加标题和版本信息
        addTitle("YoKa AI", 18f)
        addTitle("version 1.0", 14f, R.color.gray)
    }

    @SuppressLint("UseGetLayoutInflater")
    private fun addMenuItem(iconRes: Int, title: String, action: () -> Unit) {
        val itemView = LayoutInflater.from(requireContext())
            .inflate(R.layout.menu_item, menuItemsContainer, false)

        itemView.findViewById<ImageView>(R.id.menu_item_icon).setImageResource(iconRes)
        itemView.findViewById<TextView>(R.id.menu_item_text).text = title
        itemView.setOnClickListener { action() }

        menuItemsContainer.addView(itemView)
    }

    private fun addTitle(text: String, textSize: Float, colorRes: Int = R.color.black) {
        TextView(requireContext()).apply {
            this.text = text
            this.textSize = textSize
            setTextColor(ContextCompat.getColor(requireContext(), colorRes))
            menuItemsContainer.addView(this)
        }
    }

    // 菜单项动作
    private fun openChat() {
        startActivity(Intent(activity, ChatActivity::class.java))
        dismiss()
    }

    private fun openNewConversation() {
        startActivity(Intent(activity, AddFriendPage::class.java))
        dismiss()
    }

    private fun openSettings() {
        startActivity(Intent(activity, SettingsActivity::class.java))
        dismiss()
    }

    private fun logout() {
        AlertDialog.Builder(requireContext())
            .setTitle("提示")
            .setMessage("確定要登出？")
            .setPositiveButton("OK") { _, _ ->
                requireActivity().finish()
                startActivity(Intent(activity, LoginActivity::class.java))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}