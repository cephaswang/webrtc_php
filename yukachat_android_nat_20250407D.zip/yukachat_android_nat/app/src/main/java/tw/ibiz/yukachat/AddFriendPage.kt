package tw.ibiz.yukachat

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class AddFriendPage : AppCompatActivity() {

    private lateinit var titleLabel: TextView
    private lateinit var descriptionLabel: TextView
    private lateinit var inputTitleLabel: TextView
    private lateinit var inputTextField: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        println("AddFriendPage")

        setContentView(R.layout.activity_add_friend)

        // Initialize views
        titleLabel = findViewById(R.id.titleLabel)
        descriptionLabel = findViewById(R.id.descriptionLabel)
        inputTitleLabel = findViewById(R.id.inputTitleLabel)
        inputTextField = findViewById(R.id.inputTextField)
        submitButton = findViewById(R.id.submitButton)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("AddFriendPage", "返回按鈕被點擊")
            finish()
        }

        setupUI()
        setupListeners()
    }

    private fun setupUI() {
        // Set title and description text
        titleLabel.text = "與好友保持聯繫，讓交流更便利！"
        descriptionLabel.text = "在這裡，你可以透過輸入好友的電話或 Email 來發送好友邀請。無論是家人、朋友，還是工作夥伴，輕鬆建立你的專屬聯絡網。接受邀請後，即可開始聊天、分享訊息，讓溝通變得更加即時與順暢！立即邀請好友，一起享受便捷的對話體驗吧！"

        // Set input title with red asterisk
        val inputTitleText = "好友的帳號 / email / 行動電話 "
        val asterisk = "*"
        val spannableString = android.text.SpannableString(inputTitleText + asterisk)
        spannableString.setSpan(
            android.text.style.ForegroundColorSpan(resources.getColor(android.R.color.holo_red_light)),
            inputTitleText.length,
            inputTitleText.length + asterisk.length,
            android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        inputTitleLabel.text = spannableString

        // Set input field hint
        inputTextField.hint = "請填寫帳號或 email 或 行動電話"

        // Set submit button text
        submitButton.text = "存檔"
    }

    private fun setupListeners() {
        submitButton.setOnClickListener {
            submitButtonTapped()
        }
    }

    private fun submitButtonTapped() {
        // Handle empty input case
        val input = inputTextField.text.toString()
        if (input.isEmpty()) {
            showAlert("輸入為空", "請輸入內容後再試")
            return
        }

        // Get xid from SharedPreferences
        val sharedPref = getSharedPreferences("AppPrefs", MODE_PRIVATE)
        val xid = sharedPref.getString("xid", null)
        if (xid == null) {
            showAlert("錯誤", "無法獲取用戶ID")
            return
        }

        // Create URL with parameters (should URL encode parameters in production)
        val jsonUrlString = "${ConfigIni.SERVER_URL}im/app/api/?mode=invite&keyword=$input&xid=$xid"

        println(jsonUrlString)
        // Show loading indicator
        val loadingDialog = AlertDialog.Builder(this)
            .setTitle("請稍候")
            .setMessage("處理中...")
            .setCancelable(false)
            .create()
        loadingDialog.show()

        // Execute network request in background thread
        Thread {
            try {
                val url = java.net.URL(jsonUrlString)
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "GET"

                val responseCode = connection.responseCode
                if (responseCode == 200) {
                    val inputStream = connection.inputStream
                    val response = inputStream.bufferedReader().use { it.readText() }

                    runOnUiThread {
                        loadingDialog.dismiss()
                        try {
                            val json = JSONObject(response)
                            println(json)
                            val status = json.getString("status")
                            val title = json.getString("title")

                            if (status == "succ") {
                                showAlert("成功", title)
                            } else {
                                showAlert("提示", title)
                            }
                        } catch (e: Exception) {
                            showAlert("錯誤", "無法解析伺服器回應")
                        }
                    }
                } else {
                    runOnUiThread {
                        loadingDialog.dismiss()
                        showAlert("請求失敗", "HTTP錯誤碼: $responseCode")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loadingDialog.dismiss()
                    showAlert("請求失敗", e.localizedMessage ?: "未知錯誤")
                }
            }
        }.start()
    }

    private fun showAlert(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("確定", null)
            .show()
    }
}