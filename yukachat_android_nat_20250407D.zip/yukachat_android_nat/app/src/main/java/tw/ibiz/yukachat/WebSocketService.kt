package tw.ibiz.yukachat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import kotlin.math.min

class WebSocketService : Service() {

    private lateinit var webSocket: WebSocket
    private val client = OkHttpClient()
    private lateinit var webSocketListener: EchoWebSocketListener
    private val handler = Handler(Looper.getMainLooper())
    private val heartbeatInterval = 30000L // 30秒心跳間隔
    private lateinit var userId: String
    private lateinit var userSid: String

    override fun onCreate() {
        super.onCreate()
        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        userId = sharedPref.getString("xid", "") ?: ""

      //  val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        userSid = sharedPref.getString("sid", "") ?: ""

        createNotificationChannel() // 創建通知渠道
        startForeground(1, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        //val userId = intent?.getStringExtra("userId")

        if (!::webSocket.isInitialized || webSocketListener.isWebSocketClosed) {
            connectWebSocket(userId)
        }

        intent?.let {
            when (it.getStringExtra("action")) {
                "send_text" -> {
                    val fromXid = it.getStringExtra("fromXid") ?: ""
                    val targetXid = it.getStringExtra("targetXid") ?: ""
                    val message = it.getStringExtra("message") ?: ""
                    sendMessage(fromXid, targetXid, message, null)
                }

                "send_image" -> {
                    val fromXid = it.getStringExtra("fromXid") ?: ""
                    val targetXid = it.getStringExtra("targetXid") ?: ""
                    val imageUrl = it.getStringExtra("imageUrl") ?: ""
                    sendMessage(fromXid, targetXid, null, imageUrl)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocket.close(1000, "Service stopped")
        handler.removeCallbacksAndMessages(null)
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun connectWebSocket(userId: String) {
        val request = Request.Builder()
            .url("${ConfigIni.WEBSOCKET_URL}?xid=$userId")
            .build()
        webSocketListener = EchoWebSocketListener()
        webSocket = client.newWebSocket(request, webSocketListener)
    }

    private fun sendMessage(
        fromXid: String,
        targetXid: String,
        message: String?,
        imageUrl: String?
    ) {
        val jsonMessage = when {
            !message.isNullOrEmpty() -> """
                {
                    "type": "send_text",
                    "sid": "$userSid",
                    "xid": "$userId",
                    "target_sid": "$targetXid",
                    "message": "$message"
                }
            """.trimIndent()

            !imageUrl.isNullOrEmpty() -> """
                {
                    "type": "send_image",
                    "sid": "$userSid",
                    "xid": "$userId",
                    "target_sid": "$targetXid",
                    "image": "$imageUrl"
                }
            """.trimIndent()

            else -> return
        }
        try {
            val isSent = webSocket.send(jsonMessage)
            if (isSent) {
                Log.d("WebSocket", "Connect message sent successfully")
            } else {
                Log.e("WebSocket", "Failed to send connect message")
            }
            Log.d("WebSocketService", "Sent: $jsonMessage")
        } catch (e: Exception) {
            Log.e("WebSocketService", "Error sending message: ${e.message}")
        }
    }

    private fun createNotification(): Notification {
        val notificationIntent = Intent(this, ChatActivity::class.java)
        val pendingIntent =
            PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, "websocket_channel")
            .setContentTitle("聊天服務")
            .setContentText("正在保持連線...")
            .setSmallIcon(R.drawable.ic_notification) // 確保此圖標存在
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "websocket_channel",
                "WebSocket Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private inner class EchoWebSocketListener : WebSocketListener() {
        var isWebSocketClosed = false
        private var reconnectAttempts = 0

        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d("WebSocket", "Connected")
            val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
            val sid = sharedPref.getString("sid", "") ?: ""

            isWebSocketClosed = false
            val connectMessage = """
                {
                    "type": "connect",
                    "sid": "$sid"
                }
            """.trimIndent()
            println(connectMessage)
            val isSent = webSocket.send(connectMessage)
            if (isSent) {
                Log.d("WebSocket", "Connect message sent successfully")
            } else {
                Log.e("WebSocket", "Failed to send connect message")
            }
           // startHeartbeat(webSocket)
        }



        override fun onMessage(webSocket: WebSocket, text: String) {
            Log.d("WebSocket", "Received message: $text")
            try {
                val jsonObject = JSONObject(text)
                val type = jsonObject.getString("type")
                val sid = jsonObject.getString("sid")
                val userSid = jsonObject.getString("user_sid")
                val name = jsonObject.getString("name")
                val figure = jsonObject.getString("figure")
                val message = jsonObject.optString("message", null)
                val messageHint = jsonObject.optString("message_hint", null)
                val fileList = jsonObject.optString("file_list", null)
                val timeLate = jsonObject.optString("time_late", null)
                val unread = jsonObject.optString("unread", null)
                val timeAdd = jsonObject.optString("time_add", null)

                // Create Intent and put data
                val intent = Intent("tw.ibiz.yukachat.MESSAGE_RECEIVED")
                intent.putExtra("type", type)
                intent.putExtra("sid", sid)
                intent.putExtra("user_sid", userSid)
                intent.putExtra("name", name)
                intent.putExtra("figure", figure)
                intent.putExtra("message", message)
                intent.putExtra("message_hint", messageHint)
                intent.putExtra("file_list", fileList)
                intent.putExtra("time_late", timeLate)
                intent.putExtra("unread", unread)
                intent.putExtra("time_add", timeAdd)

                // Use LocalBroadcastManager with the service context
                LocalBroadcastManager.getInstance(this@WebSocketService).sendBroadcast(intent)
                Log.d("WebSocket", "Broadcast sent: type=$type, sid=$sid")
            } catch (e: Exception) {
                Log.e("WebSocket", "Error parsing message: ${e.message}")
            }
        }


        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.d("WebSocket", "Closing: $code / $reason")
            isWebSocketClosed = true
            handler.removeCallbacksAndMessages(null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.d("WebSocket", "Closed: $code / $reason")
            isWebSocketClosed = true
            handler.removeCallbacksAndMessages(null)
        }

        // 新增重連相關常數
        private val MAX_RECONNECT_ATTEMPTS = 50000
        private val INITIAL_RECONNECT_DELAY = 2000L // 初始2秒延遲
        private val MAX_RECONNECT_DELAY = 30000L // 最大30秒延遲

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e("WebSocket", "Error: ${t.message}")
            isWebSocketClosed = true
            handler.removeCallbacksAndMessages(null)

            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                // 使用指數退避算法計算延遲時間
                val delay = min(
                    INITIAL_RECONNECT_DELAY * (1 shl reconnectAttempts),
                    MAX_RECONNECT_DELAY
                )

                Log.d("WebSocket", "Attempting to reconnect (${reconnectAttempts + 1}/$MAX_RECONNECT_ATTEMPTS) " +
                        "after ${delay/1000} seconds")

                handler.postDelayed({
                    if (isWebSocketClosed && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                        reconnectAttempts++
                        connectWebSocket(userId)
                        Log.d("WebSocket", "Reconnect attempt: $reconnectAttempts")
                    }
                }, delay)
            } else {
                Log.e("WebSocket", "Max reconnection attempts ($MAX_RECONNECT_ATTEMPTS) reached. Giving up.")
                // 可選擇停止服務或執行其他清理工作
                // stopSelf()
            }
        }
/*
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e("WebSocket", "Error: ${t.message}")
            isWebSocketClosed = true
            handler.removeCallbacksAndMessages(null)
            connectWebSocket(userId) // 自動重連
        }
*/
        private fun startHeartbeat(webSocket: WebSocket) {
            handler.postDelayed(object : Runnable {
                override fun run() {
                    if (!isWebSocketClosed) {
                        //   webSocket.send("{\"type\":\"ping\"}")
                        //   Log.d("WebSocket", "Sent heartbeat")
                        handler.postDelayed(this, heartbeatInterval)
                    }
                }
            }, heartbeatInterval)
        }
    }
}