package tw.ibiz.yukachat

/*
Android 13 kotlin
config_ini.kt 常量檔案
ChatActivity
建立常量檔案，所有檔都可讀取
常量，
伺服器網址 abc.com
websocket.  abc.com:8080

// 使用 ConfigIni 中的常量
val serverUrl = ConfigIni.SERVER_URL
val websocketUrl = ConfigIni.WEBSOCKET_URL

// 使用變量
UserData.username = "user123"
UserData.password = "password123"

*/

object ConfigIni {
    //  const val SERVER_URL = "https://ims.yukaai.com/"
       const val SERVER_URL = "http://192.168.0.12/"

    //     const val WEBSOCKET_URL = "wss://ims.yukaai.com:8080/"
     const val WEBSOCKET_URL = "ws:///192.168.0.12:8080/"

    // 變量
    var username: String = ""
    var password: String = ""
    var xid: String = ""
}
