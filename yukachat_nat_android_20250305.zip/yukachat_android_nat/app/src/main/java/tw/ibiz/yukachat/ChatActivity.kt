package tw.ibiz.yukachat


/*

https://claude.ai/

ChatActivity 視圖名稱 findViewById
Android 13 kotlin com.stfalcon.chatkit okhttp
對話記錄，有文字與圖片，兩種記錄
呈現聊天列表，用戶頭像圖示，發送時間
頭像來自網址，頭像若不存在，則用系統頭像圖示

按鍵事件
從 api 取得 json 對話記錄 加入 對話列表陣列

文字 message
圖片 image_list
型態 type r接收 s發送
發送時間 time_add

單一對話的內容，文字 message 或圖片 image_list

http://192.168.0.12/im/app/api/?mode=target_message&xid=${xid}&target_xid=${target_xid}&property=${property}
莪得 json 結果
{"status":"succ","title":"","icon":"fa fa-info-circle","message":"","data":{"target":{"name":"sugoi","figure":"https:\/\/ims.yukaai.com\/archive\/user\/thumbnail\/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg"},"message":[{"id":"1","type":"s","message":"123","message_translate":null,"image_list":null,"time_add":"2024-10-11 00:20"},{"id":"4","type":"r","message":"ok","message_translate":"好的，將會為您處理。","image_list":null,"time_add":"2024-10-11 00:21"},{"id":"5","type":"s","message":null,"message_translate":null,"image_list":"https:\/\/ims.yukaai.com\/archive\/user\/thumbnail\/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg","time_add":"2024-10-12 00:21"}]}}

if status == "succ"
    解析 data json 對話 array
    記錄 加入 對話列表陣列

顯示對話列表

*/


import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.squareup.picasso.Picasso
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import okio.ByteString
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit


class ChatActivity : AppCompatActivity() {

    companion object {
        const val REQUEST_CODE_PERMISSIONS = 1002
    }

    private lateinit var webSocket: WebSocket

    private var currentPhotoPath: String? = null // 存储当前拍照的照片路径

    private lateinit var messagesList: MessagesList
    private lateinit var messagesAdapter: MessagesListAdapter<ChatMessage>
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var imageButton: ImageButton

    private val messageArray = ArrayList<ChatMessage>()
    private val userId = ConfigIni.xid // Replace with actual user ID
    private var targetXid = ""
    private var Xid = ""
    private val property = "all"
    // property: 空白 / all (只取得新的訊息, 取得最近全部訊息)

    //    private val httpClient = OkHttpClient()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    private val httpClient = OkHttpClient.Builder()
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        Xid = sharedPref.getString("xid", null).toString()

        // 从 Intent 中获取传递过来的 targetXid
        targetXid = intent.getStringExtra("targetXid").toString()

        println("Received targetXid: $targetXid")

        checkPermissions()

        // 连接 WebSocket
        connectWebSocket(Xid)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("ChatActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        // Initialize views
        messagesList = findViewById(R.id.messagesList)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        imageButton = findViewById(R.id.imageButton)

        // Setup image loader for avatars and images
        val imageLoader = ImageLoader { imageView, url, payload ->
            if (!url.isNullOrEmpty()) {
                Picasso.get().load(url).placeholder(R.drawable.default_avatar).into(imageView)
            } else {
                imageView.setImageResource(R.drawable.default_avatar)
            }
        }

        // Setup message adapter
        messagesAdapter = MessagesListAdapter(userId, imageLoader)
        messagesList.setAdapter(messagesAdapter)

        // 設置圖片按鈕點擊事件
        imageButton.setOnClickListener {
            showImagePickerDialog()
        }

        // 設置發送按鈕點擊事件
        sendButton.setOnClickListener {
            val text = messageInput.text.toString().trim()
            if (text.isNotEmpty()) {
                //  sendMessage(text, null)
                sendTextMessage(text.toString())
                messageInput.setText("")
            }
        }


        // Fetch messages
        fetchMessages()
    }


    private fun connectWebSocket(Xid: String) {
        val request = Request.Builder()
            .url("${ConfigIni.WEBSOCKET_URL}?xid=${Xid}")
            .build()

        Log.d("connectWebSocket", "${ConfigIni.WEBSOCKET_URL}?xid=${Xid}")

        val listener = EchoWebSocketListener()
        webSocket = httpClient.newWebSocket(request, listener)
    }

    private fun sendMessage(Xid: String, targetXid: String, message: String) {
        val jsonMessage = """
            {
                "type": "s",
                "xid": "$Xid",
                "target_xid": "$targetXid",
                "message": "$message"
            }
        """.trimIndent()

        webSocket.send(jsonMessage)
    }

    private inner class EchoWebSocketListener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d("WebSocket", "Connected")
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            Log.d("WebSocket", "Received message: $text")
            // 在这里处理接收到的消息，例如更新 UI
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            Log.d("WebSocket", "Received bytes: ${bytes.hex()}")
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.d("WebSocket", "Closing: $code / $reason")
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.d("WebSocket", "Closed: $code / $reason")
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e("WebSocket", "Error: ${t.message}")
        }
    }

    // 顯示圖片選擇對話框
    private fun showImagePickerDialog() {
        val options = arrayOf("拍照", "選擇圖片")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("選擇圖片來源")
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> takePhoto() // 拍照
                1 -> showImagePicker() // 選擇圖片
            }
        }
        builder.show()
    }

    // 顯示圖片選擇選單
    private fun showImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        selectImageLauncher.launch(intent)
    }

    // 註冊圖片選擇的 ActivityResultLauncher
    private val selectImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                data?.data?.let { uri ->
                    val bitmap = getBitmapFromUri(uri)
                    bitmap?.let {
                        uploadImage(it)
                    }
                }
            }
        }

    /*
    Android 13 kotlin
    fun uploadImage(bitmap: Bitmap)
    上傳圖檔到伺服 upload.php 圖檔保存在 images 目錄
    依時間命名
    回傳 json 圖檔訪問網址
    */

    private fun uploadImage(bitmap: Bitmap) {
        val cacheFile = File(cacheDir, "upload.jpg")
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos)
        val bitmapData = bos.toByteArray()

        val fos = FileOutputStream(cacheFile)
        fos.write(bitmapData)
        fos.flush()
        fos.close()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                cacheFile.name,
                cacheFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            )
            .build()

        val request = Request.Builder()
            .url("${ConfigIni.SERVER_URL}upload.php")
            .post(requestBody)
            .build()

        // val client = OkHttpClient()
        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                Log.e("uploadImage", "Upload failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                if (response.isSuccessful) {
                    try {
                        val json = responseBody?.let { JSONObject(it) }
                        Log.d("uploadImage", json.toString())
                        val imageUrl = json?.getString("imageUrl")
                        Log.d("uploadImage", "Upload successful, image URL: $imageUrl")
                        // 在主线程中更新UI
                        runOnUiThread {
                            sendImageMessage(imageUrl.toString())
                        }
                        // 在這裡處理 imageUrl
                    } catch (e: Exception) {
                        Log.e("uploadImage", "Error parsing JSON: ${e.message}")
                    }
                } else {
                    Log.e(
                        "uploadImage",
                        "Upload failed, response code: ${response.code}, body: $responseBody"
                    )
                }
            }
        })
    }


    // 將 Uri 轉換為 Bitmap
    private fun getBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }


    // 拍照並存儲到暫存檔案
    @SuppressLint("QueryPermissionsNeeded")
    private fun takePhoto() {
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: IOException) {
            Log.e("ChatActivity", "Error creating file: ${ex.message}")
            null
        }
        photoFile?.also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                it
            )
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            if (intent.resolveActivity(packageManager) != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                takePhotoLauncher.launch(intent)
            } else {
                Toast.makeText(this, "找不到相機應用", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 拍照後處理
    private val takePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                currentPhotoPath?.let { path ->
                    val bitmap = BitmapFactory.decodeFile(path)
                    uploadImage(bitmap)
                }
            }
        }

    // 建立暫存檔案
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun fetchMessages() {
        CoroutineScope(Dispatchers.IO).launch {
            try {

                val url: String =
                    "${ConfigIni.SERVER_URL}im/app/api/?mode=target_message&xid=${Xid}&target_xid=${targetXid}&property=${property}"
                val request = Request.Builder().url(url).build()

                Log.d("ChatActivity", url)

                httpClient.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string()
                    responseBody?.let {
                        parseMessages(it)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun checkPermissions() {
        val requiredPermissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_MEDIA_IMAGES
        )

        val permissionsToRequest = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest, REQUEST_CODE_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                // 所有權限已經授予
                Log.d("ChatActivity", "所有權限已經授予")
            } else {
                // 權限被拒絕
                //  Toast.makeText(this, "權限被拒絕", Toast.LENGTH_SHORT).show()
                Log.d("ChatActivity", "權限被拒絕")
            }
        }
    }


    private suspend fun parseMessages(jsonResponse: String) {
        withContext(Dispatchers.Main) {
            try {
                Log.d("parseMessages", jsonResponse)
                val jsonObject = JSONObject(jsonResponse)
                val status = jsonObject.getString("status")

                if (status == "succ") {
                    val data = jsonObject.getJSONObject("data")
                    Log.d("data.toString()", data.toString())
                    Log.d("data.toString()", data.toString().length.toString())
                    if (data.toString().length > 10) {
                        val target = data.getJSONObject("target")
                        val targetName = target.getString("name")
                        val targetFigure = target.getString("figure")
                        val messagesArray = data.getJSONArray("message")

                        for (i in 0 until messagesArray.length()) {
                            val messageObj = messagesArray.getJSONObject(i)
                            val id = messageObj.getString("id")
                            val type = messageObj.getString("type")
                            val message =
                                if (messageObj.isNull("message")) null else messageObj.getString("message")
                            val imageList =
                                if (messageObj.isNull("image_list")) null else messageObj.getString(
                                    "image_list"
                                )
                            val timeAdd = messageObj.getString("time_add")

                            val date = dateFormat.parse(timeAdd) ?: Date()
                            val authorId = if (type == "s") userId else targetXid
                            val authorName = if (type == "s") "You" else targetName
                            val authorAvatar = if (type == "s") "" else targetFigure

                            // Create message object based on type (text or image)
                            val chatMessage = if (imageList != null) {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    null,
                                    imageList,
                                    date
                                )
                            } else {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    message ?: "",
                                    null,
                                    date
                                )
                            }
                            messageArray.add(chatMessage)
                        }

                        // Add all messages to adapter
                        messagesAdapter.addToEnd(messageArray, true)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun sendTextMessage(text: String) {
        // In a real app, you would send this to your server
        // For now, just add it to the local list
        sendMessage(Xid, targetXid, text)

        val message = ChatMessage(
            UUID.randomUUID().toString(),
            userId,
            "You",
            "",
            text,
            null,
            Date()
        )

        messagesAdapter.addToStart(message, true)

        // TODO: Send message to server
    }

    // Function to send image message (if needed)
    private fun sendImageMessage(imageUrl: String) {

        sendMessage(Xid, targetXid, imageUrl)

        val message = ChatMessage(
            UUID.randomUUID().toString(),
            userId,
            "You",
            "",
            null,
            imageUrl,
            Date()
        )

        messagesAdapter.addToStart(message, true)

        // TODO: Send image to server
    }
}