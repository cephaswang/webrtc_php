<?php

header('Content-Type: text/html; charset=utf-8');
// 設定回應的 Content-Type 為 JSON
header('Content-Type: application/json');

// 檢查 mode 參數是否為 target_message
if (isset($_GET['mode']) && $_GET['mode'] === 'target_list') {

        // 模擬的 JSON 資料
        $response = [
            "data" => [
                [
                    "late_message" => "ok2",
                    "target_figure" => "https://ims.yukaai.com/archive/user/thumbnail/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg",
                    "target_gender" => "m",
                    "target_name" => "sugoi",
                    "target_xid" => "98F1o2L7qyif8r240621000529",
                    "time_late" => "2024-10-31 00:54:27",
                    "unread" => 0
                ],
                [
                    "late_message" => "請問現在方便嗎",
                    "target_figure" => "https://ims.yukaai.com/archive/user/thumbnail/QV9wcm9mZXNzaW9uYWxfaGVhZHNob3Rfb2ZfYV9tYW5fbmFtZWRfV2VpLVJlbl9DaGUuMDE2ODQxMDc3.jpg",
                    "target_gender" => "m",
                    "target_name" => "鄒偉仁",
                    "target_xid" => "EyL5RGOU6QaQE5240715093239",
                    "time_late" => null,
                    "unread" => 0
                ]
            ],
            "icon" => "fa fa-info-circle",
            "message" => "",
            "status" => "succ",
            "title" => ""
        ];

        // 將陣列轉換為 JSON 並輸出
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// 檢查 mode 參數是否為 target_message
if (isset($_GET['mode']) && $_GET['mode'] === 'target_message') {


        // 模擬資料庫或邏輯處理
        $response = [
            "status" => "succ",
            "title" => "",
            "icon" => "fa fa-info-circle",
            "message" => "",
            "data" => [
                "target" => [
                    "name" => "sugoi",
                    "figure" => "https://ims.yukaai.com/archive/user/thumbnail/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg"
                ],
                "message" => [
                    [
                        "id" => "1",
                        "type" => "s",
                        "message" => "123",
                        "message_translate" => null,
                        "image_list" => null,
                        "time_add" => "2024-10-11 00:20"
                    ],
                    [
                        "id" => "4",
                        "type" => "r",
                        "message" => "ok",
                        "message_translate" => "好的，將會為您處理。",
                        "image_list" => null,
                        "time_add" => "2024-10-11 00:21"
                    ],
                    [
                        "id" => "5",
                        "type" => "s",
                        "message" => null,
                        "message_translate" =>null,
                        "image_list" => "https://ims.yukaai.com/archive/user/thumbnail/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg",
                        "time_add" => "2024-10-12 00:21"
                    ]
                            ]
            ]
        ];

    // 將回應轉為 JSON 格式並輸出
    echo json_encode($response, JSON_UNESCAPED_UNICODE);

    // 结束脚本
    exit;

    }
?>
