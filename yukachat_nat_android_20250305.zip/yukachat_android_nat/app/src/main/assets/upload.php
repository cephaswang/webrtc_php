<?php
header('Content-Type: application/json');


// 設定上傳目錄
$uploadDir = 'images/';

// 確保上傳目錄存在
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// 檢查是否有檔案上傳
if (isset($_FILES['file'])) {
    $file = $_FILES['file'];

    // 檢查上傳是否出錯
    if ($file['error'] === UPLOAD_ERR_OK) {
        $filename = $file['name']; // 假設 $file['name'] 包含檔案名稱
        $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
        $fileName = uniqid() . '.' .  $file_extension; // 使用唯一名稱
        $filePath = $uploadDir . $fileName;

        // 移動上傳的檔案到目標目錄
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            // 成功上傳，回傳檔案訪問網址
            $fileUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $filePath; // 根據您的伺服器配置調整
            $response = array('imageUrl' => $fileUrl);
            echo json_encode($response);
        } else {
            // 移動檔案失敗
            http_response_code(500);
            echo json_encode(array('error' => 'Failed to move uploaded file.'));
        }
    } else {
        // 上傳出錯
        http_response_code(400);
        echo json_encode(array('error' => 'Upload error: ' . $file['error']));
    }
} else {
    // 沒有檔案上傳
    http_response_code(400);
    echo json_encode(array('error' => 'No file uploaded.'));
}
?>
