import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okio.ByteString
import java.util.concurrent.TimeUnit

class ChatDemoActivity : AppCompatActivity() {

    private lateinit var webSocket: WebSocket
    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button
    private var surfaceControl: Any? = null

    private val client = OkHttpClient.Builder()
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_demo)

        // 获取传递的参数
        val targetXid = "targetXid"//intent.getStringExtra("targetXid").toString()
        val Xid = "Xid" //intent.getStringExtra("Xid").toString()

        // 初始化视图
        editTextMessage = findViewById(R.id.editTextMessage)
        buttonSend = findViewById(R.id.buttonSend)

        // 获取 DecorView 的 SurfaceControl
        val decorView = window.decorView
        surfaceControl = getSurfaceControl(decorView)

        // 连接 WebSocket
        connectWebSocket(Xid)

        // 发送消息
        buttonSend.setOnClickListener {
            val message = editTextMessage.text.toString()
            if (message.isNotEmpty()) {
                sendMessage(Xid, targetXid, message)
                editTextMessage.text.clear()
            }
        }
    }

    private fun connectWebSocket(Xid: String) {
        val request = Request.Builder()
            .url("${ConfigIni.WEBSOCKET_URL}?xid=${Xid}")
            .build()

        Log.d("connectWebSocket","${ConfigIni.WEBSOCKET_URL}?xid=${Xid}")

        val listener = EchoWebSocketListener()
        webSocket = client.newWebSocket(request, listener)

        // 启动 InteractionJankMonitor 监控
        beginInteractionJankMonitoring(surfaceControl, "WebSocketConnection")
    }

    private fun sendMessage(Xid: String, targetXid: String, message: String) {
        val jsonMessage = """
            {
                "type": "s",
                "xid": "$Xid",
                "target_xid": "$targetXid",
                "message": "$message"
            }
        """.trimIndent()

        Log.d("sendMessage",jsonMessage)

        webSocket.send(jsonMessage)

        // 启动 InteractionJankMonitor 监控
        beginInteractionJankMonitoring(surfaceControl, "SendMessage")
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocket.close(1000, "Activity destroyed")
        endInteractionJankMonitoring("WebSocketConnection")
        client.dispatcher.executorService.shutdown()
    }

    /**
     * 获取 SurfaceControl
     */
    private fun getSurfaceControl(decorView: View): Any? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val getSurfaceControlMethod = View::class.java.getMethod("getSurfaceControl")
                getSurfaceControlMethod.invoke(decorView)
            } catch (e: Exception) {
                Log.e("InteractionJankMonitor", "Failed to get SurfaceControl: ${e.message}")
                null
            }
        } else {
            Log.w("InteractionJankMonitor", "SurfaceControl requires Android 11 (API 30) or higher")
            null
        }
    }

    /**
     * 启动 InteractionJankMonitor 监控
     */
    private fun beginInteractionJankMonitoring(surfaceControl: Any?, cujName: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            Log.w("InteractionJankMonitor", "Requires Android 12 (API 31) or higher")
            return
        }

        if (surfaceControl == null) {
            Log.e("InteractionJankMonitor", "SurfaceControl is null")
            return
        }

        try {
            // 获取 InteractionJankMonitor 实例
            val interactionJankMonitorClass = Class.forName("com.android.internal.jank.InteractionJankMonitor")
            val getInstanceMethod = interactionJankMonitorClass.getMethod("getInstance")
            val interactionJankMonitor = getInstanceMethod.invoke(null)

            // 获取 Configuration.Builder 类
            val configBuilderClass = Class.forName("com.android.internal.jank.InteractionJankMonitor\$Configuration\$Builder")
            val withSurfaceMethod = configBuilderClass.getMethod("withSurface", surfaceControl::class.java, String::class.java)
            val configBuilder = withSurfaceMethod.invoke(null, surfaceControl, cujName)

            // 构建 Configuration
            val buildMethod = configBuilderClass.getMethod("build")
            val config = buildMethod.invoke(configBuilder)

            // 调用 begin 方法
            val beginMethod = interactionJankMonitorClass.getMethod("begin", config::class.java)
            beginMethod.invoke(interactionJankMonitor, config)
        } catch (e: Exception) {
            Log.e("InteractionJankMonitor", "Failed to begin monitoring: ${e.message}")
        }
    }

    /**
     * 停止 InteractionJankMonitor 监控
     */
    private fun endInteractionJankMonitoring(cujName: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            Log.w("InteractionJankMonitor", "Requires Android 12 (API 31) or higher")
            return
        }

        try {
            // 获取 InteractionJankMonitor 实例
            val interactionJankMonitorClass = Class.forName("com.android.internal.jank.InteractionJankMonitor")
            val getInstanceMethod = interactionJankMonitorClass.getMethod("getInstance")
            val interactionJankMonitor = getInstanceMethod.invoke(null)

            // 调用 end 方法
            val endMethod = interactionJankMonitorClass.getMethod("end", String::class.java)
            endMethod.invoke(interactionJankMonitor, cujName)
        } catch (e: Exception) {
            Log.e("InteractionJankMonitor", "Failed to end monitoring: ${e.message}")
        }
    }

    private inner class EchoWebSocketListener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d("WebSocket", "Connected")
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            Log.d("WebSocket", "Received message: $text")
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            Log.d("WebSocket", "Received bytes: ${bytes.hex()}")
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Log.d("WebSocket", "Closing: $code / $reason")
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.d("WebSocket", "Closed: $code / $reason")
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e("WebSocket", "Error: ${t.message}")
        }
    }
}