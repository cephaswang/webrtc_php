<?php
require_once 'vendor/autoload.php';

use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;

// 設定
$serviceAccountPath = 'pvKey.json'; // 替換為您的服務帳戶金鑰檔案路徑
$deviceToken = 'dlY1ijdAQBW4zGW4Ra9O5u:APA91bFJBNenVIB-fepb_qw5W23wBbtVBSRL-cGVF4t11Vv_Jm_-OalP9733SNNRgZzRifNNX4Hnfp3iMGEa2EAnZbspRuK8MB_u9FM_jNn81VYi67h_h1E';

// 檢查檔案是否存在
if (!file_exists($serviceAccountPath)) {
    echo "錯誤: 服務帳戶金鑰檔案不存在: $serviceAccountPath\n";
    echo "請到 Firebase Console > 專案設定 > 服務帳戶 > 產生新的私密金鑰\n";
    exit(1);
}

try {
    // 初始化 Firebase
    $factory = (new Factory)->withServiceAccount($serviceAccountPath);
    $messaging = $factory->createMessaging();

    // 測試 1: 最基本的通知
    echo "=== 測試基本通知 ===\n";
    $message = CloudMessage::withTarget('token', $deviceToken)
        ->withNotification(Notification::create('測試標題', '測試內容'));

    $result = $messaging->send($message);
    echo "✅ 發送成功: " . $result . "\n\n";

    // 測試 2: 帶數據的通知
    echo "=== 測試帶數據的通知 ===\n";
    $message = CloudMessage::withTarget('token', $deviceToken)
        ->withNotification(Notification::create('新鮮水果到貨', '今日新鮮蘋果、橘子已到貨！'))
        ->withData([
            'type' => 'fruit_arrival',
            'timestamp' => date('Y-m-d H:i:s')
        ]);

    $result = $messaging->send($message);
    echo "✅ 發送成功: " . $result . "\n\n";

    // 測試 3: 只發送數據（靜默）
    echo "=== 測試靜默數據消息 ===\n";
    $message = CloudMessage::withTarget('token', $deviceToken)
        ->withData([
            'action' => 'silent_update',
            'version' => '1.0.1'
        ]);

    $result = $messaging->send($message);
    echo "✅ 發送成功: " . $result . "\n\n";

    echo "🎉 所有測試完成！\n";

} catch (Exception $e) {
    echo "❌ 錯誤: " . $e->getMessage() . "\n";

    // 提供更詳細的錯誤信息
    if (strpos($e->getMessage(), 'service account') !== false) {
        echo "\n💡 建議:\n";
        echo "1. 確認服務帳戶金鑰檔案路徑正確\n";
        echo "2. 確認服務帳戶有 Firebase Messaging 權限\n";
        echo "3. 確認 JSON 檔案格式正確\n";
    }

    if (strpos($e->getMessage(), 'token') !== false) {
        echo "\n💡 建議:\n";
        echo "1. 確認設備 token 格式正確\n";
        echo "2. 確認 token 尚未過期\n";
        echo "3. 確認 token 屬於正確的 Firebase 專案\n";
    }
}
?>