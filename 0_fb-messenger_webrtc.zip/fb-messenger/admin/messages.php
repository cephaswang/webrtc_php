<?php
    require __DIR__. '../../core/init.php';
    if(!$userObj->isLoggedIn()){
		$userObj->redirect('index.php');
	}else if($user->isAdmin !== "true"){
      $userObj->redirect('index.php');
   }

    // Define pagination variables
    $limit = 5; // Number of messages per page
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // Get messages and total count
    $messages = $dashboardObj->getRecentMessages($limit, $offset);
    $totalMessages = $dashboardObj->getTotalMessages();
    $totalPages = ceil($totalMessages / $limit);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="<?php echo BASE_URL.'assets/js/jquery.min.js';?>"></script>
   <title>Messages - Admin Panel <?php echo $site->title;?></title>
   <script>
    const appUrl = "<?php echo BASE_URL;?>";
   </script>
</head>
<body>
    <!-- Modal (hidden by default) -->
<div id="editUserModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden z-10">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-lg w-full relative">
        <!-- Close button -->
        <button id="closeModal" class="absolute top-0 right-0 mt-2 mr-2 text-gray-700 text-2xl">&times;</button>
        
        <!-- Modal content -->
        <h2 class="text-xl font-bold mb-4">Edit User</h2>
        
        <!-- Error messages -->
        <div id="errorMessages" class="bg-red-100 text-red-500 p-2 rounded mb-4 hidden"></div>
        
        <!-- Success message -->
        <div id="successMessage" class="bg-green-100 text-green-500 p-2 rounded mb-4 hidden">User updated successfully!</div>

        <!-- Form -->
        <form id="editUserForm" enctype="multipart/form-data">
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Name</label>
                <input type="text" id="name" name="name" class="w-full px-3 py-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Username</label>
                <input type="text" id="username" name="username" class="w-full px-3 py-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Email</label>
                <input type="email" id="email" name="email" class="w-full px-3 py-2 border rounded" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Password</label>
                <input type="password" id="password" name="password" class="w-full px-3 py-2 border rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Role</label>
                <select name="role" class="w-full px-3 py-2 border rounded">
                    <option value="user" id="userRole">User</option>
                    <option value="admin" id="adminRole">Admin</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Image</label>
                <img src="" id="previewImage" class="w-40 h-40 mb-2" />
                <input type="file" id="image" name="image" class="w-full px-3 py-2 border rounded">
            </div>

            <!-- Save button -->
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Save</button>
        </form>
    </div>
</div>
 <!-- This is an example component -->
<div>
<nav class="fixed z-30 w-full bg-gradient-to-r from-black to-green-700 border-b border-gray-700 text-white shadow-lg transition-all duration-150 ease-in-out">
   <div class="px-4 py-3 lg:px-5 lg:pl-3">
      <div class="flex items-center justify-between">
         <div class="flex items-center">
            <a href="<?php echo BASE_URL.'admin/dashboard/'?>" class="text-2xl font-bold flex items-center lg:ml-2.5">
               <span class="self-center whitespace-nowrap"><?php echo $site->title;?></span>
            </a> 
         </div>
      </div>
   </div>
</nav>
   <div class="flex overflow-hidden bg-white pt-16">
   <aside id="sidebar" class="fixed z-20 h-full top-0 left-0 pt-16 lg:flex flex-shrink-0 flex-col w-64 transition-width duration-75 bg-gradient-to-b from-black to-green-800 text-white" aria-label="Sidebar">
    <div class="relative flex-1 flex flex-col min-h-0 border-r border-blue-700 shadow-lg">
        <div class="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <div class="flex-1 px-3 space-y-5">
                <ul class="space-y-5 pb-4">
                    <li>
                        <a href="<?php echo BASE_URL;?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-pager group-hover:text-white"></i>
                            <span class="ml-3">View site</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL.'admin/dashboard/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                             <i class="w-4 h-6 text-gray-200 flex-shrink-0  fa-solid fa-gauge group-hover:text-white"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/users/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-users group-hover:text-white"></i>
                            <span class="ml-3">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/messages/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-regular fa-comments group-hover:text-white"></i>
                            <span class="ml-3">Messages</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/add/user/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-plus group-hover:text-white"></i>
                            <span class="ml-3">Create User</span>
                        </a>
                    </li>
                </ul>
                <h1 class="flex items-center text-base font-semibold rounded-lg">Settings</h1>
                <div class="space-y-3 pt-4">
                    <a href="<?php echo BASE_URL . 'admin/settings/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-gears group-hover:text-white"></i>
                        <span class="ml-3">Settings</span>
                    </a>
                    <a href="<?php echo BASE_URL . 'admin/profile/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-regular fa-address-card group-hover:text-white"></i>
                        <span class="ml-3">Profile</span>
                    </a>
                    <a href="<?php echo BASE_URL . 'logout.php';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-right-from-bracket group-hover:text-white"></i>
                         <span class="ml-3">Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</aside>
<div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
<div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
<main class="w-full p-4">
        
          <!-- User Table -->
          <div class="overflow-x-auto bg-white shadow-md rounded-lg">
           <!-- Display Table with Messages -->
            <table class="table-auto border-collapse">
                <thead>
                    <tr>
                        <th class="px-6 py-2 text-xs text-gray-500">Message ID</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Sender Image</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Sender Username</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Message</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Recipient Image</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Recipient Username</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $message): ?>
                    <tr>
                        <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                            <div class="flex items-center space-x-2">
                                 <span><?php echo $message->ID; ?></span>
                            </div>
                        </td>
                        <td class="border px-20 py-2">
                            <img class="h-20 w-20 rounded-full" src="<?php echo BASE_URL . $message->senderImage; ?>">
                        </td>
                        <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                            <div class="flex items-center space-x-2">
                                 <span><?php echo htmlspecialchars($message->senderUsername); ?></span>
                            </div>
                        </td>
                        
                        <td class="border px-16 py-2 text-center whitespace-nowrap text-sm text-gray-500">
                            <?php if ($message->type === 'image'): ?>
                                <img class="h-24 w-24 object-cover" src="<?php echo BASE_URL . $message->image; ?>">
                            <?php elseif ($message->type === 'voice'): ?>
                                <audio class="w-40 max-w-xs pt-1 rounded-3xl" controls><source src="<?php echo BASE_URL . $message->image; ?>" type="audio/wav"></audio>
                            <?php elseif ($message->type === 'like'): ?>
                                <span class="text-center text-lg text-blue-700 text-2xl"><i class="fb-color fas fa-thumbs-up"></i></span>
                            <?php else: ?>
                                <?php echo htmlspecialchars($message->message); ?>
                            <?php endif; ?>
                        </td>
                        <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                            <div class="flex items-center space-x-2">
                                <img class="h-20 w-20 rounded-full" src="<?php echo BASE_URL . $message->recipientImage; ?>">
                             </div>
                        </td>
                        <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                            <div class="flex items-center space-x-2">
                                 <span><?php echo htmlspecialchars($message->recipientUsername); ?></span>
                            </div>
                        </td>
                        <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                            <div class="flex items-center space-x-2">
                            <button id="deleteBtn" data-id="<?php echo $message->ID;?>" class="text-red-600 hover:text-red-900 ml-4">Delete</button>

                            </div>
                        </td>
                  
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

          </div>

          <!-- Pagination -->
          <div class="flex justify-between items-center mt-2">
            <nav class="flex justify-center mt-4">
                    <ul class="flex space-x-2">
                        <!-- Previous Button -->
                        <li>
                            <a href="?page=<?= max(1, $page - 1) ?>" class="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Previous</a>
                        </li>
                        
                        <!-- Page Numbers -->
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li>
                                <a href="?page=<?= $i ?>" class="px-3 py-2 <?= $page == $i ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700' ?> rounded hover:bg-gray-300">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <!-- Next Button -->
                        <li>
                            <a href="?page=<?= min($totalPages, $page + 1) ?>" class="px-3 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Next</a>
                        </li>
                    </ul>
                </nav>
          </div>
        </main>
        <footer class="bg-white md:flex md:items-center md:justify-between shadow rounded-lg p-4 md:p-6 xl:p-8 my-6 mx-4">
        <ul class="flex items-center flex-wrap mb-6 md:mb-0">
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Terms and conditions</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Privacy Policy</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Licensing</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Cookie Policy</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline">Contact</a></li>
        </ul>
        </footer>
    </div>
</div>
</div>
<script>
//Delete
$(document).on('click','#deleteBtn', function(e) {
    e.preventDefault();
    // Collect form data
    if(confirm("Are you sure, you want to delete this message?")){
        const formData = new FormData();
        formData.append('messageID', $(this).data('id'))
        $.ajax({
            url: `${appUrl}core/ajax/deleteMessage.php`,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(data) {
                if (data.success) {
                    alert('The message has deleted successfully');
                    location.reload(true);
                } else {
                    alert('Failed: Something went wront with the request');
                    location.reload(true);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }
});
</script>
</body>
</html>