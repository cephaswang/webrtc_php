<?php
    require __DIR__. '../../core/init.php';
    if(!$userObj->isLoggedIn()){
		$userObj->redirect('index.php');
	}else if($user->isAdmin !== "true"){
      $userObj->redirect('index.php');
   }

   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $title         = trim(stripcslashes(htmlentities($_POST['title'])));
        $url           = trim(stripcslashes(htmlentities($_POST['url'])));
        $description    = trim(stripcslashes(htmlentities($_POST['description'])));
          
        if($user){
            if(!empty($title) && !empty($url) && !empty($description)){
                // Validate the URL
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    $error =  "Invalid URL";
                    exit;
                }

                // Validate title
                if (strlen($title) < 5 || strlen($title) > 100) {
                    $error =  "Invalid title. Title must be between 5 and 100 characters.";
                    exit;
                }

                // Validate description
                if (strlen($description) < 10 || strlen($description) > 500) {
                    $error =  "Invalid description. Description must be between 10 and 500 characters.";
                    exit;
                }

                // Remove trailing slash if present
                $url = rtrim($url, '/');

                // Add a trailing slash
                $url .= '/'; 
                if (empty($error)) {
                    $userObj->update('settings',   ['title'       => $title,
                                                    'description' => $description, 
                                                    'url'         => $url], 
                                                    ['ID' => "1"]);
                    
                    $userObj->redirect('admin/settings/');
                }
             
            }else{
                $errors[] = 'All fields are requried!';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="<?php echo BASE_URL.'assets/js/jquery.min.js';?>"></script>
   <title>Settings - Admin Panel <?php echo $site->title;?></title>
   <script>
    const appUrl = "<?php echo BASE_URL;?>";
   </script>
</head>
<body>
<div>
<nav class="fixed z-30 w-full bg-gradient-to-r from-black to-green-700 border-b border-gray-700 text-white shadow-lg transition-all duration-150 ease-in-out">
   <div class="px-4 py-3 lg:px-5 lg:pl-3">
      <div class="flex items-center justify-between">
         <div class="flex items-center">
            <a href="<?php echo BASE_URL.'dashboard.php'?>" class="text-2xl font-bold flex items-center lg:ml-2.5">
               <span class="self-center whitespace-nowrap"><?php echo $site->title;?></span>
            </a> 
         </div>
      </div>
   </div>
</nav>
   <div class="flex overflow-hidden bg-white pt-16">
   <aside id="sidebar" class="fixed z-20 h-full top-0 left-0 pt-16 lg:flex flex-shrink-0 flex-col w-64 transition-width duration-75 bg-gradient-to-b from-black to-green-800 text-white" aria-label="Sidebar">
    <div class="relative flex-1 flex flex-col min-h-0 border-r border-blue-700 shadow-lg">
        <div class="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <div class="flex-1 px-3 space-y-5">
                <ul class="space-y-5 pb-4">
                    <li>
                        <a href="<?php echo BASE_URL;?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-pager group-hover:text-white"></i>
                            <span class="ml-3">View site</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL.'admin/dashboard/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                             <i class="w-4 h-6 text-gray-200 flex-shrink-0  fa-solid fa-gauge group-hover:text-white"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/users/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-users group-hover:text-white"></i>
                            <span class="ml-3">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/messages/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-regular fa-comments group-hover:text-white"></i>
                            <span class="ml-3">Messages</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/add/user/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-plus group-hover:text-white"></i>
                            <span class="ml-3">Create User</span>
                        </a>
                    </li>
                </ul>
                <h1 class="flex items-center text-base font-semibold rounded-lg">Settings</h1>
                <div class="space-y-3 pt-4">
                    <a href="<?php echo BASE_URL . 'admin/settings/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-gears group-hover:text-white"></i>
                        <span class="ml-3">Settings</span>
                    </a>
                    <a href="<?php echo BASE_URL . 'admin/profile/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-regular fa-address-card group-hover:text-white"></i>
                        <span class="ml-3">Profile</span>
                    </a>
                    <a href="<?php echo BASE_URL . 'logout.php';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-right-from-bracket group-hover:text-white"></i>
                         <span class="ml-3">Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</aside>
     <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
        <main class="w-full p-4">
        <div class="w-4/6 mx-auto bg-white p-8 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-6">Settings</h2>
            <form method="POST">
                <!-- Username Field -->
                <div class="mb-4">
                    <label for="username" class="block text-gray-700 font-medium">Site Title</label>
                    <input type="text" id="title" name="title" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500" required  value="<?php echo isset($_POST['title']) ? trim(stripcslashes(htmlentities($_POST['title']))) : $site->title; ?>">
                </div>

                <!-- Name Field -->
                <div class="mb-4">
                    <label for="name" class="block text-gray-700 font-medium">Site Url</label>
                    <input type="text" id="url" name="url" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500" required  value="<?php echo isset($_POST['url']) ? trim(stripcslashes(htmlentities($_POST['url']))) : $site->url; ?>">
                </div>

                <!-- Email Field -->
                <div class="mb-4">
                    <label for="email" class="block text-gray-700 font-medium">Description</label>
                    <input type="text" id="description" name="description" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-500" required  value="<?php echo isset($_POST['description']) ? trim(stripcslashes(htmlentities($_POST['description']))) : $site->description; ?>">
                </div>
                <!-- Error -->
                 <?php if(isset($error)):?>
                    <div class="mb-4">
                        <span id="email-error" class="error-message text-red-500 text-sm"><?php echo $error;?></span>
                    </div>
                <?php endif;?>
                <!-- Submit Button -->
                <div>
                    <button type="submit" class="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 focus:outline-none focus:bg-blue-600">
                        Update
                    </button>
                </div>
            </form>
        </div>
        </main>
        <footer class="bg-white md:flex md:items-center md:justify-between shadow rounded-lg p-4 md:p-6 xl:p-8 my-6 mx-4">
        <ul class="flex items-center flex-wrap mb-6 md:mb-0">
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Terms and conditions</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Privacy Policy</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Licensing</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Cookie Policy</a></li>
            <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline">Contact</a></li>
        </ul>
        </footer>
    </div>
</div>
</div>
</body>
</html>