<?php
    require __DIR__. '../../core/init.php';
    if(!$userObj->isLoggedIn()){
		$userObj->redirect('index.php');
	}else if($user->isAdmin !== "true"){
      $userObj->redirect('index.php');
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
   <title>Dashboard - Admin Panel <?php echo $site->title;?></title>
</head>
<body>
 <!-- This is an example component -->
<div>
<nav class="fixed z-30 w-full bg-gradient-to-r from-black to-green-700 border-b border-gray-700 text-white shadow-lg transition-all duration-150 ease-in-out">
   <div class="px-4 py-3 lg:px-5 lg:pl-3">
      <div class="flex items-center justify-between">
         <div class="flex items-center">
            <a href="<?php echo BASE_URL.'dashboard.php'?>" class="text-2xl font-bold flex items-center lg:ml-2.5">
               <span class="self-center whitespace-nowrap"><?php echo $site->title;?></span>
            </a> 
         </div>
      </div>
   </div>
</nav>
   <div class="flex overflow-hidden bg-white pt-16">
   <aside id="sidebar" class="fixed z-20 h-full top-0 left-0 pt-16 lg:flex flex-shrink-0 flex-col w-64 transition-width duration-75 bg-gradient-to-b from-black to-green-800 text-white" aria-label="Sidebar">
    <div class="relative flex-1 flex flex-col min-h-0 border-r border-blue-700 shadow-lg">
        <div class="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            <div class="flex-1 px-3 space-y-5">
                <ul class="space-y-5 pb-4">
                    <li>
                        <a href="<?php echo BASE_URL;?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-pager group-hover:text-white"></i>
                            <span class="ml-3">View site</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL.'admin/dashboard/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                             <i class="w-4 h-6 text-gray-200 flex-shrink-0  fa-solid fa-gauge group-hover:text-white"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/users/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-users group-hover:text-white"></i>
                            <span class="ml-3">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/messages/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-regular fa-comments group-hover:text-white"></i>
                            <span class="ml-3">Messages</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo BASE_URL . 'admin/add/user/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                            <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-plus group-hover:text-white"></i>
                            <span class="ml-3">Create User</span>
                        </a>
                    </li>
                </ul>
                <h1 class="flex items-center text-base font-semibold rounded-lg">Settings</h1>
                <div class="space-y-3 pt-4">
                    <a href="<?php echo BASE_URL . 'admin/settings/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-gears group-hover:text-white"></i>
                        <span class="ml-3">Settings</span>
                    </a>
                    <a href="<?php echo BASE_URL . 'admin/profile/';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-regular fa-address-card group-hover:text-white"></i>
                        <span class="ml-3">Profile</span>
                    </a>
                    <a href="<?php echo BASE_URL . 'logout.php';?>" class="flex items-center p-3 text-base font-semibold rounded-lg hover:bg-green-700 transition duration-150 ease-in-out">
                        <i class="w-4 h-6 text-gray-200 flex-shrink-0 fa-solid fa-right-from-bracket group-hover:text-white"></i>
                         <span class="ml-3">Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</aside>

      <div class="bg-gray-900 opacity-50 hidden fixed inset-0 z-10" id="sidebarBackdrop"></div>
      <div id="main-content" class="h-full w-full bg-gray-50 relative overflow-y-auto lg:ml-64">
         <main>
            <div class="pt-6 px-4">
               
               <div class="mt-4 w-full grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  <div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 ">
                     <div class="flex items-center">
                        <div class="flex-shrink-0">
                           <span class="text-2xl sm:text-3xl leading-none font-bold text-gray-900"><?php echo $dashboardObj->getTotalUsers();?></span>
                           <h3 class="text-base font-normal text-gray-500">Users</h3>
                        </div>
                        <div class="ml-5 w-0 flex items-center justify-end flex-1 text-green-500 text-base font-bold">
                        Total
                        </div>
                     </div>
                  </div>
                  <div class="bg-white shadow rounded-lg p-4 sm:p-6 xl:p-8 ">
                     <div class="flex items-center">
                        <div class="flex-shrink-0">
                           <span class="text-2xl sm:text-3xl leading-none font-bold text-gray-900"><?php echo $dashboardObj->getTotalMessages();?></span>
                           <h3 class="text-base font-normal text-gray-500">Messages</h3>
                        </div>
                        <div class="ml-5 w-0 flex items-center justify-end flex-1 text-green-500 text-base font-bold">
                           Total
                        </div>
                     </div>
                  </div>
                  
               </div>
               <div class="grid grid-cols-1 2xl:grid-cols-2 xl:gap-4 my-4">
               <div class="bg-white shadow rounded-lg mb-4 p-4 sm:p-6 h-full">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-xl font-bold leading-none text-gray-900">Latest  
                Messages</h3>
                        <a href="#" class="text-sm font-medium text-cyan-600 hover:bg-gray-100 rounded-lg inline-flex items-center p-2">
                            View all
                        </a>
                    </div>
                    <div class="flow-root">  

                        <table class="table-auto  
                border-collapse">
                            <thead>
                                <tr>
                                    <th class="px-6 py-2 text-xs text-gray-500">Sender</th>
                                    <th class="px-6 py-2 text-xs text-gray-500">Message</th>
                                    <th class="px-6 py-2 text-xs text-gray-500">Recipient</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($dashboardObj->getRecentMessages(10,0) as $user):?>
                                <tr>
                                    <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                                        <div class="flex items-center space-x-2">
                                            <img class="h-8 w-8 rounded-full" src="<?php echo BASE_URL.$user->senderImage;?>">
                                            <span><?php echo $user->senderUsername;?></span>
                                        </div>
                                    </td>
                                    <td class="border px-16 py-2 text-center whitespace-nowrap text-sm text-gray-500">
                                        <?php if ($user->type === 'image'): ?>
                                            <img class="h-24 w-24 object-cover" src="<?php echo BASE_URL.$user->image;?>">
                                        <?php elseif ($user->type === 'voice'): ?>
                                            <audio class="w-40 max-w-xs pt-1 rounded-3xl" controls><source src="<?php echo BASE_URL.$user->voice;?>" type="audio/wav"></audio>
                                        <?php elseif ($user->type === 'like'): ?>
                                            <span class="text-center text-lg text-blue-700 text-2xl">
                                                <i class="fb-color fas fa-thumbs-up"></i>   
                                            </span>
                                        <?php else: ?>
                                            <?php echo $user->message;?>    
                                        <?php endif;?>
                                    </td>
                                    <td class="border px-20 py-2 whitespace-nowrap text-sm text-gray-500">
                                        <div class="flex items-center space-x-2">
                                            <img class="h-8 w-8 rounded-full" src="<?php echo BASE_URL.$user->recipientImage;?>">
                                            <span><?php echo $user->recipientUsername;?></span>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>

                  <div class="grid grid-cols-1 2xl:grid-cols-2 xl:gap-4 my-4">
                  <div class="bg-white shadow rounded-lg mb-4 p-4 sm:p-6 h-full">
                     <div class="flex items-center justify-between mb-4">
                        <h3 class="text-xl font-bold leading-none text-gray-900">Latest Users</h3>
                        <a href="#" class="text-sm font-medium text-cyan-600 hover:bg-gray-100 rounded-lg inline-flex items-center p-2">
                        View all
                        </a>
                     </div>
                     <div class="flow-root">
                        <ul role="list" class="divide-y divide-gray-200">
                            <?php foreach($dashboardObj->getRecentUsers() as $user):?>
                            <li class="py-3 sm:py-4">
                                <div class="flex items-center space-x-4">
                                    <div class="flex-shrink-0">
                                        <img class="h-8 w-8 rounded-full" src="<?php echo BASE_URL.$user->profileImage;?>" alt="<?php echo $user->name?>">
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium text-gray-900 truncate">
                                          <?php echo $user->name;?> @<?php echo $user->username;?>
                                        </p>
                                        <p class="text-sm text-gray-500 truncate">
                                        <p> <?php echo $user->email;?></p></p>
                                    </div>
                                    
                                </div>
                            </li>
                           <?php endforeach;?>
                        </ul>
                     </div>
                  </div>
                   
               </div>
               </div>
            </div>
         </main>
         <footer class="bg-white md:flex md:items-center md:justify-between shadow rounded-lg p-4 md:p-6 xl:p-8 my-6 mx-4">
            <ul class="flex items-center flex-wrap mb-6 md:mb-0">
               <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Terms and conditions</a></li>
               <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Privacy Policy</a></li>
               <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Licensing</a></li>
               <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline mr-4 md:mr-6">Cookie Policy</a></li>
               <li><a href="#" class="text-sm font-normal text-gray-500 hover:underline">Contact</a></li>
            </ul>
            
         </footer>
         
      </div>
   </div>
 
</div>
</body>
</html>