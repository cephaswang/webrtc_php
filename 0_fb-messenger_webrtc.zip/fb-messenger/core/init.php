<?php
	if ($_SERVER['REQUEST_URI'] !== 'installer.php') {
		header('Location: ' .'installer.php');
		exit();
	}
	// Start the session
	session_start();
	
  	// Require the necessary class files
 	require 'Config.php';
	require 'classes/DB.php';
	require 'classes/User.php';
	require 'classes/Messenger.php';
	require 'classes/Dashboard.php';
	
	// Create instances of the User and Messenger classes from the MyApp namespace
	// These instances can be used to access the methods and properties of the classes
	$userObj       = new \MyApp\User;
	$messageObj    = new \MyApp\Messenger;
	$dashboardObj  = new \MyApp\Dashboard;
	$site		   = $userObj->get('settings', ['ID' => '1']);
	$user          = $userObj->userData();
	//define the BASE_URL
	define("BASE_URL", $site->url);
 
	 
