<?php
	// include the core file
	include '../init.php';
	//check if user is loggedin
	if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
    // Handle the update request
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userID   = (int) $_POST['userID'];
        $name     = trim(stripcslashes(htmlentities($_POST['name'])));
        $username = trim(stripcslashes(htmlentities($_POST['username'])));
        $email    = trim(stripcslashes(htmlentities($_POST['email'])));
        $role     = trim(stripcslashes(htmlentities($_POST['role'])));
        $password = '';
        // get user from the database
        $user     = $userObj->get('users', ['userID' => $userID]);
        $image    = '';
        $errors = [];
        $success = false;
        // if user is exists in the database, then contiune to validation the inputs   
        if($user){
            if(!empty($name) && !empty($username) && !empty($email)){
                //Inputs validation    
                if($username !== $user->username){
                    if(strlen($username) < 4){
                        $errors[] = 'Choose a username 3-30 characters long';
                    }else if($userObj->usernameExist($username)){
                        $errors[] = 'Username is already taken';
                    }
                }else{
                    $username = $user->username;
                }
                if(!empty($_POST['password'])){
                    if(strlen($_POST['password']) <= 3){
                        $errors[] = "Password must be 3-30 characters long";
                    }
                }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                    $errors[] = "Invaild Email format!";

                }else if($user->email !== $email && $userObj->emailExist($email)){
                    $errors[] = "Email is already in use";

                }else{
                    // Image validation
                    if (!empty($_FILES['image']['name'])) {
                        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
                        $fileExtension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                        
                        if (!in_array($fileExtension, $allowedExtensions)) {
                            $errors[] = 'Invalid image format (allowed: jpg, jpeg, png, gif)';
                        }else{
                            $image  = $userObj->upload($_FILES['image']);
                         
                        }
                    }else{
                        $image = 'assets/images/avatar.png';
                    }
                    if (empty($errors)) {
                        // Update the user
                        $hash = !empty($password) ? $userObj->hash($password) : $user->password;
                        $role = $role === 'user' ? 'false' : 'true';
                        $id = $userObj->update('users', ['name'         => $name,
                                                         'username'     => $username, 
                                                         'email'        => $email, 
                                                         'password'     => $hash,
                                                         'profileImage' => $image,
                                                         'sessionID'    => 0, 
                                                         'connectionID' => 0,
                                                         'isAdmin' => $role], 
                                                        ['userID' => $user->userID]);
                        $success = true;
                    }
                }
            }else{
                $errors[] = 'All fields are requried!';
            }
        }
    }
    header('Content-Type: application/json');

    // Return JSON response
    echo json_encode([
        'success' => $success,
        'errors' => $errors
    ]);
?>
