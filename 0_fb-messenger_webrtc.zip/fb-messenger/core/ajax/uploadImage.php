<?php 
	// include the core file
	include '../init.php';
	//check if user is loggedin
	if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
	//Handle the Upload requesdt
	if($_SERVER['REQUEST_METHOD'] === "POST"){
		if(isset($_FILES['file'])){
			if(!empty($_FILES['file']['name'][0])){
				$userID   = $userObj->userID;
				// get user data
				$sentTo   = $userObj->userData($_POST['sentTo']);
				//check if we get the user data
				if(!empty($sentTo)){
					$file   = $userObj->upload($_FILES['file']);
					// check if image is uploaded
					if($file){
						//send message
						$messageObj->sendMessage('',$userID, $sentTo->userID, $file, 'image', '');
						//return response
						echo '{"status": "success", "message":"'.BASE_URL.$file.'"}';
					}else{
						echo '{"status": "error", "message":"'.$userObj->errors().'"}';
					}
				}
			}
		}
	}