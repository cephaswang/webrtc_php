<?php
    //include the core file
 	include '../init.php';
    //check if user is loggedin
    if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
    //Handle the delete request 
    if($_SERVER['REQUEST_METHOD'] === 'POST') {
         $userID =   $_POST['userID'];
         //check if user exists in the database
         $nUser  =   $userObj->get('users', ['userID' => $userID]);
        //check if current user is admin
        if($user->isAdmin === "true"){
            if($nUser){
               //delete the user
               $userObj->deleteUser( $nUser->userID);
               $success = true;
            }else{
                $success = true;
            }
            //return the json reponse to js file
            header('Content-Type: application/json');
            echo json_encode([
                'success' => $success
            ]);
            exit;
        }
    }
?>