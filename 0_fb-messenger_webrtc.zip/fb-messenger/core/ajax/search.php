<?php
	// include the core file
	include '../init.php';
	//check if user is loggedin
	if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
	//Handle the search request
	if($_SERVER['REQUEST_METHOD'] === "POST"){
		if(isset($_POST['search'])){
			$search = trim(stripcslashes(htmlentities($_POST['search'], ENT_QUOTES)));
			
			if(!empty($search)){
				//get search result
				$users = $userObj->search($search);
				// Display the return
				?>
				<h3 class="select-none font-bold text-5 py-2 p-2 m-2">Users</h3>
				<?php
				if(count($users) === 0){
					echo '<p class="font-bold text-4 text-center">No match found!</p>';
				}
				foreach($users as $user){
					echo '<li class="flex select-none items-center  
						           cursor-pointer rounded-lg p-3">
						    <a href="'.BASE_URL.$user->username.'/messages" class="flex-1">
						    <div class="flex-1 flex">
						        <div class="flex gap-x-2 items-center flex-1 flex-wrap ">
						            <div>
						                <img class="w-12 h-12 object-cover border-gray-400 border rounded-full" src="'.BASE_URL.$user->profileImage.'"/>
						            </div>
						            <div class="flex">
						                <div> 
						                    <div class="text-gray-800">
						                        <span style="font-size: .9375rem;">
						                        	'.$user->username.'
						                        </span>
						                    </div>
						                </div>
						            </div>
						        </div>
						    </div>
						    </a>
						</li>';
				}
			}
		}
	}