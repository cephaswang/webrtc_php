<?php
    //inlcude the core file 
 	include '../init.php';
    // check if user is not logged in 
     if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
    //handle the delete request
    if($_SERVER['REQUEST_METHOD'] === 'POST') {
         $messageID =   $_POST['messageID'];
         //get the message from database 
         $message  =   $userObj->get('messages', ['messageID' => $messageID]);
        //check if current user is admin
        if($user->isAdmin === "true"){
            if($message){
               $messageObj->deleteMessage($message->messageID);
               $success = true;
            }else{
                $success = true;
            }
            //Return Json response
            header('Content-Type: application/json');
            echo json_encode([
                'success' => $success
            ]);
            exit;
        }
    }
?>