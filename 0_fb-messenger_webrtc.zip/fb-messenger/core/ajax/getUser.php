<?php
    //include the core file
 	include '../init.php';
    //check if user is logged in 
    if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
    //Handle the get user request
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userID =   $_POST['userID'];
        //check if user is exists in the database
        $user   = $userObj->get('users', ['userID' => $userID]);
        //check if user is found
        if($user){
            $error = "";
            $success = true;
            $return = $user;
        }else{
            $error = "User is not found";
            $success = false;
            $return = '';
        }

        //Return the user data as json format
        header('Content-Type: application/json');
        echo json_encode([
            'success' => $success,
            'errors' => $error,
            'user' => $return
        ]);
        exit;
    }
?>