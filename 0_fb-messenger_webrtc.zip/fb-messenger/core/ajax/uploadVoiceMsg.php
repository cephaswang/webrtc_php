<?php 
    // include the core file
	include '../init.php';
	//check if user is loggedin
	if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }
    // Handle the request for voice message
    if(isset($_FILES['file']) and !$_FILES['file']['error']){
         $file       = $_FILES['file']['tmp_name'];
         $error      = $_FILES['file']['error'];
         $name       = $_FILES['file']['name'];
         $filename   = basename($name);
         $receiverID = $_POST['sendTo'];
         $user       = $userObj->userData();
         $sendTo     = $userObj->userData($receiverID);
        //check if get the user data
        if($user){
            if($sendTo){   
                if(!$error){
                if (mime_content_type($file) === 'audio/ogg') {
                    // Get the parent directory two levels above the current directory
                    $parentDirectory = dirname(dirname(dirname(__FILE__)));
                    //path to store voice messages 
                    $path = '/content/recordings/';
                    // Generate random filename
                    $filename = $path . md5(time() . mt_rand()) . '.wav';

                    //Try to upload the file
                    if (!move_uploaded_file($file, $parentDirectory . $filename)) {
                        // Error: Failed to move uploaded file
                        echo 'uploading error';
                    } else {
                        // Send message and display success message
                        $messageObj->sendMessage('', $user->userID, $sendTo->userID, '', 'voice', $filename);
                        $cleanPath = str_replace('/content/recordings/', 'content/recordings/', $filename);
                        echo '{"status": "success", "message":"' . BASE_URL . $cleanPath . '"}';
                    }
                } else {
                    // Error: Invalid file extension
                    echo 'extension error';
                }

                }
            }
        }
    }
   