<?php
    /** 
       @NOTE: for local webserver use local ip 127.0.0.1
    */ 
    define("DB_HOST", "127.0.0.1");
    define("DB_NAME", "fb-test-1");
    define("DB_USER", "root");
    define("DB_PASS", "");