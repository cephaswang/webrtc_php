<?php 

class Installer {
    private $db;
    private $dbHost, $dbName, $dbUser, $dbPass, $siteUrl;

    public function __construct($dbHost, $dbName, $dbUser, $dbPass, $siteUrl) {
        try {
            $dsn = "mysql:host=$dbHost";
            $this->db = new PDO($dsn, $dbUser, $dbPass);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->dbName  = $dbName;
            $this->dbHost  = $dbHost;
            $this->dbUser  = $dbUser;
            $this->dbPass  = $dbPass;
            $this->siteUrl = $siteUrl;

        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    public function createDatabase() {
        if (!$this->db) {
            return "Error: Database connection failed.";
        }
    
        try {
            // Check if the database exists
            $query = "SHOW DATABASES LIKE '{$this->dbName}'";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_COLUMN);
          
            if (empty($result)) {
                 // Create the database if it doesn't exist
                $query = "CREATE DATABASE `{$this->dbName}`";
                $stmt = $this->db->prepare($query);
                $stmt->execute();
                 
            }
            //import database into newly created database
            $this->importSQL();   
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }
    public function importSQL(){
        if (!$this->db) {
            return "Error: Database connection failed.";
        }

        try {
            $sql = file_get_contents('sql/fb-messenger.sql');
            $statements = explode(";", $sql);
            $this->db->exec("USE `{$this->dbName}`");
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if (!empty($statement))  {
                    $this->db->exec($statement);
                }
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }
    public function updateDBinfo(){
        $filePath = 'core/Config.php';

        $fileContents = file_get_contents($filePath);
        if($fileContents){
            $newValues = [
                'DB_HOST' => $this->dbHost,
                'DB_NAME' => $this->dbName,
                'DB_USER' => $this->dbUser,
                'DB_PASS' => $this->dbPass,
                'BASE_URL' => $this->siteUrl
            ];

            foreach ($newValues as $defineName => $newValue) {
                $searchPattern = "/define\(\"$defineName\", \"(.*?)\"\)/";
                $replacement = "define(\"$defineName\", \"$newValue\")";
                $fileContents = preg_replace($searchPattern, $replacement, $fileContents);
            }

            file_put_contents($filePath, $fileContents);
            $this->updateSettings();
            return true;
        }
    }
    public function updateSettings(){
    	$stmt = $this->db->prepare("UPDATE `settings` SET `url`= :siteUrl WHERE `ID` = '1'");
    	$stmt->bindParam(":siteUrl", $this->siteUrl, PDO::PARAM_STR);
    	$stmt->execute();
    }
    public function removeRedirect(){  
        $filePath = 'core/init.php';
        $fileContent = file_get_contents($filePath);
        if($fileContent){
            $pattern = "/if\s*\(\s*\\\$_SERVER\['REQUEST_URI'\]\s*!==\s*['\"]installer\.php['\"]\s*\)\s*\{\s*header\s*\(\s*['\"]Location:\s*['\"]\s*\.\s*['\"]installer\.php['\"]\s*\);\s*exit\s*\(\);\s*\}/s";
            $updatedContent = preg_replace($pattern, '', $fileContent);
            file_put_contents($filePath, $updatedContent);
            return true;
        } else {
            return false;
        }
    }
    public function delete(string $filePath){
        if (file_exists($filePath)) {
            return unlink($filePath);
        }
        return false;
    }
    public function deleteDirectory(string $dirPath): void {
        $directoryHandle = opendir($dirPath);    
        while (($item = readdir($directoryHandle)) !== false) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $itemPath = $dirPath . DIRECTORY_SEPARATOR . $item;
    
            if (is_dir($itemPath)) {
                $this->deleteDirectory($itemPath);
            } else {
                unlink($itemPath);
            }
        }
        closedir($directoryHandle);
        rmdir($dirPath);
    }
}
