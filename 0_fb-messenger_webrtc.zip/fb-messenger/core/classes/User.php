<?php 
	/**

	Define the namespace for the current code file as MyApp.
	*/
	namespace MyApp;

	/**

	Import the PDO class from the PHP Standard Library.
	*/
	use PDO;
	class User{
		/**
		 * Database connection object.
		 *
		 * @var object
		 */
		public $db;

		/**
		 * User ID of the currently logged-in user.
		 *
		 * @var int|null
		 */
		public $userID;

		/**
		 * Error message.
		 *
		 * @var string|null
		 */
		public $error;

		/**
		 * Session ID.
		 *
		 * @var string|null
		 */
		public $sessionID;
 
		/**
		 * Class constructor.
		 * Initializes the database connection and sets the user ID and session ID.
		 */
		public function __construct() {
		    // Create a new instance of the DB class and establish a database connection
		    $db = new \MyApp\DB;
		    $this->db = $db->connect();

		    // Set the user ID by calling the ID method
		    $this->userID = $this->ID();

		    // Set the session ID by calling the getSessionID method
		    $this->sessionID = $this->getSessionID();
		}

		
		/**
		 * Get the ID of the currently logged-in user.
		 *
		 * @return mixed The user ID if logged in, null otherwise.
		 */
		public function ID() {
		    if ($this->isLoggedIn()) {
		        return $_SESSION['user_id'];
		    }
		}


		/**
		 * Returns the session ID.
		 *
		 * @return string The session ID.
		 */
		public function getSessionID() {
		    return session_id();
		}


		/**
		 * Updates the session ID for the current user.
		 */
		public function updateSession() {
		    $this->update('users', ['sessionID' => $this->sessionID], ['userID' => $this->userID]);
		}


		/**
		 * Retrieves a user based on the session ID.
		 *
		 * @param string $sessionID The session ID.
		 * @return object|false The user object if found, or false if not found.
		 */
		public function getUserBySession($sessionID) {
		    return $this->get('users', ['sessionID' => $sessionID]);
		}


		/**
		 * Returns the error message.
		 *
		 * @return string The error message.
		 */
		public function errors() {
		    return $this->error;
		}


		/**
		 * Retrieves user data based on the provided username.
		 *
		 * @param string $username The username to search for.
		 * @return object|false The user data as an object if found, or false if not found.
		 */
		public function getUserByUsername($username) {
		    return $this->get('users', ['username' => $username]);
		}
	
		/**
		 * Checks if an email exists in the users table.
		 *
		 * @param string $email The email to check.
		 * @return mixed The user data if the email exists, false otherwise.
		 */
		public function emailExist($email) {
		    // Prepare the SQL statement to check if the email exists in the `users` table
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `email` = :email");
		    // Bind the email parameter to the prepared statement
		    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
		    $stmt->execute();
		    $data = $stmt->fetch(PDO::FETCH_OBJ);

		    if (!empty($data)) {
		        return $data;
		    } else {
		        return false;
		    }
		}


		//Method to check if username is already exist in the database
		public function usernameExist($username) {
		    // Prepare the SQL statement to check if the username exists in the `users` table
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `username` = :username");
		    
		    // Bind the username parameter to the prepared statement
		    $stmt->bindParam(":username", $username, PDO::PARAM_STR);
		    
		    // Execute the prepared statement
		    $stmt->execute();
		    
		    // Fetch the result as an object
		    $data = $stmt->fetch(PDO::FETCH_OBJ);
		    
		    if (!empty($data)) {
		        // Username exists, return the data object
		        return $data;
		    } else {
		        // Username does not exist, return false
		        return false;
		    }
		}

		//Method to encrypt the user password
		public function hash($password) {
		    // Hash the password using the default hashing algorithm
		    return password_hash($password, PASSWORD_DEFAULT);
		}

		//Method to redirect user to a provided location 
		public function redirect($location){
			header("Location: ".BASE_URL.$location);
			exit;
		}

		//Method to check if user is logged in 
		public function isLoggedIn(){
			return ((isset($_SESSION['user_id'])) ? true : false);
		}

		/**
		 * Logs out the user by destroying the session and redirecting to the index page.
		 */
		public function logout() {
		    $_SESSION = array(); // Clear all session variables
		    session_destroy(); // Destroy the session
		    session_regenerate_id(); // Regenerate a new session ID for security
		    $this->redirect('index.php'); // Redirect to the index page
		}

		//Method to get user data from database
		public function userData($userID = '') {
		    // If $userID parameter is not empty, use the provided value; otherwise, use the current user's ID
		    $userID = ((!empty($userID)) ? $userID : $this->userID);

		    // Retrieve user data from the 'users' table based on the userID
		    return $this->get('users', ['userID' => $userID]);
		}

		public function search($search) {
		    // Prepare the SQL statement to select users based on username and exclude the current user
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `username` LIKE ? AND `userID` != ?");
		    
		    // Bind the search term with a wildcard '%' to the first parameter
		    $stmt->bindValue(1, $search.'%', PDO::PARAM_STR);
		    
		    // Bind the current user's ID to the second parameter
		    $stmt->bindValue(2, $this->userID, PDO::PARAM_INT);
		    
		    // Execute the SQL statement
		    $stmt->execute();
		    
		    // Return the result as an array of objects
		    return $stmt->fetchAll(PDO::FETCH_OBJ);
		}


		public function get($table, $fields = array()) {
		    $where = " WHERE ";
		    // Construct the SQL query
		    $sql = "SELECT * FROM {$table}";

		    // Add WHERE conditions based on the provided $fields array
		    foreach ($fields as $key => $value) {
		        $sql .= " {$where} {$key} = :{$key}";
		        $where = " AND ";
		    }

		    // Prepare and execute the SQL query
		    if ($stmt = $this->db->prepare($sql)) {
		        foreach ($fields as $key => $value) {
		            $stmt->bindValue(":{$key}", $value);
		        }
		        // Execute the SQL statement
		        $stmt->execute();
		   	    // Return the result as an array of objects
		        return $stmt->fetch(PDO::FETCH_OBJ);
		    }
		}


		/**
		 * Inserts data into the specified table.
		 *
		 * @param string $table The name of the table.
		 * @param array $fields An associative array of column names and their corresponding values.
		 * @return int The last inserted ID.
		 */
		public function insert($table, $fields = array()) {
		    // Construct the column names string
		    $columns = implode(",", array_keys($fields));
		    
		    // Construct the value placeholders string
		    $values = ":" . implode(", :", array_keys($fields));
		    
		    // Construct the SQL query
		    $sql = "INSERT INTO {$table} ({$columns}) VALUES ({$values})";

		    if ($stmt = $this->db->prepare($sql)) {
		        // Bind the values to the placeholders
		        foreach ($fields as $key => $value) {
		            $stmt->bindValue(":{$key}", $value);
		        }
		        
		        // Execute the query
		        $stmt->execute();
		        
		        // Return the last inserted ID
		        return $this->db->lastInsertId();
		    }
		}


		/**
		 * Updates records in the specified table based on the given conditions.
		 *
		 * @param string $table The name of the table.
		 * @param array $fields An associative array of column names and their corresponding values to be updated.
		 * @param array $cond An associative array of column names and their corresponding values for the update conditions.
		 */
		public function update($table, $fields, $cond) {
		    $columns = '';
		    $where = " WHERE ";
		    $i = 1;
		    
		    // Construct the SET clause for updating columns
		    foreach ($fields as $name => $value) {
		        $columns .= "`{$name}` = :{$name}";
		        if ($i < count($fields)) {
		            $columns .= ", ";
		        }
		        $i++;
		    }
		    
		    $sql = "UPDATE `{$table}` SET {$columns}";
		    
		    // Construct the WHERE clause for update conditions
		    foreach ($cond as $key => $value) {
		        $sql .= " {$where} `{$key}` = :{$key}";
		        $where = " AND ";
		    }
		    
		    if ($stmt = $this->db->prepare($sql)) {
		        // Bind the values for updating columns
		        foreach ($fields as $key => $value) {
		            $stmt->bindValue(":{$key}", $value);
		        }
		        
		        // Bind the values for update conditions
		        foreach ($cond as $key => $value) {
		            $stmt->bindValue(":{$key}", $value);
		        }
		        
		        // Execute the update query
		        $stmt->execute();
		    }
		}


		/**
		 * Uploads a file to the server.
		 *
		 * @param array $file The uploaded file data.
		 * @return string|bool The uploaded file path if successful, or false if there was an error.
		 */
		public function upload($file) {
		    $fileInfo = getimagesize($file['tmp_name']);
		    $fileTmp = $file['tmp_name'];
		    $filename = basename($file['name']);
		    $fileSize = $file['size'];
		    $errors = $file['error'];
		    
		    // Get the file extension
		    $ext = explode('.', $filename);
		    $ext = strtolower(end($ext));

		    //Array to allow image extensions
		    $allowed = ['image/png', 'image/jpeg', 'image/jpg'];
		    
		    //check if file extension exist in allowed array
		    if (!in_array($fileInfo['mime'], $allowed)) {
		        $this->error = "File extension is not allowed";
		    } else {
                // Get the parent directory two levels above the current directory
		        $parentDirectory = dirname(dirname(dirname(__FILE__)));
                //path to store images 
		        $folder = '/content/';
		        // Generate random filename
		        $uploadFile = $folder . md5(time() . mt_rand()) . '.' . $ext;
		        //Check if there is no error
		        if ($errors === 0) {
		        	//Check if file size is less than or equal to 5mb max
		            if ($fileSize <= 5000000) {
		            	//Upload the image file
		                move_uploaded_file($fileTmp, $parentDirectory . $uploadFile);
		                //return the file location
		                return $uploadFile;
		            } else {
		            	//return error if file size is large
		                $this->error = "File is too large!";
		            }
		        }
		    }
		    
		    return false; // Return false if there was an error
		}
		/**
		 * Delete User.
		 *
		 * @param int $id The email to check.
		 * @return  void.
		 */
		public function deleteUser(int $id) {
		    // Prepare the SQL statement to delete user from the `users` table
		    $stmt = $this->db->prepare("DELETE FROM `users` WHERE `userID` = :userID");
		    // Bind the email parameter to the prepared statement
		    $stmt->bindParam(":userID", $id, PDO::PARAM_INT);
		    $stmt->execute();
		}

	}