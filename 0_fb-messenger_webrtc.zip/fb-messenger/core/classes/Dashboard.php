<?php 
namespace MyApp;
// Declare the namespace as "MyApp"
// This allows the class to be organized within the specified namespace
use PDO;
// Import the PDO class from the global namespace
// This allows the class to use the PDO class without needing to fully qualify its name

	class Dashboard{
		public $db, $userID, $user;

		// Declare public properties: $db, $userID, $user
		// These properties will be accessible throughout the class
		 
		public function __construct(){
		    // Create a new DB instance and assign it to the $db property
		    $db = new \MyApp\DB;
		    $this->db = $db->connect();

		    // Create a new User instance and assign it to the $user property
		    $this->user = new \MyApp\User;

		    // Get the current user ID and assign it to the $userID property
		    $this->userID = $this->user->ID();
		}
        // Method to display the recent users in the dashboard
        public function getRecentUsers(){
            $stmt = $this->db->prepare("SELECT * FROM users ORDER BY created_at DESC LIMIT 10");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        // Method to display the user
        public function getUsers($limit = 10, $offset = 0, $search = '') {
            // Prepare the search term for a LIKE query
            $searchTerm = "%" . $search . "%";
            
            // Modify the SQL query to include the search functionality
            $stmt = $this->db->prepare("
                SELECT * FROM users 
                WHERE name LIKE :search 
                ORDER BY `userID` DESC 
                LIMIT :limit OFFSET :offset
            ");
            
            // Bind the search term, limit, and offset to the query
            $stmt->bindParam(':search', $searchTerm, PDO::PARAM_STR);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        // Method to display the recent messages
        public function getRecentMessages($limit, $offset) {
            // SQL query to fetch recent messages with pagination
            $sql = "SELECT
                        m.messageID AS ID,
                        u1.userID AS senderID,
                        u1.username AS senderUsername,
                        u1.profileImage AS senderImage,
                        u2.name AS recipientName,
                        u2.username AS recipientUsername,
                        u2.profileImage AS recipientImage,
                        m.message,
                        m.type,
                        m.image
                    FROM messages m
                    INNER JOIN users u1 ON m.sentBy = u1.userID
                    INNER JOIN users u2 ON m.sentTo = u2.userID
                    ORDER BY m.created_at DESC
                    LIMIT :limit OFFSET :offset";
        
            // Prepare and execute the SQL statement
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
        
            // Fetch and return the results as objects
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        
        // Method to get total message count for pagination
        public function getTotalMessages() {
            $sql = "SELECT COUNT(*) as total FROM messages";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_OBJ)->total;
        }
        
        // Method to get total users count
        public function getTotalUsers($search = '') {
            // Prepare the search term for a LIKE query
            $searchTerm = "%" . $search . "%";
            
            // Modify the SQL query to count the total number of matching users
            $stmt = $this->db->prepare("
                SELECT COUNT(*) AS total 
                FROM users 
                WHERE username LIKE :search
            ");
            
            // Bind the search term
            $stmt->bindParam(':search', $searchTerm, PDO::PARAM_STR);
            
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_OBJ)->total;
        }
	}