<?php
namespace MyApp;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface {
    protected $clients;
    public $userObj,$messageObj, $userData;

    public function __construct() {
        $this->clients     = new \SplObjectStorage;
        $this->userObj     = new \MyApp\User;
        $this->messageObj  = new \MyApp\Messenger;
        echo "Server is started \n";
    }   

    //method to get new connection
    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
            $queryString = $conn->httpRequest->getUri()->getQuery();
            parse_str($queryString, $query);

            if($data = $this->userObj->getUserBySession($query['token'])){
                 $this->userData = $data;
                 $conn->userData = $data;
                 $this->clients->attach($conn);
                 $this->userObj->update('users', 
                                       ['connectionID' => $conn->resourceId], 
                                       ['userID' => $data->userID]);

                 echo "New connection! ({$data->username})\n"; 
            }
    }
    //method to get messages 
    public function onMessage(ConnectionInterface $from, $msg) {
        $numRecv = count($this->clients) - 1;
        echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');
        $data = json_decode($msg, true);
        $sentTo = $this->userObj->userData($data['sentTo']);
        if($data['type'] === 'message'){
        $this->userObj->insert('messages',['message' => $data['message'], 
                                           'sentBy'  => $from->userData->userID,
                                           'sentTo'  => $sentTo->userID]);
        }else if ($data['type'] === 'like'){
         $this->userObj->insert('messages',['message' => '', 
                                            'sentBy'  => $from->userData->userID,
                                            'sentTo'  => $sentTo->userID,
                                            'type'    => 'like']);
        }
        
         $send['sentBy']    = $from->userData->userID;
         $send['sentTo']    = $sentTo->userID;
         $send['message']   = $data['message'];
         $send['type']      = $data['type'];
         $send['profileImage'] = $from->userData->profileImage;
         $send['username'] = $from->userData->username;

        foreach ($this->clients as $client) {
            if ($from !== $client) {
                // The sender is not the receiver, send to each client connected
                if($client->resourceId == $sentTo->connectionID || $from == $client){
                    $client->send(json_encode($send));
                }
            }
        }
    }
    //Method to close the connection
    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";
    }
    //Method to return the error
    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}