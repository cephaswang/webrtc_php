<?php 
namespace MyApp;
// Declare the namespace as "MyApp"
// This allows the class to be organized within the specified namespace
use PDO;
// Import the PDO class from the global namespace
// This allows the class to use the PDO class without needing to fully qualify its name

	class Messenger{
		public $db, $userID, $user;

		// Declare public properties: $db, $userID, $user
		// These properties will be accessible throughout the class
		 
		public function __construct(){
		    // Create a new DB instance and assign it to the $db property
		    $db = new \MyApp\DB;
		    $this->db = $db->connect();

		    // Create a new User instance and assign it to the $user property
		    $this->user = new \MyApp\User;

		    // Get the current user ID and assign it to the $userID property
		    $this->userID = $this->user->ID();
		}

		/**
		 * Sends a message.
		 *
		 * @param string $message The message content.
		 * @param int $userID The ID of the user sending the message.
		 * @param int $sentTo The ID of the user receiving the message.
		 * @param string $file The file associated with the message.
		 * @param string $type The type of the message.
		 * @param string $voice The voice associated with the message.
		 * @return void
		 */
		public function sendMessage($message, $userID, $sentTo, $file, $type, $voice)
		{
		    $this->user->insert('messages', [
		        'message' => $message, 
		        'sentBy'  => $userID, 
		        'sentTo'  => $sentTo, 
		        'type'    => $type,
		        'image'   => $file,
		        'voice'   => $voice
		    ]);
		}

		/**
		 * Redirects to the message page.
		 *
		 * @return void
		 */
		public function redirectToMessage()
		{
		    // Prepare the SQL query to fetch the latest message
		    $stmt = $this->db->prepare("SELECT * FROM `messages` 
		                                LEFT JOIN `users` ON `sentTo` = `userID`
		                                WHERE `sentTo` = `userID` AND `sentBy` = :userID
		                                ORDER BY `messageID` DESC");
		    
		    // Bind the user ID parameter
		    $stmt->bindParam(":userID", $this->userID, PDO::PARAM_INT);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch the result as an object
		    $user = $stmt->fetch(PDO::FETCH_OBJ);

		    // Check if a user with messages is found
		    if ($user) {
		        // Redirect to the user's message page
		        $this->user->redirect("{$user->username}/messages/");
		    } else if (!basename(__FILE__) === "home.php") {
		        // If no messages found and not in home.php, redirect to home.php
		        $this->redirect('home.php');
		    }
		}

		/**
		 * Retrieves recent messages.
		 *
		 * @return void
		 */
		public function recentMessages(){ 
		    // Construct the SQL query to retrieve recent messages
		    $sql = "SELECT * FROM `messages` 
		            INNER JOIN `users` ON `sentBy` = `userID` and `messageID` in 
		            (SELECT max(`messageID`) 
		            FROM `messages` 
		            WHERE `sentBy` = `userID` AND `sentTo` = :userID OR 
		            `sentBy` = :userID AND `sentTo` = `userID`) 
		            OR `sentTO` = `userID` and `messageID` IN 
		            (SELECT max(`messageID`) 
		            FROM `messages` 
		            WHERE `sentBy` = `userID` AND `sentTo` = :userID OR 
		            `sentBy` = :userID AND `sentTo` = `userID`)
		            WHERE `sentBy` = `userID` AND `sentTo` = :userID OR 
		            `sentBy` = :userID AND `sentTo` = `userID`
		            GROUP BY `userID` ORDER BY `messageID` DESC";

		    // Prepare the SQL statement
		    $stmt = $this->db->prepare($sql);

		    // Bind the user ID parameter
		    $stmt->bindParam(":userID", $this->userID, PDO::PARAM_INT);

		    // Execute the query
		    $stmt->execute();

		    // Fetch all the messages as objects
		    $messages = $stmt->fetchAll(PDO::FETCH_OBJ);

		    // Iterate through the messages
		    foreach ($messages as $user) {
		        $date = new \DateTime($user->created_at);
		        $userID = $this->userID;
		        echo '<li id="recent" data-user="'.$user->userID.'"
						class="'.(($user->status === "notseen" && $user->sentBy !== $userID) ? 'fb-li-active' :'').' 
						       flex select-none items-center
						       cursor-pointer rounded-lg p-3">
							<a class="flex-1" 
							   href="'.BASE_URL.$user->username.'/messages">
							<div class="flex-1 flex">
								<div class="flex justify-center flex-wrap sm:flex-nowrap md:flex-nowrap xl:flex-nowrap 2xl:flex-nowrap relative gap-x-2 items-center flex-1">
									<div class="flex-shrink-0">
										<img class="w-12 h-12 object-cover 
												    border-gray-400 border 
												    rounded-full" 
											 src="'.BASE_URL.$user->profileImage.'">
									</div>
									<div class="sm:flex md:flex xl:flex 2xl:flex">
										<div class="mx-auto"> 
										 
										  <div class="text-gray-800">		
											<span style="font-size: .9375rem;">'.$user->username.'</span>
										  </div>

											<div class="text-gray-500 text-xs mx-auto flex overflow-hidden">
												<div class="overflow-hidden truncate" style="max-width:200px;"><span class="text-xs" id="recentText">'.
												     (($user->type === "image") 
												     	? 
												     '[image]' 
												     : 
												     (($user->type === "voice") 
												     	? 
												     '[voice]' 
												     : 
												     (($user->type === "like") 
												     	? 
												     '<span class="flex text-lg text-gray-400 text-2xl"><i class="fb-color fas fa-thumbs-up"></i></span>' 
												     : 
												     $user->message))).
												    '</span></div>
												<div class="time-stamp text-gray-500 
															text-xs self-end mx-1">
													<span class="self-start tracking-wide" id="recentTime">'.$date->format('h:i a').'</span>
												</div>
											</div>
										</div>
									</div>
									'.(($user->status === "notseen" && $user->sentBy !== $userID) ? '
										<span id="badge" 
										 	   class="fb-color absolute right-1">
										 	   <i class="fas fa-circle"></i>
										 </span>' : '').'
									  
								</div>
							</div>
						</a>
					</li>';
		    }
		}


		/**
		 * Retrieves chat messages between the current user and a specific sender.
		 *
		 * @param int $senderID The ID of the message sender.
		 * @return void
		 */
		public function getChat($senderID){
		    // Prepare SQL statement to select messages between the current user and the given sender
		    $stmt = $this->db->prepare("SELECT * FROM `messages` 
		                               LEFT JOIN `users` ON `sentBy` = `userID`
		                               WHERE `sentBy` = :senderID AND 
		                                     `sentTo` = :userID OR 
		                                     `sentBy` = :userID AND 
		                                     `sentTo` = :senderID 
		                               ORDER BY `messageID` DESC");
		    
		    // Bind the parameters
		    $stmt->bindParam(":senderID", $senderID, PDO::PARAM_INT);
		    $stmt->bindParam(":userID", $this->userID, PDO::PARAM_INT);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch all messages
		    $messages = $stmt->fetchAll(PDO::FETCH_OBJ);
		    
		    // Loop through the messages and display them
		    foreach($messages as $user){
		        if($user->sentBy === $this->userID){
		            // Display right-aligned message for the current user
		            echo '<div class="message flex w-full h-auto justify-end">
							    <div class="flex flex-row-reverse">
							        <div class="flex items-center">
							        '.(($user->type ==="image") ? '
							       	  <img data-fancybox data-src="'.BASE_URL.$user->image.'" class="m-2 min-w-4 max-w-xs 
							                       rounded-3xl" 
							                src="'.BASE_URL.$user->image.'">
							         ' :
							           (($user->type === "voice") ? 
							           	'<audio class="m-2 min-w-4 max-w-xs pt-1 rounded-3xl" controls><source src="'.BASE_URL.$user->voice.'" type="audio/wav"></audio>' 
							           : (($user->type === "like") ? 
							           	'<span class="text-lg text-gray-700 text-5xl">
			                                <i class="fb-color fas fa-thumbs-up"></i>   
			                            </span>' :
							           '<span 
							                class="fb-bg text-white py-2 px-4 m-1 rounded-full text-sm">'.$user->message.'
							           </span>')
							           )).'

							        </div>
							        <div class="flex items-center">
							            <div>
							                <ul class="flex gap-x-1 text-gray-400 
							                           text-sm hidden">

							                    <li class="leading-6 hover:bg-gray-100 
							                               text-center rounded-full 
							                               w-6 h-6 
							                               cursor-pointer">
							                        <span><i class="fas fa-ellipsis-v"></i></span>
							                    </li>
							                    
							                    <li class="leading-6 hover:bg-gray-100 
							                               text-center rounded-full 
							                               w-6 h-6 cursor-pointer">
							                        <span><i class="p-1 fas fa-reply"></i></span>
							                    </li>

							                    <li class="leading-6 hover:bg-gray-100 
							                               text-center rounded-full 
							                               w-6 h-6 cursor-pointer">
							                        <span><i class="p-1 far fa-smile"></i></span>
							                    </li>
							                </ul>
							            </div>
							        </div>
							    </div>
							</div>';
		        } else {
		            // Display left-aligned message for the other user
		            echo '<!-- LEFT CHAT MESSAGE -->
							<div class="message flex w-full">
							    <div class="flex items-end">
							        <div class="px-1 py-1">
							            <img class="w-8 h-8 object-cover border-gray-400 
							                        border rounded-full" 
							                 src="'.BASE_URL.$user->profileImage.'"/>
							        </div>
							        <div class="flex items-center max-w-xs">
							     
							           '.(($user->type ==="image") ? '
							       	  <img  data-fancybox data-src="'.BASE_URL.$user->image.'"  class="m-2 min-w-4 max-w-xs 
							                       rounded-3xl" 
							                src="'.BASE_URL.$user->image.'">
							         ' :
							           (($user->type === "voice") ? 
							           	'<audio class="m-2 min-w-4 max-w-xs pt-1 rounded-3xl" controls><source src="'.BASE_URL.$user->voice.'" type="audio/ogg"></audio>' 
							           
							           : (($user->type === "like") ? 
							           	'<span class="text-lg text-gray-700 text-5xl">
			                                <i class="fb-color fas fa-thumbs-up"></i>   
			                            </span>' 
							           : 
							           '<span 
							                class="rounded-2xl bg-gray-200 
							                        text-gray-800 text-white 
							                        py-2 px-4 m-1 
							                        rounded-full text-sm">'.$user->message.'
							           </span>')
							           )).'
							        </div>
							        <div class="flex self-center hover:flex">
							            <div>
							                <ul class="flex gap-x-1 text-gray-400 
							                           text-sm flex-row-reverse hidden">
							                    <li class="leading-6 hover:bg-gray-100 
							                               text-center rounded-full 
							                               w-6 h-6 cursor-pointer">
							                     <span><i class="fas fa-ellipsis-v"></i></span>
							                    </li>

							                    <li class="leading-6 hover:bg-gray-100 
							                               text-center rounded-full 
							                               w-6 h-6 cursor-pointer">
							                     <span><i class="p-1 fas fa-reply"></i></span>
							                    </li>
							                    
							                    <li class="leading-6 hover:bg-gray-100 
							                               text-center rounded-full 
							                               w-6 h-6 cursor-pointer">
							                        <span><i class="p-1 far fa-smile"></i></span>
							                    </li>
							                </ul>
							            </div>
							        </div>
							    </div>
							</div>';
		        }
		    }
		}


		/**
		 * Sets the status of messages as 'seen' for a given sender ID.
		 *
		 * @param int $senderID The ID of the message sender.
		 * @return void
		 */
		public function setMessageStatus($senderID)
		{
		    // Update the 'status' field of messages to 'seen'
		    $this->user->update('messages', ['status' => 'seen'], ['sentBy' => $senderID, 'sentTo' => $this->userID]);
		}


		/**
		 * Retrieves chat media (images) between the current user and a specific sender.
		 *
		 * @param int $senderID The ID of the message sender.
		 * @return void
		 */
		public function getChatMedia($senderID)
		{
		    // Prepare SQL statement to select messages with images between the current user and the given sender
		    $stmt = $this->db->prepare("SELECT * FROM `messages` WHERE (`sentBy` = :userID AND `sentTo` = :senderID OR `sentBy` = :senderID AND `sentTo` = :userID) AND `image` IS NOT NULL AND `image` != ''");
		    
		    // Bind the parameters
		    $stmt->bindParam(":senderID", $senderID, PDO::PARAM_INT);
		    $stmt->bindParam(":userID", $this->userID, PDO::PARAM_INT);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch all media data
		    $mediaData = $stmt->fetchAll(PDO::FETCH_OBJ);
		    
		    // Loop through the media data and display the images
		    foreach($mediaData as $media){
		        echo '<div data-fancybox data-src="'.BASE_URL.$media->image.'" class="img-box relative overflow-hidden cursor-pointer px-1 py-1">
		                  <img class="h-full w-full rounded-lg" src="'.BASE_URL.$media->image.'" alt="">
		              </div>';
		    }
		}
		/**
		 * Delete User.
		 *
		 * @param int $id The email to check.
		 * @return  void.
		 */
		public function deleteMessage(int $id) {
		    // Prepare the SQL statement to delete user from the `users` table
		    $stmt = $this->db->prepare("DELETE FROM `messages` WHERE `messageID` = :messageID");
		    // Bind the email parameter to the prepared statement
		    $stmt->bindParam(":messageID", $id, PDO::PARAM_INT);
		    $stmt->execute();
		}

	}