<?php
/**
	Define the namespace for the current code file as MyApp.
*/
namespace MyApp;

/**
	Import the PDO class from the PHP Standard Library.
*/
use PDO;
/**
	Class DB represents a database connection.
*/
class DB {
	/**
    	Establishes a database connection and returns the PDO object.
  	    @return PDO The PDO object representing the database connection.
        NOTE: for local webserver use local ip 127.0.0.1
    */
    public function connect() {
        $db = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    }
}
