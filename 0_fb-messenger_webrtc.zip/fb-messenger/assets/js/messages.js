$(function(){ 
	$(document).on('click', '#thumbBtn', function(event) {
	  event.stopPropagation();
	  let chat = $('#messages');
	  let sentTo = $("#textarea").data('receiver');
	  let message = `
	    <div class="message flex w-full h-auto justify-end">
	      <div class="flex flex-row-reverse">
	        <div class="flex items-center">
	          <span class="text-lg text-gray-700 text-5xl">
	            <i class="fb-color fas fa-thumbs-up"></i>
	          </span>
	        </div>
	        <div class="flex items-center">
	          <div>
	            <ul class="flex gap-x-1 text-gray-400 text-sm hidden">
	              <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer">
	                <span><i class="fas fa-ellipsis-v"></i></span>
	              </li>
	              <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer">
	                <span><i class="p-1 fas fa-reply"></i></span>
	              </li>
	              <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer">
	                <span><i class="p-1 far fa-smile"></i></span>
	              </li>
	            </ul>
	          </div>
	        </div>
	      </div>
	    </div>
	  `;
	  
	  let data = { sentTo: sentTo, message: '', type: "like" };

	  chat.prepend(message);
	  conn.send(JSON.stringify(data));
	  scrollDown();
	});

	$('#textarea').emojioneArea({
		events: {
			keyup: function(editor,event){
				let text   = this.getText();
				let sentTo = editor.data('receiver');
				let chat = $('#messages');
 
				if(text != ""){
					if(event.key === "Enter"){
						let data = {sentTo:sentTo, message:text,type:"message"};
						let message = '<div class="message flex w-full h-auto justify-end"><div class="flex flex-row-reverse"><div class="flex items-center"><span class="fb-bg text-white py-2 px-4 m-1 rounded-full text-sm">'+this.getText()+'</span></div><div class="flex items-center"><div><ul class="flex gap-x-1 text-gray-400 text-sm hidden"><li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="fas fa-ellipsis-v"></i></span></li><li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="p-1 fas fa-reply"></i></span></li><li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer"><span><i class="p-1 far fa-smile"></i></span></li></ul></div></div></div></div>';
						chat.prepend(message);
						conn.send(JSON.stringify(data));
						scrollDown();
						this.setText('');

					}
				}
			}
		}
	});
});