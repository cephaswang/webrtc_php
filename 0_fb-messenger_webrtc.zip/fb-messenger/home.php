<?php
	include 'core/init.php';
    
	if (!$user || !$userObj->isLoggedIn()) {
        $userObj->logout();
        $userObj->redirect('index.php');
    }

	$userObj->updateSession();

	$user =  $userObj->userData();
	$messageObj->redirectToMessage();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Facebook Messenger</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />    <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL;?>assets/style/style.css">
    <script
          src="https://code.jquery.com/jquery-3.6.0.min.js"
          integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
          crossorigin="anonymous"></script>
</head>
<body>
<div class="wrapper">
<div class="inner-wrapper">
    <div class="w-screen h-screen">
        <!--Wrapper for chat-->
        <div class="flex h-full flex-wrap flex-auto">
            <!--CHAT_LEFT-->
            <div class="chat-left sm:w-1/5 md:w-1/5 xl:w-1/5 2xl:w-1/5 " style="">  
                <div class="flex flex-col">
                    <div class="flex mx-4 flex-wrap">
                        <div class="flex-1">
                            <h3 class="select-none font-bold text-2xl text-gray-800 py-4">Chats</h3>
                        </div>
                        <div class="flex items-center flex-wrap">
                            <button id="menu-button1">
                                <span class="btn-box rounded-full w-8 h-8 bg-gray-200 flex items-center justify-center p-4 m-1 cursor-pointer">
                                   <i class="fas fa-times"></i>
                                </span>
                             </button>
                        </div>
                    </div>
                    <div class="flex bg-gray-100 m-2 mx-4 rounded-full border items-center">
                        <span class="text-gray-500 px-1 pl-2 text-xl"><i class="fas fa-search"></i></span>
                        <span class="flex-1 p-1"><input id="search" class="w-full outline-none bg-transparent text-gray-700" type="text" placeholder="Search for User" name="user-search" /></span>
                    </div>
                    <div class="parent">
                        <div class=" w-10/12 overflow-x-scroll  sm:overflow-x-auto md:overflow-x-auto xl:overflow-x-auto 2xl:overflow-x-auto " >
                            <ul class="mx-2 left-overflow flex sm:flex-col md:flex-col xl:flex-col 2xl:flex-col">
                                <div class="result hidden">     
                                </div>
                                <div id="recentMessages">
                                  <!-- RECENT-MESSAGES -->
                                  <?php $messageObj->recentMessages();?>
                                </div>
                                

                            </ul>
                        </div>
                    </div>
                </div>
            </div><!--CHAT_LEFT_ENDS-->
            <!--CHAT_CENTER-->
            <div class="chat-center flex-1 flex flex-col h-full border border-gray-300 border-t-0 border-b-0">
                <div class="flex items-center justify-between border border-l-0 border-r-0 border-b-1 border-t-0 border-gray-300">
                    <div class="items-center flex">
                        <div class="px-3 py-4">
                            <img class="w-10 h-10 object-cover border-gray-400 border rounded-full" />
                        </div>
                        <div>
                            <span class="select-none font-bold text-gray-800 text-lg ">
                             </span>
                        </div>
                        <div class="flex items-center flex-wrap">
                            <button id="searchBtn">
                                <span class="rounded-full w-8 h-8 bg-gray-200 flex items-center justify-center p-4 m-1 cursor-pointer">
                                    <i class="fas fa-search"></i>
                                </span>
                            </button>
                            
                           
                            <span class="bg-blue-300 rounded-full inline-block"></span>
                        </div>
                    </div>
                    <div class="gap-x-4 flex mx-4 text-xl fb-color">
                        
                        <a href="<?php echo BASE_URL;?>logout.php" class="select-none font-bold text-gray-800 text-lg hover:underline cursor-pointer
                        ">Logout</a>
                    </div>
                </div>
                <div id="chat" class="chat-wrap h-full flex overflow-y-auto">
                    
                    <!--CHAT-->
                    <div id="messages" class="chat p-2 flex flex-col-reverse overflow-y-auto w-full">
                         <!--DISPLAY-CHAT -->
                        <div class="message flex w-full h-auto justify-end">
                          <div class="flex flex-row-reverse">
                            <div class="flex items-center">
                            <span class="rounded-2xl bg-gray-200 text-gray-800 text-white py-2 px-4 m-1 rounded-full text-sm">To start a chat, Click on   <i class="fas fa-search"></i> on the top left and search for the user to start a start</span>
                            </div>
                            <div class="flex items-center">
                              <div>
                                <ul class="flex gap-x-1 text-gray-400 text-sm hidden">
                                  <li class="leading-6 hover:bg-gray-100 text-center rounded-full w-6 h-6 cursor-pointer">
                                    <span><i class="fas fa-ellipsis-v"></i></span>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                     </div>
                    <!--CHAT_ENDS-->
                 </div>
                <!--CHAT_WRAP_ENDS-->

                <div class="box-border border-gray-300 border py-3 px-3 border-l-0 border-r-0">
                    <ul class="gap-x-1 flex items-center justify-arround text-white text-lg">
                        <!-- <li class="m-1 cursor-pointer ">
                            <span>
                                <i class="fb-bg rounded-2xl p-1 fas fa-plus"></i>
                            </span>
                        </li> -->
                        <li class="m-1 cursor-pointer ">
                            <span>
                                <label for="file" class="cursor-pointer">
                                    <i class="text-xl text-gray-200 p-1 p-1  far fa-images"></i>
                                </label>
                             </span>
                        </li>
                        <li class="m-1 cursor-pointer relative">
                            <span>
                                <i class='fa fa-microphone text-xl text-gray-200 p-1 p-1'></i>
                            </span>
                            
                        </li>
                        <li class="flex-1 m-1 cursor-pointer relative text-gray-700 bg-gray-100 py-2 px-4 flex-1 w-full border-gray-300 rounded-full ">
                            <input id="textarea"  class="outline-none  placeholder-gray-300::placeholder bg-transparent w-full" placeholder="Enter Your Message" type="text" name="message" autocomplete="no" disabled>
                         </li>
                        <li class="self-center flex cursor-pointer ">
                            <span class="text-lg text-gray-400 text-2xl">
                                <i class="text-gray-200 fas fa-thumbs-up"></i>   
                            </span>
                        </li>
                    </ul>
                </div>
            </div><!--CHAT_CENTER_ENDS-->
            <!--CHAT_RIGHT-->
            
            <!--CHAT_RIGHT_ENDS-->
        </div><!--Wrapper for chat-ends-->
    </div>
</div><!----INNER_WRAPPER---->
</div><!----WRAPPER ENDSS--->  
<!-- JAVASCRIPT -->
<script type="text/javascript">
    //create websocket conenction
    const conn    = new WebSocket(`ws://localhost:8080/fb-messenger/?token=<?php echo $userObj->sessionID;?>`);
    const baseURL = "<?php echo BASE_URL;?>";

    //scroll to bottom 
    function scrollDown() {
      const height = $('.message').toArray().reduce((acc, value) => acc + $(value).height(), 0);
      $('.chat-wrap').animate({ scrollTop: height }, 1000);
    }

    //buttons for mobile view
    $('#searchBtn').click(function() {
      const searchDiv = $('.chat-left');
      searchDiv.toggle(searchDiv.css('display') === 'none');
    });

    $('#searchBtnClose').click(function() {
      $('.chat-left').css('display', 'none');
    });

    $('#profileBtn').click(function() {
      const profileDiv = $('.chat-right');
      profileDiv.toggle(profileDiv.css('display') === 'none');
    });

    $('#profileBtnClose').click(function() {
      const profileDiv = $('.chat-right');
      profileDiv.toggle(profileDiv.css('display') === 'none');
    });
</script>
  
 <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/main.js"></script>
 <script type="text/javascript" src="<?php echo BASE_URL;?>assets/js/search.js"></script>
 
 </body>
</html> 