<?php 
    include 'core/init.php';
    if($userObj->isLoggedIn()){
        $userObj->redirect('index.php');
    }
    if($_SERVER['REQUEST_METHOD'] === "POST"){
        if(isset($_POST)){
            $name     = trim(stripcslashes(htmlentities($_POST['name'])));
            $username = trim(stripcslashes(htmlentities($_POST['username'])));
            $email    = trim(stripcslashes(htmlentities($_POST['email'])));
            $password = $_POST['password'];

            if(!empty($name) && !empty($username) && !empty($email) && !empty($password)){
               
                if(strlen($username) < 4){
                    $error = 'Choose a username 3-30 characters long';
 
                }else if($userObj->usernameExist($username)){
                    $error = 'Username is already taken';
                
                }else if(strlen($password) <= 3){
                    $error = "Password must be 3-30 characters long";

                }else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                    $error = "Invaild Email format!";

                }else if($userObj->emailExist($email)){
                    $error = "Email is already in use";

                }else{
                     if(!empty($_FILES['image']['name'][0])){
                        $image  = $userObj->upload($_FILES['image']);
                     }else{
                         $image = 'assets/images/avatar.png';
                     }

                        $hash = $userObj->hash($password);
                        session_regenerate_id();
                        $id = $userObj->insert('users', ['name'         => $name,
                                                         'username'     => $username, 
                                                         'email'        => $email, 
                                                         'password'     => $hash,
                                                         'profileImage' => $image,
                                                         'sessionID'    => 0, 
                                                         'connectionID' => 0]);
                        $_SESSION['user_id'] = $id;
                        $userObj->redirect('home.php');
                }
            }else{
                $error = 'All fields are requried!';
            }
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signup - Facebook Messenger</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="assets/style/style.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
</head>
<body>
<div class="wrapper">
<div class="inner-wrapper">
<!--WRAPPER FOR LOGIN-->
<div class="flex h-screen w-screen justify-center"> 
<div class="h-4/5 w-full flex fb-body-bg">
<div class="flex items-center flex-1">
<div class="flex mx-auto w-12/12 sm:w-6/12 md:w-10/12 xl:w-6/12 2xl:w-6/12 flex-wrap flex-col sm:flex-row md:flex-row xl:flex-row 2xl:flex-row sm:flex-nowrap md:flex-nowrap xl:flex-nowrap 2xl:flex-nowrap" style="">
    <div class="flex-col flex p-2 pt-16 w-8/12 sm:w-6/12 md:w-6/12 xl:w-6/12 2xl:w-6/12"> 
        <div>
            <h1 class="font-bold fb-color text-6xl">Facebook</h1>
        </div>
        <div>
            <h2 class="text-gray-700 text-4xl">Facebook helps you connect and share with the people in your life.</h2>
        </div>
    </div>
    <div style="flex-basis: 396px;" class="shadow-md bg-white rounded-xl border border-gray-100 mx-2">
        <div>
            <div class="mx-1 my-1 p-2">
                <ul class="flex flex-col items-center">
                    <form method="POST" enctype="multipart/form-data">
                    <li class="m-1 my-2">
                    <input  type="text" 
                            name="name" 
                            placeholder="Name"
                            class="login-input"
                            >
                    </li>
                    <li class="m-1 my-2">
                    <input  type="text" 
                            name="username" 
                            placeholder="Username"
                            class="login-input"
                            >
                    </li>
                    <li class="m-1 my-2">
                    <input  type="Email" 
                            name="email" 
                            placeholder="Email address"
                            class="login-input"
                            >
                    </li>
                    <li class="m-1 my-2">
                    <input  type="password" 
                            name="password" 
                            placeholder="Password"
                            class="login-input"
                            >
                    </li>

                    
                    
                    <li class="m-1 my-2 text-center">
                        <div class="">
                            <div class="flex items-center">
                                <div class="w-10 sm:w-40 md:w-40 xl:w-40 2xl:w-40  h-auto overflow-hidden">
                                    <img id="profileImg" class="w-full" src="assets/images/avatar.png">
                                    
                                </div>
                                <span class="px-2 text-gray-500">Profile Image</span>
                                <div class="flex justify-center flex-1">
                                    <label for="image-up">
                                        <span class="text-4xl cursor-pointer"><i class="fas fa-upload"></i></span>
                                    </label>
                                    <input class="hidden"id="image-up" type="file" name="image">
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="m-1 my-2 border-t border-gray-200"></li>
                    <li class="m-1 my-2">
                     <!-- ERROR -->
                     <?php 
                            if(isset($error)){
                                echo '<p class="text-red-400 text-sm">'.$error.'</p>';
                            }
                     ?>
                      </li>
                    <li class="m-1 my-2">
                        <button class="text-lg py-2 px-5 fb-bg text-white w-full rounded-lg font-bold">Signup</button>
                    </li>
                    <li class="m-1 my-2">
                        <a href="index.php" class="fb-color text-sm">Already have account? Login</a>
                    </li>
                     
                     
                </form>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div><!--WRAPPER FOR LOGIN-END-->
</div><!----INNER_WRAPPER---->
</div><!----WRAPPER ENDSS--->
<script>
    // Display selected image before uploading
    $('#image-up').change(function(e) {
        let file = e.target.files[0];
        let reader = new FileReader();
        reader.onload = function(e) {
            $('#profileImg').attr('src', e.target.result);
        }
        reader.readAsDataURL(file);
    });
</script>
</body>
</html>