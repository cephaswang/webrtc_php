<?php
    include 'core/init.php';
    if($userObj->isLoggedIn()){
        $userObj->redirect('home.php');
    }
    if($_SERVER['REQUEST_METHOD'] === "POST"){
        if(isset($_POST)){
            $email    = trim( stripcslashes(htmlentities($_POST['email'], ENT_QUOTES)));
            $password = $_POST['password'];

            if(!empty($email) && !empty($password)){
                if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                    $error = "Invaild email format";
                }else{
                    if($user = $userObj->emailExist($email)){
                        if(password_verify($password, $user->password)){
                            //login
                            session_regenerate_id();             
                            $_SESSION['user_id'] = $user->userID;
                            $userObj->redirect('home.php');
                        }else{
                            $error = "Your email or password is incorrect!";
                        }
                    }else{
                        $error = "No accounts belongs to this email address";
                    }
                }
            }else{
                $error = "Please enter your email and password to login!";
            }
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Facebook Messenger</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="assets/style/style.css">
</head>
<body>
<div class="wrapper">
<div class="inner-wrapper">
<!--WRAPPER FOR LOGIN-->
<div class="flex h-screen w-screen justify-center"> 
<div class="h-4/5 w-full flex fb-body-bg">
<div class="flex items-center flex-1">
<div class="flex mx-auto w-12/12 sm:w-6/12 md:w-10/12 xl:w-6/12 2xl:w-6/12 flex-wrap flex-col sm:flex-row md:flex-row xl:flex-row 2xl:flex-row sm:flex-nowrap md:flex-nowrap xl:flex-nowrap 2xl:flex-nowrap" style="">
    <div class="flex-col flex p-2 pt-16 w-8/12 sm:w-6/12 md:w-6/12 xl:w-6/12 2xl:w-6/12"> 
        <div>
            <h1 class="font-bold fb-color text-6xl">Facebook</h1>
        </div>
        <div>
            <h2 class="text-gray-700 text-4xl">Facebook helps you connect and share with the people in your life.</h2>
        </div>
    </div>
    <div style="flex-basis: 396px;" class="shadow-md bg-white rounded-xl border border-gray-100 mx-2">
        <div>
            <div class="mx-1 my-1 p-2">
                <ul class="flex flex-col items-center">
                    <form method="POST">
                    <li class="m-1 my-2">
                    <input  type="Email" 
                            name="email" 
                            placeholder="Email address"
                            class="login-input"
                            >
                    </li>
                    <li class="m-1 my-2">
                    <input  type="password" 
                            name="password" 
                            placeholder="Password"
                            class="login-input"
                            >
                    </li>
                    <li class="m-1 my-2">
                     <!-- ERROR -->
                     <?php 
                            if(isset($error)){
                                echo '<p class="text-red-400 text-sm">'.$error.'</p>';
                            }
                     ?>
                      </li>
                    <li class="m-1 my-2">
                        <button class="text-lg py-2 px-5 fb-bg text-white w-full rounded-lg font-bold">Log In</button>
                    </li>
                    
                    <li class="m-1 my-2 border-t border-gray-200"></li>
                    <li class="m-1 my-2 text-center">
                        <a href="signup.php" class="text-lg py-2 px-5 fb-green text-white rounded-lg font-bold">Create New Account</a>
                    </li>
                     
                </form>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div><!--WRAPPER FOR LOGIN-END-->
</div><!----INNER_WRAPPER---->
</div><!----WRAPPER ENDSS--->
</body>
</html>