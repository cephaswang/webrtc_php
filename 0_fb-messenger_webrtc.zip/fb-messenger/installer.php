<?php 
require_once(__DIR__ . '/core/classes/Installer.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requiredFields = ['siteUrl', 'dbHost', 'dbName', 'dbUser'];
    $formData = array_intersect_key($_POST, array_flip($requiredFields));
    
    if (count($formData) === count($requiredFields) && !in_array('', $formData, true)) {
        $dbHost  = $formData['dbHost'];
        $dbName  = $formData['dbName'];
        $dbUser  = $formData['dbUser'];
        $dbPass  = $formData['dbPass'] ?? '';
        $siteUrl = $formData['siteUrl']; 

        $installer = new Installer($dbHost, $dbName, $dbUser, $dbPass, $siteUrl);
        $error = $installer->createDatabase();
        if(empty($error)){
            if($installer->updateDBinfo()){
                if($installer->removeRedirect()){
                    if ($installer->delete('installer.php')) {
                        $installer->delete('core/classes/Installer.php');
                        $installer->deleteDirectory('sql');
                        header("Location: {$siteUrl}");
                        exit;
                    }
                }
            }
        }

    } else {
        $error = 'All fields are required.';
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <title>Installer - FB Like Messenger</title>
</head>
<body>
<!-- component -->
<div class="h-screen md:flex">
    <div class="relative overflow-hidden md:flex w-1/2 bg-gradient-to-tr from-black to-green-900  
 justify-around items-center hidden">
        <div>
            <h1 class="text-white font-bold text-4xl font-sans">Need  
 help with something?</h1>
            <p class="text-white mt-1">You can now contact us via Facebook <a href="https://www.facebook.com/aizaz.dinho/" target="_blank" class="center block w-28 text-white font-bold">Click here</a></p>
        </div>
        <div class="absolute -bottom-32 -left-40 w-80 h-80 border-4 rounded-full border-opacity-30 border-t-8"></div>
        <div class="absolute -bottom-40 -left-20 w-80 h-80 border-4 rounded-full border-opacity-30 border-t-8"></div>
        <div class="absolute -top-40 -right-20 w-80 h-80 border-4 rounded-full border-opacity-30 border-t-8"></div>
        <div class="absolute -top-20 -right-20 w-80 h-80 border-4 rounded-full border-opacity-30 border-t-8"></div>
    </div>
    <div class="flex md:w-1/3 justify-center ml-20 py-10 items-center bg-white">
        <form class="bg-white w-full" method="POST">
            <h1 class="font-bold text-5xl mb-10">Installation</h1>
            <h1 class="text-gray-800 font-bold text-2xl mb-1">Database</h1>
            <p class="text-sm font-normal text-gray-600 mb-7">Fill MySQL info</p>
            <div class="grid grid-cols-1 md:grid-cols-1 gap-1">
                  <div class="flex items-center border-2 py-2 px-1 rounded-2xl mb-4">
                    <input id="host" class="w-full pl-2 outline-none border-none" type="text" name="dbHost" placeholder="MySQL Database Localhost, For local webserver use local ip 127.0.0.1"/>
                 </div>
                <div class="flex items-center border-2 py-2 px-3 rounded-2xl mb-4">
                    <input class="pl-2 outline-none border-none" type="text" name="dbName"  placeholder="MySQL Database name" />
                </div>
                <div class="flex items-center border-2 py-2 px-3 rounded-2xl mb-4">
                    <input class="pl-2 outline-none border-none" type="text" name="dbUser"  placeholder="MySQL Database User" />
                </div>
                <div class="flex items-center border-2 py-2 px-3 rounded-2xl mb-4">
                    <input class="pl-2 outline-none border-none" type="text" name="dbPass"  placeholder="MySQL Database Password" />
                </div>
                <div class="flex items-center border-2 py-2 px-3 rounded-2xl">
                    <input class="pl-2 outline-none border-none w-full" type="text" name="siteUrl" placeholder="Site Url eg:`http://localhost/fb-messenger/` with '/' at the end of url " />
                </div>
            </div>
            <?php if(!empty($error)):?>
            <div class="flex flex-col mt-2">
                <div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
                    <?php echo $error;?>
                </div>
            </div>
            <?php endif;?>
            <button type="submit" class="block w-full bg-indigo-600 mt-4 py-2 rounded-2xl text-white font-semibold mb-2">Save</button>
        </form>
    </div>
</div>                  
</body>
</html>
