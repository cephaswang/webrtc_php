Application Installation Guide

To set up this application, please follow the steps below:
Automatic Installation

    Extract the ZIP File: After extracting the application files from the ZIP, access the app through your web browser. This will redirect you to the installer page.

    Database Information:
        On the installer page, provide your database (DB) connection information, including the database name.
        If the specified database does not exist, the installer will attempt to create it automatically. Simply provide the required DB information, and the installer will handle the setup.

    File Cleanup:
        After the setup completes, the installer will try to delete the following files for security:
            root/installer.php
            core/classes/Installer.php
            The sql folder in the root directory.
        If the files are not deleted automatically, remove them manually.

    Remove Redirect Code:
        Open core/init.php and delete the following code to prevent redirection to the installer page in future sessions:

        php

        if ($_SERVER['REQUEST_URI'] !== 'installer.php') {
            header('Location: ' . 'installer.php');
            exit();
        }

    WebSocket URL Configuration:
        If you are not using localhost, update the WebSocket URL in both home.php and messenger.php to reflect the correct URL.

Manual Installation

If you prefer manual installation, follow these steps:

    Create the Database:
        In PHPMyAdmin, create a new database named fb-messenger.

    Import Database File:
        Import the fb-messenger.sql file into the fb-messenger database:
            In PHPMyAdmin, navigate to fb-messenger -> Import tab.
            Select the fb-messenger.sql file and click the Go button.

    Configure Application Files:
        Open core/init.php and set your localhost URL.
        Open core/classes/db.php and enter your database name, MySQL user, and password.

    WebSocket URL Configuration:
        If you are not using localhost, update the WebSocket URL in both home.php and messenger.php.

By following these steps, you should be able to configure the application successfully for your desired environment.


Contact me : https://www.facebook.com/aizaz.dinho/
