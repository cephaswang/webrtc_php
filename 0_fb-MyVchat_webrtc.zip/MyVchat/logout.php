<?php 
	// Include the require php files
	include 'core/init.php';
	// Call the logout function to logout the logged in user
	$userObj->logout();