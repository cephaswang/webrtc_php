<?php 
	namespace MyApp;
	use PDO;

	/**
	 * Database connection class.
	 */
	class DB{
	    /**
	     * Establishes a database connection and returns the PDO object.
	     *
	     * @return PDO The PDO database connection object.
	     */
	    function connect(){
	        // Create a new PDO connection to the MySQL database
	        $db = new PDO("mysql:host=127.0.0.1; dbname=MyVchat", "root", "");

	        // Return the PDO database connection object
	        return $db; 
	    }
	}
