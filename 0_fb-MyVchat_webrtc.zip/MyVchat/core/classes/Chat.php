<?php
    namespace MyApp;
    use Ratchet\MessageComponentInterface;
    use Ratchet\ConnectionInterface;

    /**
     * Chat class implementing the Ratchet MessageComponentInterface.
     */
    class Chat implements MessageComponentInterface {
        protected $clients;
        public    $userObj, $data;

        /**
         * Constructor to initialize the Chat class.
         */
        public function __construct() {
            $this->clients  = new \SplObjectStorage;
            $this->userObj  = new \MyApp\User;
            echo "WebSocket Server is Started\n";
        }

        /**
         * Called when a new connection is opened.
         *
         * @param ConnectionInterface $conn The new connection object.
         */
        public function onOpen(ConnectionInterface $conn) {
            // Store the new connection to send messages to later
            $queryString = $conn->httpRequest->getUri()->getQuery();
            parse_str($queryString, $query);

            if($data = $this->userObj->getUserBySession($query['token'])){
                $this->data  = $data;
                $conn->data  = $data;
                $this->clients->attach($conn);
                $this->userObj->updateConnection($conn->resourceId, $data->userID);
                echo "New connection! ({$data->username})\n";
            }
        }

        /**
         * Called when a message is received from a client.
         *
         * @param ConnectionInterface $from The sender's connection object.
         * @param string $msg The received message.
         */
        public function onMessage(ConnectionInterface $from, $msg) {
            $numRecv = count($this->clients) - 1;
            echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
                , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');
            $data  = json_decode($msg, true);
            $sendTo  = $this->userObj->userData($data['sendTo']);

            $send['sendTo']        = $sendTo->userID;
            $send['by']            = $from->data->userID;
            $send['profileImage']  = $from->data->profileImage;
            $send['username']      = $from->data->username;
            $send['type']          = $data['type'];
            $send['data']          = $data['data'];

            foreach ($this->clients as $client) {
                if ($from !== $client) {
                    // The sender is not the receiver, send to each client connected
                    if($client->resourceId == $sendTo->connectionID || $from == $client){
                        $client->send(json_encode($send));
                    }
                }
            }
        }

        /**
         * Called when a connection is closed.
         *
         * @param ConnectionInterface $conn The closed connection object.
         */
        public function onClose(ConnectionInterface $conn) {
            // The connection is closed, remove it, as we can no longer send it messages
            $this->clients->detach($conn);

            echo "Connection {$conn->resourceId} has disconnected\n";
        }

        /**
         * Called when an error occurs.
         *
         * @param ConnectionInterface $conn The connection where the error occurred.
         * @param \Exception $e The exception representing the error.
         */
        public function onError(ConnectionInterface $conn, \Exception $e) {
            echo "An error has occurred: {$e->getMessage()}\n";

            $conn->close();
        }
    }
