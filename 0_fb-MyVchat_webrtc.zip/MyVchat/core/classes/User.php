<?php
	namespace MyApp;
	use PDO;
	class User{
		public $db, $userID, $sessionID,$error;

		public function __construct(){
			$db  = new \MyApp\DB;
			$this->db = $db->connect();
			$this->userID = $this->ID();
			$this->sessionID = $this->getSessionID();
		}

		/**
		 * Returns the error message.
		 *
		 * @return string The error message.
		 */
		public function errors() {
		    return $this->error;
		}

		/**
		 * Get the user's ID if they are logged in.
		 *
		 * @return int|null The user's ID or null if not logged in.
		 */
		public function ID(){
		    if($this->isLoggedIn()){
		        return $_SESSION['userID'];
		    }
		}

		/**
		 * Get the current session ID.
		 *
		 * @return string The session ID.
		 */
		public function getSessionID(){
		    return session_id();
		}


		/**
		 * Check if an email exists in the database.
		 *
		 * @param string $email The email address to check.
		 *
		 * @return mixed If the email exists, returns a user object. Otherwise, returns false.
		 */
		public function emailExist($email){
		    // Prepare a database query to select a user by email
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `email` = :email");
		    
		    // Bind the email parameter to the prepared statement
		    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch the user as an object
		    $user = $stmt->fetch(PDO::FETCH_OBJ);

		    // Check if a user with the given email exists
		    if(!empty($user)){
		        // Return the user object
		        return $user;
		    }else{
		        // Return false if no user with the given email exists
		        return false;
		    }
		}


		//Method to check if username is already exist in the database
		public function usernameExist($username) {
		    // Prepare the SQL statement to check if the username exists in the `users` table
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `username` = :username");
		    
		    // Bind the username parameter to the prepared statement
		    $stmt->bindParam(":username", $username, PDO::PARAM_STR);
		    
		    // Execute the prepared statement
		    $stmt->execute();
		    
		    // Fetch the result as an object
		    $data = $stmt->fetch(PDO::FETCH_OBJ);
		    
		    if (!empty($data)) {
		        // Username exists, return the data object
		        return $data;
		    } else {
		        // Username does not exist, return false
		        return false;
		    }
		}


		//Method to encrypt the user password
		public function hash($password) {
		    // Hash the password using the default hashing algorithm
		    return password_hash($password, PASSWORD_DEFAULT);
		}

		//Method to redirect user to a provided location 
		public function redirect($location){
			header("Location: ".BASE_URL.$location);
			exit;
		}

		//Method to check if user is logged in 
		public function isLoggedIn(){
			return ((isset($_SESSION['userID'])) ? true : false);
		}

		/**
		 * Logs out the user by destroying the session and redirecting to the index page.
		 */
		public function logout() {
		    $_SESSION = array(); // Clear all session variables
		    session_destroy(); // Destroy the session
		    session_regenerate_id(); // Regenerate a new session ID for security
		    $this->redirect('index.php'); // Redirect to the index page
		}

		/**
		 * Get user data based on a given user ID.
		 *
		 * @param string $userID (Optional) The user ID for which to retrieve data. If empty, uses the currently logged-in user's ID.
		 *
		 * @return mixed|null If user data is found, returns a user object. Otherwise, returns null.
		 */
		public function userData($userID = ''){
		    // Determine the user ID to use (either the provided one or the currently logged-in user's ID)
		    $userID = ((!empty($userID)) ? $userID : $this->userID);
		    
		    // Prepare a database query to select user data by user ID
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `userID` = :userID");
		    
		    // Bind the user ID parameter to the prepared statement
		    $stmt->bindParam(":userID", $userID, PDO::PARAM_STR);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch the user data as an object
		    return $stmt->fetch(PDO::FETCH_OBJ);
		}


		/**
		 * Get a list of users (excluding the currently logged-in user).
		 *
		 * @return void Outputs a list of users as HTML elements.
		 */
		public function getUsers(){
		    // Prepare a database query to select all users except the currently logged-in user
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `userID` != :userID");
		    
		    // Bind the user ID parameter to the prepared statement
		    $stmt->bindParam(":userID", $this->userID, PDO::PARAM_INT);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch all users as an array of objects
		    $users = $stmt->fetchAll(PDO::FETCH_OBJ);

		    // Loop through each user and generate HTML output
		    foreach($users as $user){
		        echo '<li class="select-none transition hover:bg-green-50 p-4 cursor-pointer select-none">
		                <a href="'.BASE_URL.$user->username.'">
		                    <div class="user-box flex items-center flex-wrap">
		                    <div class="flex-shrink-0 user-img w-14 h-14 rounded-full border overflow-hidden">
		                        <img class="w-full h-full" src="'.BASE_URL.$user->profileImage.'">
		                    </div>
		                    <div class="user-name ml-2">
		                        <div><span class="flex font-medium">'.$user->name.'</span></div>
		                        <div></div>
		                    </div>
		                    </div>
		                </a>
		            </li>';
		    }
		}

		/**
		 * Get user data by their username.
		 *
		 * @param string $username The username to search for.
		 *
		 * @return mixed|null If a user with the given username is found, returns their data as an object. Otherwise, returns null.
		 */
		public function getUserByUsername($username){
		    // Prepare a database query to select a user by their username
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `username` = :username");
		    
		    // Bind the username parameter to the prepared statement
		    $stmt->bindParam(":username", $username, PDO::PARAM_STR);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch the user data as an object
		    return $stmt->fetch(PDO::FETCH_OBJ);
		}

		/**
		 * Update the session ID for the current user.
		 */
		public function updateSession(){
		    // Prepare a database query to update the session ID for the current user
		    $stmt = $this->db->prepare("UPDATE `users` SET `sessionID` = :sessionID WHERE `userID` = :userID");
		    
		    // Bind the session ID and user ID parameters to the prepared statement
		    $stmt->bindParam(":sessionID", $this->sessionID, PDO::PARAM_STR);
		    $stmt->bindParam(":userID", $this->userID, PDO::PARAM_INT);
		    
		    // Execute the query to update the session ID
		    $stmt->execute();
		}


		/**
		 * Get user data by their session ID.
		 *
		 * @param string $sessionID The session ID to search for.
		 *
		 * @return mixed|null If a user with the given session ID is found, returns their data as an object. Otherwise, returns null.
		 */
		public function getUserBySession($sessionID){
		    // Prepare a database query to select a user by their session ID
		    $stmt = $this->db->prepare("SELECT * FROM `users` WHERE `sessionID` = :sessionID");
		    
		    // Bind the session ID parameter to the prepared statement
		    $stmt->bindParam(":sessionID", $sessionID, PDO::PARAM_STR);
		    
		    // Execute the query
		    $stmt->execute();
		    
		    // Fetch the user data as an object
		    return $stmt->fetch(PDO::FETCH_OBJ);
		}

		/**
		 * Update the connection ID for a user.
		 *
		 * @param string $connectionID The connection ID to set for the user.
		 * @param int $userID The user ID of the user whose connection ID is being updated.
		 */
		public function updateConnection($connectionID, $userID){
		    // Prepare a database query to update the connection ID for a user
		    $stmt = $this->db->prepare("UPDATE `users` SET `connectionID` = :connectionID WHERE `userID` = :userID");
		    
		    // Bind the connection ID and user ID parameters to the prepared statement
		    $stmt->bindParam(":connectionID", $connectionID, PDO::PARAM_STR);
		    $stmt->bindParam(":userID", $userID, PDO::PARAM_INT);
		    
		    // Execute the query to update the connection ID
		    $stmt->execute();
		}

		/**
		 * Create a new user in the database.
		 *
		 * @param string $name The name of the user.
		 * @param string $username The username of the user.
		 * @param string $email The email address of the user.
		 * @param string $password The password of the user.
		 * @param string $image The profile image of the user.
		 *
		 * @return int The ID of the newly created user.
		 */
		public function createUser($name, $username, $email, $password, $image){
		    // Prepare a database query to insert a new user
		    $stmt = $this->db->prepare("INSERT INTO `users` (`username`, `name`, `email`, `password`, `profileImage`) VALUES (:name, :username, :email, :password, :profileImage)");
		    
		    // Bind the user data parameters to the prepared statement
		    $stmt->bindParam(":name", $name, PDO::PARAM_STR);
		    $stmt->bindParam(":username", $username, PDO::PARAM_STR);
		    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
		    $stmt->bindParam(":password", $password, PDO::PARAM_STR);
		    $stmt->bindParam(":profileImage", $image, PDO::PARAM_STR);
		    
		    // Execute the query to create the new user
		    $stmt->execute();
		    
		    // Return the ID of the newly created user
		    return $this->db->lastInsertId();
		}



		/**
		 * Uploads a file to the server.
		 *
		 * @param array $file The uploaded file data.
		 * @return string|bool The uploaded file path if successful, or false if there was an error.
		 */
		public function upload($file) {
		    $fileInfo = getimagesize($file['tmp_name']);
		    $fileTmp = $file['tmp_name'];
		    $filename = basename($file['name']);
		    $fileSize = $file['size'];
		    $errors = $file['error'];
		    
		    // Get the file extension
		    $ext = explode('.', $filename);
		    $ext = strtolower(end($ext));

		    //Array to allow image extensions
		    $allowed = ['image/png', 'image/jpeg', 'image/jpg'];
		    
		    //check if file extension exist in allowed array
		    if (!in_array($fileInfo['mime'], $allowed)) {
		        $this->error = "File extension is not allowed";
		    } else {
                // Get the parent directory two levels above the current directory
		        $parentDirectory = dirname(dirname(dirname(__FILE__)));
                //path to store images 
		        $folder = '/assets/images/';
		        // Generate random filename
		        $uploadFile = $folder . md5(time() . mt_rand()) . '.' . $ext;
		        //Check if there is no error
		        if ($errors === 0) {
		        	//Check if file size is less than or equal to 5mb max
		            if ($fileSize <= 5000000) {
		            	//Upload the image file
		                move_uploaded_file($fileTmp, $parentDirectory . $uploadFile);
		                //return the file location
		                return $uploadFile;
		            } else {
		            	//return error if file size is large
		                $this->error = "File is too large!";
		            }
		        }
		    }
		    
		    return false; // Return false if there was an error
		}


	}