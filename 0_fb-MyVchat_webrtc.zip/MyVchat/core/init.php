<?php 
	// Start a new session or resume the existing session
	session_start();

	// Include necessary classes
	require 'classes/DB.php';
	require 'classes/User.php';

	// Create an instance of the User class
	$userObj = new \MyApp\User;

	// Define the base URL for the application
	define('BASE_URL', 'http://localhost/MyVchat/');
