<?php
    // Include the initialization file
    include 'core/init.php';

    // Check if the user is already logged in, and if so, redirect them to the index page
    if ($userObj->isLoggedIn()) {
        $userObj->redirect('index.php');
    }

    // Check if the request method is POST
    if ($_SERVER['REQUEST_METHOD'] === "POST") {
        // Check if the POST data is set
        if (isset($_POST)) {
            // Sanitize and validate user input
            $name     = trim(stripcslashes(htmlentities($_POST['name'])));
            $username = trim(stripcslashes(htmlentities($_POST['username'])));
            $email    = trim(stripcslashes(htmlentities($_POST['email'])));
            $password = $_POST['password'];

            // Check if all required fields are not empty
            if (!empty($name) && !empty($username) && !empty($email) && !empty($password)) {
               
                // Check the length of the username
                if (strlen($username) < 4) {
                    $error = 'Choose a username 3-30 characters long';
                } else if ($userObj->usernameExist($username)) {
                    $error = 'Username is already taken';
                } else if (strlen($password) <= 3) {
                    $error = "Password must be 3-30 characters long";
                } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error = "Invalid Email format!";
                } else if ($userObj->emailExist($email)) {
                    $error = "Email is already in use";
                } else {
                     // Check if an image file is uploaded, and if so, upload it
                    if (!empty($_FILES['image']['name'][0])) {
                        $image = $userObj->upload($_FILES['image']);
                    } else {
                        $image = 'assets/images/avatar.png';
                    }

                    // Hash the user's password
                    $hash = $userObj->hash($password);
                    session_regenerate_id();
                    // Create a new user and store their ID in the session
                    $id = $userObj->createUser($name, $username, $email, $hash, $image);
                    $_SESSION['userID'] = $id;
                    // Redirect to the home page
                    $userObj->redirect('home.php');
                }
            } else {
                $error = 'All fields are required!';
            }
        }
    }

?>
<html>
<head>
    <title>Create a new account  - MyVchat - A Real Time Video Chat System Using WebRTC, PHP, MySQL, JavaScript</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Tailwind Link -->
    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <!-- Font Awesome Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- CSS Link -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">
    <!-- Jquery Link -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

</head>
<body>
<!--WRAPPER-->
<div class=" wrapper h-screen items-center justify-center flex">

<div class="inner rounded flex bg-white w-4/5 border" style="height:80%; margin-bottom:5%;">
    <!--LEFT_SIDE-->
    <div class="w-2/5 border-r">
        <div class="select-none flex h-full items-center justify-center">
            <img class="select-none w-4/5" src="assets/images/login-left-bg.png">
        </div>
    </div><!--LEFT_SIDE_END-->  

    <!--RIGHT_SIDE-->
    <div class="flex-2 flex rounded-xl w-full h-full ">
        <!--PROFILE_SECTION-->
        <div class=" flex flex-1 justify-center items-center">
            <div class="flex flex-col flex-1 h-full overflow-hidden overflow-y-auto items-center justify-start">
            
                
                <div class="right-heading w-full flex flex-col items-center">
                    
                <form method="post" class="w-full" enctype="multipart/form-data">
                 <div class="w-full flex flex-col items-center">
                    <div class="">
                            <div class="flex-1 items-center">
                                <div class="mt-10 w-60 h-60 right-img rounded-full">
                                    <img id="profileImg" class="h-full w-full" src="assets/images/avatar.png">
                                    
                                </div>
                                <span class="px-2 text-gray-500">Profile Image</span>
                                <div class="flex justify-center flex-1">
                                    <label for="image-up">
                                        <span class="text-4xl cursor-pointer"><i class="fas fa-upload"></i></span>
                                    </label>
                                    <input class="hidden"id="image-up" type="file" name="image">
                                </div>
                            </div>
                        </div>
                    <div class="flex w-2/4 flex-col my-2 items-center">
                        <input class="w-4/5 my-2 border border-gray-200 rounded px-4 py-2" type="text" name="name" placeholder="Name">

                        <input class="w-4/5 my-2 border border-gray-200 rounded px-4 py-2" type="text" name="username" placeholder="Username">

                        <input class="w-4/5 my-2 border border-gray-200 rounded px-4 py-2" type="email" name="email" placeholder="Email">

                        <input class="w-4/5 my-2 border border-gray-200 rounded px-4 py-2" type="password" name="password" placeholder="Password">

                         <div class="select-none  error text-red-500 text-xs p-2 px-2 w-auto self-start ml-20">
                            <!-- ERROR -->
                            <?php 
                                if(isset($error)){
                                    echo $error;
                                }else if($error = $userObj->errors()){
                                    echo $error;
                                }
                            ?>
                        </div>
                    </div>
                       
                    <div>
                    <button class="active:-top-2 relative transition border border-gray-400 shadow-md my-4 bg-green-400 hover:bg-green-500 p-2 px-20 rounded-full text-white text-xl">Sign up</button>
                    </div>
                    <p>Already have a account?, <a href="index.php" class="font-black">Login</a></p>
                 </div>
                </form>
                </div>
                
            </div>
        </div>
        <!--PROFILE_SECTION_END-->
    </div>
    <!--RIGHT_SIDE_END-->
</div><!--INNER_ENDS-->
</div><!--WRAPPER ENDS-->
<script>
    // This function validates the selected file before uploading
    function validateFile(fileInput) {
        // Get information about the selected file
        const fileInfo = fileInput.files[0];
        
        // Extract the file extension and convert it to lowercase
        const fileExtension = fileInfo.name.split('.').pop().toLowerCase();
        
        // Define an array of allowed file extensions (in this case, 'png', 'jpeg', and 'jpg')
        const allowedExtensions = ['png', 'jpeg', 'jpg'];
        
        // Check if the file extension is not in the list of allowed extensions
        if (!allowedExtensions.includes(fileExtension)) {
            return 'File extension is not allowed';
        }
        
        // Check if the file size exceeds 5,000,000 bytes (approximately 5MB)
        if (fileInfo.size > 5000000) {
            return 'File is too large!';
        }

        // If both checks pass, return null to indicate that validation is successful
        return null; // Validation passed
    }

    // This code block runs when the user selects an image to upload
    $('#image-up').change(function(e) {
        // Get a reference to the file input element with the ID 'image-up'
        const fileInput = document.getElementById('image-up'); // Replace with your file input element's ID
        
        // Call the validateFile function to check if the selected file is valid
        const error = validateFile(fileInput);
        
        // If there is an error (i.e., the file is not valid), display an alert with the error message
        if (error) {
            alert(error); // Display the error message
        } else {
            // If the file is valid, read its content and display it as an image
            let file = e.target.files[0];
            let reader = new FileReader();
            
            // When the file reading is complete, set the source of the 'profileImg' element to the file's data URL
            reader.onload = function(e) {
                $('#profileImg').attr('src', e.target.result);
            }
            
            // Start reading the file as a data URL
            reader.readAsDataURL(file);
        }
    });

</script>
</body>
</html>