To set up this application, please follow the steps below:

    Create a new MySQL database named it 'MyVchat' using PHPMyAdmin.
    Import the 'MyVchat.sql' file into your 'MyVchat' database. In PHPMyAdmin, navigate to 'MyVchat' -> 'Import' tab. Choose the SQL file and click on the 'Go' button.
    Open the 'init.php' file located in the 'core' directory. Set your localhost URL within the file.
    Open the 'db.php' file located in the 'core/classes' directory. Set your database name, MySQL user, and password within the file.
    If you are not using localhost, modify the WebSocket URL in the 'home.php' and 'connect.php' files.
    and also in main.js search for redirectToCall function and update the MyChat to your domain

    after you logged in, go to your project root directory and open up your terminal and type php bin/server.php 
    and it should print "websocket server is started"   

By following these steps, you will be able to successfully configure the application for your desired environment.

Test Account
Email aizaz.dinho@meralesson.com
Password password

Email dany@example.com
Password password


Note: Make sure you have a web server environment set up (such as Apache or Nginx) with PHP, AND PHP CLI and MySQL support before running the app. or use xampp 

Need Help? 
contact me here
https://www.facebook.com/aizaz.dinho/