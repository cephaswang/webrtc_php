package tw.ibiz.yukachat

/* deepseek

LoginActivity
Android 12 kotlin 語言設定

由上而下

圖檔，居中 yuka_logo，版面(CircleImageView)
文字，歡迎使用 Yuka AI Chat
文字，帳號*，靠左
輸入框，提示(請輸入帳號)，版面(灰色圓角外框)
文字，密碼*，靠左
輸入框，提示(請輸入密碼)，版面(灰色圓角外框)
按鍵，文字(登入)，版面(#2196F3色圓角外框)，事件，打印
文字，註冊帳號，灰色，靠左，事件，打印
文字，忘記密碼，灰色，靠左，事件，打印

*/



import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        // 登入按鈕點擊事件
        val backButton: Button = findViewById(R.id.login_button)
        backButton.setOnClickListener {
            Log.d("LoginActivity", "登入按鈕被點擊")
            // finish() // 結束當前 Activity
        }

        // 註冊帳號點擊事件
        val registerText: TextView = findViewById(R.id.register_text)
        registerText.setOnClickListener {
            Log.d("LoginActivity", "註冊帳號被點擊")
            // finish() // 結束當前 Activity
        }


        // 忘記密碼點擊事件
        val forgotPasswordText: TextView = findViewById(R.id.forgot_password_text)
        forgotPasswordText.setOnClickListener {
            Log.d("LoginActivity", "忘記密碼被點擊")
        }
    }
}