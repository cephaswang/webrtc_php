package tw.ibiz.yukachat



/*

ConversationsActivity
Android 12 kotlin 聊天主頁面

運行 firebase  並傳給 API token


ConversationsActivity
Android 12 kotlin 聊天主頁面

標題∶聊天主頁面

標題列：
由左而右
頭像：藍色圓型圖示，底色白
文字：聊天主頁面，靠左
按鍵：新增好友，藍色圓型圖示，底色白，btnAddFriend
按鍵：設定藍色圓型圖示，底色白，btnSettings

搜尋列：
按鍵∶搜尋，圓型圖示，底灰色，btnSearch
輸入框，提示文字：搜尋訊息etSearch，背景倒圓灰色

按鍵事件，打印訊息

好友列表TableView rvFriendList

好友列表點擊事件，打印訊息

自定義單筆視圖
左側為頭像，圖檔來自網址，若檔案不存在，則用系統圖示，版面(CircleImageView)
中間兩行，第一行姓名，第二行訊息文字，
右側，訊息時間，文字格式，單行。
資料取自 json messageList ，
target_name 姓名，
target_figure 頭像，
late_message 訊息文字，
time_late 訊息時間

中文回答

方法 1：使用 Vector Asset (推薦)
在 Android Studio 添加 ic_user

打開 res/drawable 資料夾
右鍵 > New > Vector Asset
Clip Art 選擇 Account Circle (或類似的頭像圖示)
設定名稱為 ic_user
點擊 Next > Finish
這會自動產生 ic_user.xml 向量圖標，無需手動編寫 XML。

*/


import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await


class ConversationsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversations)

        print("ConversationsActivity onCreate")

        // 獲取 Firebase Token
        CoroutineScope(Dispatchers.IO).launch {
            try {
                print("CoroutineScope Start")
                val token = FirebaseMessaging.getInstance().token.await()
                // 將 token 傳遞給你的 API
                // sendTokenToApi(token)
                print("Firebase token")
                print(token)
            } catch (e: Exception) {
                print("CoroutineScope error")
                e.printStackTrace()
            }
        }

        // 設定按鈕點擊事件
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            println("設定按鈕被點擊")
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        // 新增好友按鈕點擊事件
        findViewById<ImageButton>(R.id.btnAddFriend).setOnClickListener {
            println("新增好友按鈕被點擊")
        }

        // 搜尋按鈕點擊事件
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            val searchText = findViewById<EditText>(R.id.etSearch).text.toString()
            println("搜尋按鈕被點擊，搜尋內容：$searchText")
        }

        // 模擬 JSON 資料
        val json = """
            [
                {"target_name": "好友1", "target_figure": "https://ims.yukaai.com/archive/user/thumbnail/QV9wcm9mZXNzaW9uYWxfaGVhZHNob3Rfb2ZfYV9tYW5fbmFtZWRfV2VpLVJlbl9DaGUuMDE2ODQxMDc3.jpg", "late_message": "你好！", "time_late": "12:00"},
                {"target_name": "好友2", "target_figure": "https://ims.yukaai.com/archive/user/thumbnail/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg", "late_message": "在嗎？", "time_late": "13:00"}
            ]
        """

        // 使用 Gson 解析 JSON
        val type = object : TypeToken<List<Friend>>() {}.type
        val friendList: List<Friend> = Gson().fromJson(json, type)

        // 設置 RecyclerView
        val adapter = FriendAdapter(friendList) { friend ->
            println("點擊好友：${friend.targetName}")
        }
        findViewById<RecyclerView>(R.id.rvFriendList).apply {
            layoutManager = LinearLayoutManager(this@ConversationsActivity)
            this.adapter = adapter
        }
    }
}