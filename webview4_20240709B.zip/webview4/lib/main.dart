import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

/*
  https://www.youtube.com/watch?v=q_dsgjGRBsw
  InAppBrowser - Flutter Snippet Series - EP 02

  https://github.com/pichillilorenzo/flutter_inappwebview/issues/1669
*/

  late InAppWebViewController _webViewController;
  String url = "";
  double _progress = 0;
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        key: scaffoldKey,
          appBar: AppBar(
            title: const Text('InAppWebView Example'),
          ),
          body:
          Stack(
            children: [
              InAppWebView(
                initialUrlRequest: URLRequest(
                  url: WebUri.uri(
                      Uri.parse("https://192.168.106.129/fb-messenger/")),
                ),

                onWebViewCreated: (InAppWebViewController controller) {
                  _webViewController = controller;
                },
                onProgressChanged:
                    (InAppWebViewController controller, int progress) {
                  setState(() {
                    _progress = progress / 100;
                  });
                },
                onReceivedServerTrustAuthRequest: (_, challenge) async {
                  return ServerTrustAuthResponse(action: ServerTrustAuthResponseAction.PROCEED);
                },

                onPermissionRequest: (controller, request) async {
                  return PermissionResponse(
                      resources: request.resources,
                      action: PermissionResponseAction.GRANT);
                },

            ),

              _progress < 1 ?
                  SizedBox(height: 3,
                  child: LinearProgressIndicator(
                    value: _progress,
                    backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2),
                  ),
                  ):const SizedBox()
            ],
          ),
      )

      ,);
  }

}


/*
import 'package:flutter/material.dart';
import 'MyWebsite.dart';

void main() {
  runApp(const MyWebsite());
}

*/
