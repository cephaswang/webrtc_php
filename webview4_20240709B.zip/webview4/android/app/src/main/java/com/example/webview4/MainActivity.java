package com.example.webview4;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
