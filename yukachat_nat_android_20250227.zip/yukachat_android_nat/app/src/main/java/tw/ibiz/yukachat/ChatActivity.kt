package tw.ibiz.yukachat

/*

chatgpt
iOS 16 swift. MessageKit  呈現聊天列表，用戶頭像圖示，發送時間
頭像來自網址，頭像若不存在，則用系統頭像圖示
隨機生成三天，12筆記錄，含文字，圖片，各半

將同一日歸類在同一區塊
以日期為標簽
focus 到最後一筆記錄

android 13 kotlin com.stfalcon.chatkit
ChatActivity
呈現聊天列表，用戶頭像圖示，發送時間
頭像來自網址，頭像若不存在，則用系統頭像圖示


android 13 kotlin com.stfalcon.chatkit
ChatActivity

版面下方，
發送照片按鍵 imageButton ，事件，發送圖檔，拍照發送
發送文字訊息編輯框 messageInput
發送按鍵  sendButton

private lateinit var messagesListAdapter: MessagesListAdapter<Message>
private lateinit var messagesList: MessagesList


android studio application (tw.ibiz.yukachat)  建立module chatkit
將 module 編譯為 .aar 給其它專案 android 13 引用
./gradlew :chatkit:build --warning-mode all
./gradlew :chatkit:assembleRelease --warning-mode all


Android com.stfalcon.chatkit 巳停止更新，如何自行發佈更新元件，目前巳編寫好新版本

export USERNAME=your_github_username
export TOKEN=your_github_personal_access_token

./gradlew publish --info

如何將目錄電腦上的目錄 chatkit 內檔案發佈到
https://github.com/cephaswang/chatkit


android studio 2024 uses unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details. 如何排除

這個問 DeepSeek 會有生成的程式範例，可參考
ChatActivity
Android 12 kotlin 聊天主頁面
手機端
com.stfalcon.chatkit
服務器端 websocket
apache php mysql

手機John發送照片給Mary，手機John發送文字給Mary(照片發給你了)，Mary回覆(收到)
請生成手機端與伺服器程式

John 發送拍照檔案給 Mary，
拍照後經 http 上傳到伺服器，回應圖檔所在網址
websocket 發送訊息事件給伺服器

 */

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class ChatActivity : AppCompatActivity() {

    companion object {
        const val WRITE_EXTERNAL_STORAGE_REQUEST_CODE = 1001
    }

    private lateinit var messagesListAdapter: MessagesListAdapter<Message>
    private lateinit var messagesList: MessagesList
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var imageButton: ImageButton

    private lateinit var imageLoader: ImageLoader

    private val currentUser = User("1", "Me", null)

    private val REQUEST_CODE_PERMISSIONS = 1001
//    private val client = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).build()


    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        checkPermissions()


        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("ChatActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        messagesList = findViewById(R.id.messagesList)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        imageButton = findViewById(R.id.imageButton)

        messagesList = findViewById(R.id.messagesList)

        imageLoader = ImageLoader { imageView, url, _ ->
            Log.d("ImageLoader", url.toString())

            when {
                // Web URL
                url?.startsWith("http") == true -> {
                    Glide.with(imageView.context)
                        .load(url)
                        .placeholder(R.drawable.default_avatar)
                        .error(R.drawable.default_avatar)
                        .into(imageView)
                    return@ImageLoader
                }
                // Content URI
                url?.startsWith("content://") == true -> {
                    Glide.with(imageView.context)
                        .load(Uri.parse(url))
                        .placeholder(R.drawable.default_avatar)
                        .error(R.drawable.default_avatar)
                        .into(imageView)
                    return@ImageLoader
                }
                // Drawable resource (if url is a resource ID string)
                url?.matches("\\d+".toRegex()) == true -> {
                    Glide.with(imageView.context)
                        .load(url.toInt())
                        .placeholder(R.drawable.default_avatar)
                        .error(R.drawable.default_avatar)
                        .into(imageView)
                    return@ImageLoader
                }

                else -> {
                    // Fallback
                    Glide.with(imageView.context)
                        .load(url)
                        .placeholder(R.drawable.default_avatar)
                        .error(R.drawable.default_avatar)
                        .into(imageView)
                    return@ImageLoader
                }
            }
        }

        // 設置訊息適配器
        messagesListAdapter = MessagesListAdapter("user_1", imageLoader)
        messagesList.setAdapter(messagesListAdapter)

        // 設置發送按鈕點擊事件
        sendButton.setOnClickListener {
            val text = messageInput.text.toString().trim()
            if (text.isNotEmpty()) {
                sendMessage(text, null)
                messageInput.setText("")
            }
        }

        // 設置圖片按鈕點擊事件
        imageButton.setOnClickListener {
            showImagePickerDialog()
        }

        // 生成隨機訊息
        generateRandomMessages()
    }


    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun checkPermissions() {
        val requiredPermissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.READ_MEDIA_IMAGES
        )

        val permissionsToRequest = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest, REQUEST_CODE_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                // 所有權限已經授予
                Log.d("ChatActivity", "所有權限已經授予")
            } else {
                // 權限被拒絕
                Toast.makeText(this, "權限被拒絕", Toast.LENGTH_SHORT).show()
            }
        }
    }


    // 顯示圖片選擇對話框
    private fun showImagePickerDialog() {
        val options = arrayOf("拍照", "選擇圖片")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("選擇圖片來源")
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> takePhoto() // 拍照
                1 -> showImagePicker() // 選擇圖片
            }
        }
        builder.show()
    }

/*
完善程式能成功呈現用戶頭像，圖檔，文字訊息內容
ChatActivity OkHttpClient
*/

    private fun generateRandomMessages() {
        val users = listOf(
            User("user_1", "Alice", "${ConfigIni.SERVER_URL}images/avatar1.jpg"),
            User("user_2", "Bob", "${ConfigIni.SERVER_URL}images/avatar2.jpg"),
            User("user_3", "Charlie", null) // 無頭像
        )

        val messages = mutableListOf<Message>()
        val calendar = Calendar.getInstance()

        for (i in 0 until 12) {
            val user = users.random()

            // 設定三天內的隨機時間
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_MONTH, -Random().nextInt(3))
            val date = calendar.time

            val message = if (i % 2 == 0) {
                // 文字訊息
                Message(UUID.randomUUID().toString(), user, "這是訊息 $i", null, date)
            } else {
                // 圖片訊息
                Message(
                    UUID.randomUUID().toString(),
                    user,
                    null,
                    "${ConfigIni.SERVER_URL}avatar$i.jpg",
                    date
                )
            }

            messages.add(message)
        }

        // 依時間排序
        messages.sortBy { it.getCreatedAt() }

        Log.d("generateRandomMessages",messages.toString())

        // 插入訊息到適配器
        messages.forEach { messagesListAdapter.addToStart(it, true) }

        // 自動滾動到最後一筆
        messagesList.scrollToPosition(messagesListAdapter.itemCount - 1)
    }

    // 發送訊息
    private fun sendMessage(text: String?, imageUrl: String?) {
        val message = Message(UUID.randomUUID().toString(), currentUser, text, imageUrl, Date())
        messagesListAdapter.addToStart(message, true)
        // 自動滾動到最後一筆
        messagesList.scrollToPosition(messagesListAdapter.itemCount - 1)
    }

/*
android kotlin
fun uploadImage(bitmap: Bitmap
// 註冊圖片選擇的
private val selectImageLauncher =
registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
    if (result.resultCode == Activity.RESULT_OK) {

    }
}
將選取圖片發給 uploadImage
*/

    // 註冊圖片選擇的 ActivityResultLauncher
    private val selectImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                data?.data?.let { uri ->
                    val bitmap = getBitmapFromUri(uri)
                    bitmap?.let {
                        uploadImage(it)
                    }
                }
            }
        }

    // 將 Uri 轉換為 Bitmap
    private fun getBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    // 顯示圖片選擇選單
    private fun showImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        selectImageLauncher.launch(intent)
    }

    private var currentPhotoPath: String? = null // 存储当前拍照的照片路径

/*
android kotlin
fun uploadImage(bitmap: Bitmap
// 拍照後處理
private val takePhotoLauncher =
    registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
}
將選取圖片發給 uploadImage
*/
    // 拍照後處理
    private val takePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                currentPhotoPath?.let { path ->
                    val bitmap = BitmapFactory.decodeFile(path)
                    uploadImage(bitmap)
                }
            }
        }

    // 建立暫存檔案
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    // 拍照並存儲到暫存檔案
    private fun takePhoto() {
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: IOException) {
            Log.e("ChatActivity", "Error creating file: ${ex.message}")
            null
        }
        photoFile?.also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                it
            )
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            takePhotoLauncher.launch(intent)
        }
    }

/*
Android 13 kotlin
fun uploadImage(bitmap: Bitmap)
上傳圖檔到伺服 upload.php 圖檔保存在 images 目錄
依時間命名
回傳 json 圖檔訪問網址
*/


    private fun uploadImage( bitmap: Bitmap) {
        val cacheFile = File(cacheDir, "upload.jpg")
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos)
        val bitmapData = bos.toByteArray()

        val fos = FileOutputStream(cacheFile)
        fos.write(bitmapData)
        fos.flush()
        fos.close()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                cacheFile.name,
                cacheFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            )
            .build()

        val request = Request.Builder()
            .url("${ConfigIni.SERVER_URL}upload.php")
            .post(requestBody)
            .build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                Log.e("uploadImage", "Upload failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                if (response.isSuccessful) {
                    try {
                        val json = responseBody?.let { JSONObject(it) }
                        Log.d("uploadImage", json.toString())
                        val imageUrl = json?.getString("imageUrl")
                        Log.d("uploadImage", "Upload successful, image URL: $imageUrl")
                        //sendMessage(null,imageUrl.toString())
                        // 在主线程中更新UI
                        runOnUiThread {
                            sendMessage(null, imageUrl.toString())
                        }
                        // 在這裡處理 imageUrl
                    } catch (e: Exception) {
                        Log.e("uploadImage", "Error parsing JSON: ${e.message}")
                    }
                } else {
                    Log.e("uploadImage", "Upload failed, response code: ${response.code}, body: $responseBody")
                }
            }
        })
    }


}
