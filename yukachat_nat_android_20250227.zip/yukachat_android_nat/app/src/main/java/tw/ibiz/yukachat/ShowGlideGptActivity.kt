package tw.ibiz.yukachat

/*

deepseek

android 13 kotlin
ShowGlideGptActivity
import com.bumptech.glide.Glide

androidx.core.content.FileProvider

四個按鍵事件，呈現四種圖檔範例，
1 網路圖片，若檔案不存在，則改用資源檔ic_user，
2 手機端選取的圖檔(打印檔案位置，打印檔案容量)
3 拍照需建立依時間命名的暫存檔(打印檔案位置，打印檔案容量)
4 資源檔 ic_user

"https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2025/02/26/realtime/31564330.jpg&x=0&y=0&sw=0&sh=0&sl=W&fw=800&exp=3600&w=930&nt=1"

*/

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import android.Manifest
import android.annotation.SuppressLint

class ShowGlideGptActivity : AppCompatActivity() {

    private lateinit var currentPhotoPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_glide_gpt)

        checkCameraPermission()

        // 按鍵1: 載入網路圖片，若檔案不存在則改用資源檔 ic_user
        findViewById<Button>(R.id.button1).setOnClickListener {
            val imageUrl = "https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2025/02/26/realtime/31564330.jpg&x=0&y=0&sw=0&sh=0&sl=W&fw=800&exp=3600&w=930&nt=1"
            Glide.with(this)
                .load(imageUrl)
                .error(R.drawable.ic_user) // 若載入失敗，使用 ic_user
                .into(findViewById(R.id.imageView))
        }

        // 按鍵2: 從手機端選取圖檔
        findViewById<Button>(R.id.button2).setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE)
        }

        // 按鍵3: 拍照並建立依時間命名的暫存檔
        findViewById<Button>(R.id.button3).setOnClickListener {
            dispatchTakePictureIntent()
        }

        // 按鍵4: 載入資源檔 ic_user
        findViewById<Button>(R.id.button4).setOnClickListener {
            Glide.with(this)
                .load(R.drawable.ic_user)
                .into(findViewById(R.id.imageView))
        }
    }
    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            // 权限已授予，继续执行相机操作
          //  openCamera()
        } else {
            // 权限被拒绝，向用户显示提示
            Toast.makeText(this, "需要相机权限才能使用此功能", Toast.LENGTH_SHORT).show()
        }
    }

    fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
           // openCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    @Deprecated("This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      with the appropriate {@link ActivityResultContract} and handling the result in the\n      {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_PICK_IMAGE -> {
                    val selectedImageUri: Uri? = data?.data
                    selectedImageUri?.let { uri ->
                        // 打印檔案位置
                        Log.d("ImagePath", uri.toString())
                        // 打印檔案容量
                        val file = File(getRealPathFromURI(uri))
                        Log.d("FileSize", "${file.length()} bytes")
                        Glide.with(this)
                            .load(uri)
                            .into(findViewById(R.id.imageView))
                    }
                }
                REQUEST_CODE_TAKE_PHOTO -> {
                    Glide.with(this)
                        .load(currentPhotoPath)
                        .into(findViewById(R.id.imageView))
                    // 打印檔案位置
                    Log.d("PhotoPath", currentPhotoPath)
                    // 打印檔案容量
                    val file = File(currentPhotoPath)
                    Log.d("FileSize", "${file.length()} bytes")
                }
            }
        }
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    null
                }
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        "${applicationContext.packageName}.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_CODE_TAKE_PHOTO)
                }
            }
        }
    }

    @SuppressLint("SimpleDateFormat")
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun getRealPathFromURI(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.moveToFirst()
        val idx = cursor?.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
        val path = cursor?.getString(idx ?: 0)
        cursor?.close()
        return path ?: ""
    }

    companion object {
        private const val REQUEST_CODE_PICK_IMAGE = 1001
        private const val REQUEST_CODE_TAKE_PHOTO = 1002
    }
}