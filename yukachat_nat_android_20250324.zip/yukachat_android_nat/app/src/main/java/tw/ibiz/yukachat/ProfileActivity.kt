package tw.ibiz.yukachat


import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLDecoder
import java.net.URLEncoder

/*
ProfileActivity
Android 12 kotlin 帳號頁
由上而下，居中

方型照片：頭像，從網址取得檔案，若取得失敗則用系統頭像
點擊事件，
從檔案選取照片，返回更換頭像
拍照，返回更換頭像

標簽∶名稱，文字靠左
編輯框名稱∶文字框底色∶灰，圓角 10

標簽∶Email，文字靠左
編輯框Email∶文字框底色∶灰，圓角 10

按鍵∶存檔，底色藍
點擊事件，打印 編輯框名稱的值 編輯框Email值
上傳頭像到服務器，編輯框名稱的值 編輯框Email的值
底色∶#2196F3，圓角 10


*/



class ProfileActivity : AppCompatActivity() {

    private lateinit var profileImage: ImageView
    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var saveButton: Button

    private var selectedImageUri: Uri? = null

    private lateinit var Xid: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        Xid = sharedPref.getString("xid", "") ?: ""


        profileImage = findViewById(R.id.profile_image)
        nameEditText = findViewById(R.id.name_edit_text)
        emailEditText = findViewById(R.id.email_edit_text)
        saveButton = findViewById(R.id.save_button)

        apiLoaderDetail(nameEditText, emailEditText, this)

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("SettingsActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        // 加載頭像
        loadProfileImage("https://ims.yukaai.com/archive/user/thumbnail/bGluZS1sb2dvLXcuOTMyOTE0OTcx.jpg")

        // 頭像點擊事件
        profileImage.setOnClickListener {
            showImagePickerOptions()
        }


// 存檔按鈕點擊事件
        saveButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val email = emailEditText.text.toString()
            val encodedName = URLEncoder.encode(name, "UTF-8")
            val encodedEmail = URLEncoder.encode(email, "UTF-8")

            if (name.isNotEmpty() && email.isNotEmpty()) {
                // 打印名稱和 Email
                println("Name: $name, Email: $email")

                // 構建 API 請求 URL
                val url =
                    "${ConfigIni.SERVER_URL}user/app/api/?mode=update&name=$encodedName&email=$encodedEmail&xid=$Xid"
                Log.d("jsonString", url)

                // 使用 OkHttp 發送請求
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url(url)
                    .build()

                client.newCall(request).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        // 請求失敗
                        runOnUiThread {
                            Toast.makeText(
                                this@ProfileActivity,
                                "Network error: ${e.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onResponse(call: Call, response: Response) {
                        if (response.isSuccessful) {
                            // 解析 JSON 回應
                            val jsonString = response.body?.string()
                            if (jsonString != null) {
                                try {
                                    Log.d("jsonString", jsonString)
                                    val jsonObject = JSONObject(jsonString)

                                    val status = jsonObject.getString("status")
                                    val title = jsonObject.getString("title")
                                    val icon = jsonObject.getString("icon")
                                    val message = jsonObject.getString("message")

                                    runOnUiThread {
                                        if (status == "succ") {
                                            // 成功
                                            Toast.makeText(
                                                this@ProfileActivity,
                                                "Profile saved successfully!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        } else {
                                            // 失敗
                                            Toast.makeText(
                                                this@ProfileActivity,
                                                "Failed to save profile: $message",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                } catch (e: Exception) {
                                    // JSON 解析失敗
                                    runOnUiThread {
                                        Toast.makeText(
                                            this@ProfileActivity,
                                            "Failed to parse API response",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            } else {
                                // 回應內容為空
                                runOnUiThread {
                                    Toast.makeText(
                                        this@ProfileActivity,
                                        "Empty API response",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        } else {
                            // 回應不成功
                            runOnUiThread {
                                Toast.makeText(
                                    this@ProfileActivity,
                                    "API error: ${response.message}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                })
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun loadProfileImage(imageUrl: String) {
        Glide.with(this)
            .load(imageUrl)
            .error(R.drawable.default_avatar) // 如果加載失敗，使用默認頭像
            .into(profileImage)
    }

    private fun apiLoaderDetail(nameEditText: EditText, emailEditText: EditText, context: Context) {
        Log.d("LoginResult", "apiLoaderDetail")

        val apiUrl = "${ConfigIni.SERVER_URL}im/app/api/?mode=detail&xid=$Xid"

        Log.d("apiLoaderDetail", apiUrl)

        // 使用 Kotlin 的協程來處理網絡請求
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // 使用 OkHttpClient 發起網絡請求
                val client = OkHttpClient()
                val request = Request.Builder().url(apiUrl).build()
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && !responseBody.isNullOrEmpty()) {

                    Log.d("responseBody",responseBody)

                    // 解析 JSON
                    val jsonObject = JSONObject(responseBody)
                    val status = jsonObject.getString("status")

                    if (status == "succ") {
                        val dataObject = jsonObject.getJSONObject("data")
                        val name = dataObject.getString("name")
                        val email = dataObject.getString("email")
                        val decodedName = URLDecoder.decode(name, "UTF-8")

                        // 更新 UI（切換到主線程）
                        withContext(Dispatchers.Main) {
                            nameEditText.setText(decodedName)
                            emailEditText.setText(email)
                        }
                    } else {
                        Log.e("APIError", "API returned status: $status")
                    }
                } else {
                    Log.e("APIError", "Failed to fetch data: ${response.message}")
                }
            } catch (e: Exception) {
                Log.e("APIError", "Exception occurred: ${e.message}")
            }
        }
    }

    // 擴展函數：簡化網絡請求
    fun Request.Builder.execute(): Response {
        val client = OkHttpClient()
        val request = this.build()
        return client.newCall(request).execute()
    }


    private fun showImagePickerOptions() {
        val options = arrayOf("圖片檔", "拍照")
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("請選擇")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> pickImageFromGallery()
                1 -> takePhoto()
            }
        }
        builder.show()
    }

    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    private fun takePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        photoLauncher.launch(intent)
    }

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                result.data?.data?.let { uri ->
                    selectedImageUri = uri
                    profileImage.setImageURI(uri)
                }
            }
        }


    private val photoLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val imageUri = result.data?.data
                if (imageUri != null) {
                    val inputStream = contentResolver.openInputStream(imageUri)
                    val imageBitmap = BitmapFactory.decodeStream(inputStream)
                    inputStream?.close()
                    profileImage.setImageBitmap(imageBitmap)
                    selectedImageUri = saveImageToCache(imageBitmap)
                }
            }
        }

    private fun saveImageToCache(bitmap: android.graphics.Bitmap): Uri? {
        val file = File(cacheDir, "profile_image.jpg")
        return try {
            file.outputStream().use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 100, out)
            }
            Uri.fromFile(file)
        } catch (e: Exception) {
            null
        }
    }

    private fun uploadProfileImage(imageUri: Uri?) {
        // 實現上傳邏輯
        if (imageUri != null) {
            // 上傳圖像到服務器
        }
    }
}