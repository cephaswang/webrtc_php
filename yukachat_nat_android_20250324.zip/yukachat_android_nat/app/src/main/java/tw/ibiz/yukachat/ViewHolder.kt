package tw.ibiz.yukachat

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.stfalcon.chatkit.messages.MessageHolders
import de.hdodenhof.circleimageview.CircleImageView
import java.text.SimpleDateFormat
import java.util.Locale

// 自定義接收文本消息的 ViewHolder
class CustomIncomingTextMessageViewHolder(itemView: View) :
    MessageHolders.IncomingTextMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val avatarView: CircleImageView? = itemView.findViewById(R.id.messageUserAvatar)

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("a h:mm", Locale("zh", "TW"))
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK) // 設置文字顏色為黑色
        }
        avatarView?.let {
            val avatarUrl = message.getUser().getAvatar()
            if (!avatarUrl.isNullOrEmpty()) {
                imageLoader?.loadImage(it, avatarUrl, null)
            } else {
                it.setImageResource(R.drawable.default_avatar)
            }
        }
    }
}

// 自定義發送文本消息的 ViewHolder
class CustomOutcomingTextMessageViewHolder(itemView: View) :
    MessageHolders.OutcomingTextMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val messageTextView: TextView? = itemView.findViewById(R.id.messageText)

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("a h:mm", Locale("zh", "TW"))
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK) // 設置文字顏色為黑色
        }
        messageTextView?.let {
            it.text = message.getText() // 確保文字更新
            it.setTextColor(android.graphics.Color.WHITE) // 強制設為黑色
        }
    }
}

// 自定義接收圖片消息的 ViewHolder
class CustomIncomingImageMessageViewHolder(itemView: View) :
    MessageHolders.IncomingImageMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)
    private val avatarView: CircleImageView? = itemView.findViewById(R.id.messageUserAvatar)

    override fun onBind(message: ChatMessage) {
        super.onBind(message)
        timeView?.let {
            val formatter = SimpleDateFormat("a h:mm", Locale("zh", "TW"))
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK) // 設置文字顏色為黑色
        }
        // 加載頭像
        avatarView?.let {
            val avatarUrl = message.getUser().getAvatar()
            if (!avatarUrl.isNullOrEmpty()) {
                imageLoader?.loadImage(it, avatarUrl, null)
            } else {
                it.setImageResource(R.drawable.default_avatar)
            }
        }
    }
}

// 自定義發送圖片消息的 ViewHolder
class CustomOutcomingImageMessageViewHolder(itemView: View) :
    MessageHolders.OutcomingImageMessageViewHolder<ChatMessage>(itemView) {

    private val timeView: TextView? = itemView.findViewById(R.id.messageTime)

    override fun onBind(message: ChatMessage) {
        super.onBind(message)

        timeView?.let {
            val formatter = SimpleDateFormat("a h:mm", Locale("zh", "TW"))
            it.text = formatter.format(message.getCreatedAt())
            it.setTextColor(android.graphics.Color.BLACK) // 設置文字顏色為黑色
        }
    }
}