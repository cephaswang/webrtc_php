package tw.ibiz.yukachat


/*


ConversationsActivity
Android 12 kotlin 聊天主頁面

運行 firebase  並傳送 API token 到服務器
新增，當接收到推播時，呈現推播訊息完整內容

ConversationsActivity
Android 12 kotlin 聊天主頁面

標題∶聊天主頁面

標題列：
由左而右
頭像：藍色圓型圖示，底色白
文字：聊天主頁面，靠左
按鍵：新增好友，藍色圓型圖示，底色白，btnAddFriend
按鍵：設定藍色圓型圖示，底色白，btnSettings

搜尋列：
按鍵∶搜尋，圓型圖示，底灰色，btnSearch
輸入框，提示文字：搜尋訊息etSearch，背景倒圓灰色

按鍵事件，打印訊息

好友列表TableView rvFriendList

好友列表點擊事件，打印訊息

自定義單筆視圖
左側為頭像，圖檔來自網址，若檔案不存在，則用系統圖示，版面(CircleImageView)
中間兩行，第一行姓名，第二行訊息文字，
右側，訊息時間，文字格式，單行。
資料取自 json messageList ，
target_name 姓名，
target_figure 頭像，
late_message 訊息文字，
time_late 訊息時間

中文回答

方法 1：使用 Vector Asset (推薦)
在 Android Studio 添加 ic_user

打開 res/drawable 資料夾
右鍵 > New > Vector Asset
Clip Art 選擇 Account Circle (或類似的頭像圖示)
設定名稱為 ic_user
點擊 Next > Finish
這會自動產生 ic_user.xml 向量圖標，無需手動編寫 XML。


ConversationsActivity
Android 12 kotlin 聊天主頁面

onstart()

延遲 1 秒
讀取 cmark 寫入 SharedPreferences 記錄
若存在，則 fun apiLodaer_list(cmark)

apiLodaer_list()
server_address/im/app/api/?mode=target_list&cmark=cmark
read_list() 讀取回傳json，打印


ConversationsActivity
Android 12 kotlin 聊天主頁面




========================================================================

ConversationsActivity
Android 12 kotlin 聊天主頁面
完整 import

fun sendTokenToServer() 發送 Token 到服務器 不用 okhttp

val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
讀取 token 寫入 SharedPreferences 記錄
如果 token 未定義，則打印 "token 未定義" 返回

發送到 token API
val apiUrl = "https://ims.yukaai.com/app/api/?mode=token&device=android&token=$token&language=tw"
fun read_cmark
解析回傳 json
cmark 若有值，則寫入 sharedPref，打印

========================================================================

ConversationsActivity
Android 12 kotlin 聊天主頁面
完整 import

fun checkLoginStatus 檢查題否巳登入 不用 okhttp
val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
讀取 cmark 寫入 SharedPreferences 記錄
如果 cmark 未定義，則打印 "getFirebaseToken()"

cmark 有定義則
讀取 account 寫入 SharedPreferences 記錄
讀取 password 寫入 SharedPreferences 記錄

發送到 log_in API
https://ims.yukaai.com/user/app/api/?mode=log_in&is_uu=(account)&is_pp=(password)&cmark=(cmark)
fun loginResult
解析回傳 json
status 的值若等於 succ 打印登入成功 不等於 打印登入失敗
title 打印值  跳轉下頁 LoginActivity
0900010093 / qaWS12
0921000111 / qaWS12

android 13 kotlin
ConversationsActivity
讀取檔案
assets/target_list.json
解析

*/


import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL


class ConversationsActivity : AppCompatActivity() {

    private lateinit var sharedPref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversations)

        print("ConversationsActivity onCreate")

        sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

        // 設定按鈕點擊事件
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            println("設定按鈕被點擊 SettingsActivity")
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        // 新增好友按鈕點擊事件
        findViewById<ImageButton>(R.id.btnAddFriend).setOnClickListener {
            println("新增好友按鈕被點擊")
        }


        // 搜尋按鈕點擊事件
        findViewById<ImageButton>(R.id.btnSearch).setOnClickListener {
            val searchText = findViewById<EditText>(R.id.etSearch).text.toString()
            println("搜尋按鈕被點擊，搜尋內容：$searchText")
        }

    }

    private fun loadJSONFromAsset(context: Context, fileName: String): String? {
        return try {
            val inputStream: InputStream = context.assets.open(fileName)
            val size: Int = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            String(buffer, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    override fun onStart() {
        super.onStart()

        // 檢查是否已登入
        checkLoginStatus()
    }


    private fun apiLoaderList() {
        Log.d("LoginResult", "apiLoaderList")
        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val xid = sharedPref.getString("xid", "") ?: ""
        val apiUrl = "${ConfigIni.SERVER_URL}im/app/api/?mode=target_list&xid=$xid"

        Log.d("apiLoaderList:apiUrl", apiUrl)

        Thread {
            try {
                val url = URL(apiUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val reader = BufferedReader(InputStreamReader(connection.inputStream))
                    val response = reader.readText()
                    reader.close()

                    Log.d("API_RESPONSE", response)

                    val jsonString = response // loadJSONFromAsset(this, "target_list.json")
                    try {
                        val jsonObject = jsonString?.let { JSONObject(it) }
                        val status = jsonObject?.getString("status")
                        if (status == "succ") {
                            val dataArray: JSONArray = jsonObject.getJSONArray("data")
                            val type = object : TypeToken<List<Friend>>() {}.type
                            val friendList: List<Friend> =
                                Gson().fromJson(dataArray.toString(), type)
                            // 設置 RecyclerView
                            val adapter = FriendAdapter(friendList) { friend ->
                                println("")
                                println("點擊好友：${friend.targetName}")
                                println("點擊好友：${friend.targetXid}")
                                val intent = Intent(this, ChatActivity::class.java)
                                intent.putExtra("targetXid", friend.targetXid)
                                intent.putExtra("targetFigure", friend.targetFigure)
                                startActivity(intent)
                            }

                            runOnUiThread {
                                findViewById<RecyclerView>(R.id.rvFriendList).apply {
                                    layoutManager = LinearLayoutManager(this@ConversationsActivity)
                                    this.adapter = adapter
                                }
                            }

                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    //parseJson(response)
                } else {
                    Log.e("API_ERROR", "Response Code: $responseCode")
                }

                connection.disconnect()
            } catch (e: Exception) {
                Log.e("API_ERROR", "Exception: ${e.message}")
            }
        }.start()
    }

    private fun parseJson(response: String) {
        try {
            val jsonObjectC = JSONObject(response)
            val jsonArray = jsonObjectC.getJSONArray("data")
            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val targetXid = jsonObject.optString("target_xid", "Unknown")
                val lateMessage = jsonObject.optString("late_message", "")
                val timeLate = jsonObject.optString("time_late", "")

                Log.d("JSON_PARSE", "Name: $targetXid, Message: $lateMessage, Time: $timeLate")
            }
        } catch (e: Exception) {
            Log.e("JSON_ERROR", "Exception: ${e.message}")
        }
    }

    /*
    登入 login fun
    val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
    從全域記錄讀取帳號 account ，密碼 password， xid

    如果全域記錄參數不完整，則結束。

    訪問 api
    https://ims.yukaai.com/user/app/api/?mode=log_in&is_uu=(account)&is_pp=(password)&xid=(xid)

    讀取回傳 json
    if status == "succ"
    登入成功
    全域記錄 logged_in 設定為 true
    運行 apiLoaderList()

    登入失敗
    全域記錄 logged_in 設定為 false
    跳轉到下一頁 LoginActivity
    fun 結束
    */


    private fun checkLoginStatus() {
        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        val xid = sharedPref.getString("xid", "") ?: ""

        if (xid.isEmpty()) {
            Log.d("LoginStatus", "xid 未定義")
            navigateToLogin()
            return
        }

        val account = sharedPref.getString("account", null)
        val password = sharedPref.getString("password", null)

        if (!account.isNullOrEmpty() && !password.isNullOrEmpty()) {
            val apiUrl =
                "${ConfigIni.SERVER_URL}user/app/api/?mode=log_in&is_uu=${account}&is_pp=${password}&xid=${xid}"
            Log.d("checkLoginStatus", apiUrl)
            loginResult(apiUrl)
        } else {
            Log.d("LoginStatus", "帳號或密碼未存儲")
            // 登入失敗，跳轉到 LoginActivity
            runOnUiThread {
                navigateToLogin()
            }
        }
    }

    private fun loginResult(apiUrl: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL(apiUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    Log.d("LoginResult", response)
                    val jsonObject = JSONObject(response)
                    val status = jsonObject.getString("status")
                    val title = jsonObject.getString("title")

                    Log.d("LoginResult", "title: $title")
                    if (status == "succ") {
                        Log.d("LoginResult", "登入成功")

                        // 提取 sid
                        val dataObject = jsonObject.getJSONObject("data")
                        val sid = dataObject.getString("sid")
                        Log.d("LoginResult sid", sid)

                        // 將 sid 保存在 SharedPreferences
                        val sharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
                        with(sharedPreferences.edit()) {
                            putString("sid", sid)
                            apply()
                        }

                        apiLoaderList()
                    } else {
                        Log.d("LoginResult", "登入失敗")
                        navigateToLogin()
                    }
                } else {
                    Log.e("LoginResult", "API 請求失敗，HTTP 狀態碼: $responseCode")
                }
                connection.disconnect()
            } catch (e: Exception) {
                Log.e("LoginResult", "API 請求錯誤: ${e.message}", e)
            }
        }
    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }


}