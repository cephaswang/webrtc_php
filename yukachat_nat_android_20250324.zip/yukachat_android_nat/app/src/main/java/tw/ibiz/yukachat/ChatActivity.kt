package tw.ibiz.yukachat

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.squareup.picasso.Picasso
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.messages.MessageHolders
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import com.stfalcon.chatkit.utils.DateFormatter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class ChatActivity : AppCompatActivity() {

    companion object {
        const val REQUEST_CODE_PERMISSIONS = 1002
        const val CAMERA_PERMISSION_CODE = 100
        const val CAMERA_REQUEST_CODE = 102
    }

    private lateinit var messagesList: MessagesList
    private lateinit var messagesAdapter: MessagesListAdapter<ChatMessage>
    private lateinit var messageInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var imageButton: ImageButton

    private val messageArray = ArrayList<ChatMessage>()
    private lateinit var userId: String
    private var targetXid = ""
    private val property = "all"
    private var imageUri: Uri? = null

    private var currentPhotoPath: String? = null // 存储当前拍照的照片路径

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    private val displayDateFormat = dateFormat // SimpleDateFormat("a h:mm", Locale("zh", "TW"))

    private val httpClient = OkHttpClient.Builder()
        .readTimeout(3, java.util.concurrent.TimeUnit.SECONDS)
        .build()


    private val messageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("ChatActivity", "Broadcast received: ${intent?.extras}")

            val type = intent?.getStringExtra("type")
            val sid = intent?.getStringExtra("sid")
            val userSid = intent?.getStringExtra("user_sid")
            val name = intent?.getStringExtra("name")
            val figure = intent?.getStringExtra("figure")
            val message = intent?.getStringExtra("message")
            val fileList = intent?.getStringExtra("file_list")

            val timeLate = intent?.getStringExtra("time_late")
            val unread = intent?.getStringExtra("unread")
            val timeAdd = intent?.getStringExtra("time_add")


            when (type) {
                "message" -> {
                    Log.d("ChatActivity", "Received message from $userSid: $message")
                    // Create ChatMessage object and add to message list

                    val chatMessage = ChatMessage(
                        UUID.randomUUID().toString(), // Generate unique ID
                        userSid ?: "", // Sender ID
                        "對方", // Sender name
                        figure ?: "", // Sender avatar URL
                        message ?: "", // Message content
                        null, // Image URL
                        (timeAdd?.let {
                            try {
                                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).parse(it)
                            } catch (e: Exception) {
                                Date()
                            }
                        } ?: Date()) // Parse time_add or use current time if null/invalid
                        // Date() // Current time
                    )
                    runOnUiThread {
                        messagesAdapter.addToStart(chatMessage, true)
                        messagesList.scrollToPosition(0)
                    }

                }

                "file" -> {
                    Log.d("ChatActivity", "Received file from $userSid: ${fileList}")
                    // Create ChatMessage object for file and add to message list
                    val chatMessage = ChatMessage(
                        UUID.randomUUID().toString(), // Generate unique ID
                        userSid ?: "", // Sender ID using user_sid
                        name ?: "對方", // Sender name from JSON, default to "對方"
                        figure ?: "", // Sender avatar URL from JSON
                        null, // Message content is null for file type
                        fileList ?: "", // Use the first file in the list as the image URL
                        (timeAdd?.let {
                            try {
                                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).parse(it)
                            } catch (e: Exception) {
                                Date()
                            }
                        } ?: Date()) // Parse time_add or use current time if null/invalid
                    )
                    runOnUiThread {
                        messagesAdapter.addToStart(chatMessage, true)
                        messagesList.scrollToPosition(0)
                    }
                }
            }
        }
    }


    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // Register broadcast receiver using LocalBroadcastManager
        val filter = IntentFilter("tw.ibiz.yukachat.MESSAGE_RECEIVED")
        LocalBroadcastManager.getInstance(this).registerReceiver(messageReceiver, filter)

        // 註冊廣播接收器
        //   val filter = IntentFilter("tw.ibiz.yukachat.MESSAGE_RECEIVED")
        // Android 13 (API 33) 及以上版本
        //  registerReceiver(messageReceiver, filter, Context.RECEIVER_NOT_EXPORTED)

        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        userId = sharedPref.getString("xid", "") ?: ""

        targetXid = intent.getStringExtra("targetXid").toString()
        Log.d("ChatActivity", "Received targetXid: $targetXid")

        // 啟動前景服務來管理 WebSocket
        val serviceIntent = Intent(this, WebSocketService::class.java)
        serviceIntent.putExtra("userId", userId)
        startForegroundService(serviceIntent)

        checkPermissions()

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("ChatActivity", "返回按鈕被點擊")
            finish()
        }

        // 初始化 UI
        messagesList = findViewById(R.id.messagesList)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        imageButton = findViewById(R.id.imageButton)

        // 設置圖片加載器
        val imageLoader = ImageLoader { imageView, url, payload ->
            if (!url.isNullOrEmpty()) {
                Picasso.get().load(url).placeholder(R.drawable.default_avatar).into(imageView)
            } else {
                imageView.setImageResource(R.drawable.default_avatar)
            }
        }

        // 設置消息適配器並自定義綁定邏輯
        // messagesAdapter = MessagesListAdapter(userId, imageLoader)
        // 創建 MessageHolders 並配置自定義 ViewHolder
        val holders = MessageHolders()

        // 配置接收文本消息
        holders.setIncomingTextConfig(
            CustomIncomingTextMessageViewHolder::class.java,
            R.layout.item_custom_incoming_text_message
        )

        // 配置發送文本消息
        holders.setOutcomingTextConfig(
            CustomOutcomingTextMessageViewHolder::class.java,
            R.layout.item_custom_outcoming_text_message
        )

        // 配置接收圖片消息
        holders.setIncomingImageConfig(
            CustomIncomingImageMessageViewHolder::class.java,
            R.layout.item_custom_incoming_image_message
        )

        // 配置發送圖片消息
        holders.setOutcomingImageConfig(
            CustomOutcomingImageMessageViewHolder::class.java,
            R.layout.item_custom_outcoming_image_message
        )

        // 設置消息適配器
        messagesAdapter = MessagesListAdapter(userId, holders, imageLoader)

        messagesAdapter.setDateHeadersFormatter(object : DateFormatter.Formatter {
            override fun format(date: Date): String {
                val weekDays = arrayOf("日", "一", "二", "三", "四", "五", "六")
                val calendar = Calendar.getInstance().apply { time = date }
                val weekDay = weekDays[calendar.get(Calendar.DAY_OF_WEEK) - 1] // 星期從 1 (週日) 開始
                val sdf = SimpleDateFormat("M 月 d 日($weekDay)", Locale("zh", "TW"))
                return sdf.format(date)
            }
        })

        messagesList.setAdapter(messagesAdapter)

        // 設置圖片按鈕點擊事件
        imageButton.setOnClickListener {
            showImagePickerDialog()
        }

        // 設置發送按鈕點擊事件
        sendButton.setOnClickListener {
            val text = messageInput.text.toString().trim()
            if (text.isNotEmpty()) {
                sendTextMessage(text)
                messageInput.setText("")
            }
        }

        // 獲取歷史消息
        fetchMessages()
    }

    override fun onStop() {
        super.onStop()
        Log.d("ChatActivity", "Activity stopped, WebSocket managed by service")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ChatActivity", "Activity destroyed, stopping WebSocketService")

        // 停止 WebSocketService
        val serviceIntent = Intent(this, WebSocketService::class.java)
        stopService(serviceIntent)

        // Unregister broadcast receiver
        LocalBroadcastManager.getInstance(this).unregisterReceiver(messageReceiver)

        // 取消註冊廣播接收器
        //unregisterReceiver(messageReceiver)
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            return
        } else {
           // Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
            Log.d("permissions","Camera permission denied")
        }
    }

    private fun showImagePickerDialog() {
        checkCameraPermission()
        val options = arrayOf("拍照", "選擇圖片")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("選擇圖片來源")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> takePhoto()
                1 -> showImagePicker()
            }
        }
        builder.show()
    }

    private fun showImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        selectImageLauncher.launch(intent)
    }

    private val selectImageLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                data?.data?.let { uri ->
                    val bitmap = getBitmapFromUri(uri)
                    bitmap?.let { uploadImage(it) }
                }
            }
        }

    private fun uploadImage(bitmap: Bitmap) {
        val cacheFile = File(cacheDir, "upload.jpg")
        val bos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos)
        val bitmapData = bos.toByteArray()

        val fos = FileOutputStream(cacheFile)
        fos.write(bitmapData)
        fos.flush()
        fos.close()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                cacheFile.name,
                cacheFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
            )
            .build()

        val uploadAddress = "${ConfigIni.SERVER_URL}upload.php"
        val request = Request.Builder().url(uploadAddress).post(requestBody).build()

        httpClient.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("uploadImage", "Upload failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                println(responseBody)
                if (response.isSuccessful) {
                    try {
                        val json = responseBody?.let { JSONObject(it) }
                        val imageUrl = json?.getString("imageUrl")
                        Log.d("uploadImage", "Upload successful, image URL: $imageUrl")
                        runOnUiThread { sendImageMessage(imageUrl.toString()) }
                    } catch (e: JSONException) {
                        Log.e("uploadImage", "JSON parsing failed: ${e.message}")
                    }
                } else {
                    Log.e("uploadImage", "Upload failed, response code: ${response.code}")
                }
            }
        })
    }

    private fun getBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            MediaStore.Images.Media.getBitmap(contentResolver, uri)
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun takePhoto() {
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: IOException) {
            Log.e("ChatActivity", "Error creating file: ${ex.message}")
            null
        }
        photoFile?.also {
            val photoURI: Uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", it)
            imageUri = contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                ContentValues().apply {
                    put(MediaStore.Images.Media.TITLE, "New Picture")
                    put(MediaStore.Images.Media.DESCRIPTION, "From the Camera")
                })

            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
        }
    }

    @Deprecated("Deprecated in favor of Activity Result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            try {
                val bitmap = BitmapFactory.decodeStream(contentResolver.openInputStream(imageUri!!))
                uploadImage(bitmap)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun fetchMessages() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url =
                    "${ConfigIni.SERVER_URL}im/app/api/?mode=target_message&xid=${userId}&target_sid=${targetXid}&property=${property}"
                val request = Request.Builder().url(url).build()

                httpClient.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string()
                    responseBody?.let { parseMessages(it) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun checkPermissions() {
        val requiredPermissions =
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.READ_MEDIA_IMAGES)
        val permissionsToRequest = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()

        if (permissionsToRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest, REQUEST_CODE_PERMISSIONS)
        }
    }


    private suspend fun parseMessages(jsonResponse: String) {
        withContext(Dispatchers.Main) {
            try {
                val jsonObject = JSONObject(jsonResponse)
                if (jsonObject.getString("status") == "succ") {
                    val data = jsonObject.getJSONObject("data")
                    if (data.toString().length > 10) {
                        val target = data.getJSONObject("target")
                        val targetName = target.getString("name")
                        val targetFigure = target.getString("figure")
                        val messagesArray = data.getJSONArray("message")

                        for (i in 0 until messagesArray.length()) {
                            val messageObj = messagesArray.getJSONObject(i)
                            val id = messageObj.getString("id")
                            val type = messageObj.getString("type")
                            val message =
                                if (messageObj.isNull("message")) null else messageObj.getString("message")
                            val imageList =
                                if (messageObj.isNull("image_list")) null else messageObj.getString(
                                    "image_list"
                                )
                            val timeAdd = messageObj.getString("time_add")

                            // 解析時間字符串為 Date
                            val date = dateFormat.parse(timeAdd) ?: Date()

                            val authorId = if (type == "s") userId else targetXid
                            val authorName = if (type == "s") "You" else targetName
                            val authorAvatar = if (type == "s") "" else targetFigure

                            val chatMessage = if (imageList != null) {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    null,
                                    imageList,
                                    date // 傳入 Date 類型
                                )
                            } else {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    message ?: "",
                                    null,
                                    date // 傳入 Date 類型
                                )
                            }
                            messageArray.add(chatMessage)
                        }
                        messagesAdapter.addToEnd(messageArray, true)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


    /*
  //  private val dateFormat = SimpleDateFormat("a h:mm", Locale.getDefault())

    private suspend fun parseMessages(jsonResponse: String) {
        withContext(Dispatchers.Main) {
            try {
                val jsonObject = JSONObject(jsonResponse)
                if (jsonObject.getString("status") == "succ") {
                    val data = jsonObject.getJSONObject("data")
                    if (data.toString().length > 10) {
                        val target = data.getJSONObject("target")
                        val targetName = target.getString("name")
                        val targetFigure = target.getString("figure")
                        val messagesArray = data.getJSONArray("message")

                        for (i in 0 until messagesArray.length()) {
                            val messageObj = messagesArray.getJSONObject(i)
                            val id = messageObj.getString("id")
                            val type = messageObj.getString("type")
                            val message =
                                if (messageObj.isNull("message")) null else messageObj.getString("message")
                            val imageList =
                                if (messageObj.isNull("image_list")) null else messageObj.getString(
                                    "image_list"
                                )
                            val timeAdd = messageObj.getString("time_add")

                            // 解析時間字符串為 Date
                            val date = dateFormat.parse(timeAdd) ?: Date()

                            val authorId = if (type == "s") userId else targetXid
                            val authorName = if (type == "s") "You" else targetName
                            val authorAvatar = if (type == "s") "" else targetFigure

                            val chatMessage = if (imageList != null) {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    null,
                                    imageList,
                                    date // 傳入 Date 類型
                                )
                            } else {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    message ?: "",
                                    null,
                                    date // 傳入 Date 類型
                                )
                            }
                            messageArray.add(chatMessage)
                        }
                        messagesAdapter.addToEnd(messageArray, true)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
*/
    /*
    private suspend fun parseMessages(jsonResponse: String) {
        withContext(Dispatchers.Main) {
            try {
                val jsonObject = JSONObject(jsonResponse)
                if (jsonObject.getString("status") == "succ") {
                    val data = jsonObject.getJSONObject("data")
                    if (data.toString().length > 10) {
                        val target = data.getJSONObject("target")
                        val targetName = target.getString("name")
                        val targetFigure = target.getString("figure")
                        val messagesArray = data.getJSONArray("message")

                        for (i in 0 until messagesArray.length()) {
                            val messageObj = messagesArray.getJSONObject(i)
                            val id = messageObj.getString("id")
                            val type = messageObj.getString("type")
                            val message =
                                if (messageObj.isNull("message")) null else messageObj.getString("message")
                            val imageList =
                                if (messageObj.isNull("image_list")) null else messageObj.getString(
                                    "image_list"
                                )
                            val timeAdd = messageObj.getString("time_add")

                            val date = dateFormat.parse(timeAdd) ?: Date()
                            // 格式化為「上午/下午」格式
                            val displayTime = displayDateFormat.format(date)
                            val authorId = if (type == "s") userId else targetXid
                            val authorName = if (type == "s") "You" else targetName
                            val authorAvatar = if (type == "s") "" else targetFigure

                            val chatMessage = if (imageList != null) {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    null,
                                    imageList,
                                    displayTime
                                )
                            } else {
                                ChatMessage(
                                    id,
                                    authorId,
                                    authorName,
                                    authorAvatar,
                                    message ?: "",
                                    null,
                                    displayTime
                                )
                            }
                            messageArray.add(chatMessage)
                        }
                        messagesAdapter.addToEnd(messageArray, true)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
*/
    private fun sendTextMessage(text: String) {
        val message =
            ChatMessage(
                UUID.randomUUID().toString(), userId, "You", "", text, null,
                Date()
            )
        messagesAdapter.addToStart(message, true)

        // 通過前景服務發送消息
        val serviceIntent = Intent(this, WebSocketService::class.java)
        serviceIntent.putExtra("action", "send_text")
        serviceIntent.putExtra("fromXid", userId)
        serviceIntent.putExtra("targetXid", targetXid)
        serviceIntent.putExtra("message", text)
        startService(serviceIntent)
    }

    private fun sendImageMessage(imageUrl: String) {
        val message =
            ChatMessage(
                UUID.randomUUID().toString(), userId, "You", "", null, imageUrl,
                Date()
            )
        messagesAdapter.addToStart(message, true)

        // 通過前景服務發送圖片消息
        val serviceIntent = Intent(this, WebSocketService::class.java)
        serviceIntent.putExtra("action", "send_image")
        serviceIntent.putExtra("fromXid", userId)
        serviceIntent.putExtra("targetXid", targetXid)
        serviceIntent.putExtra("imageUrl", imageUrl)
        startService(serviceIntent)
    }
}