package tw.ibiz.yukachat



import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide


class FriendAdapter(
    private val friendList: List<Friend>,
    private val onItemClick: (Friend) -> Unit
) : RecyclerView.Adapter<FriendAdapter.FriendViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FriendViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_friend, parent, false)
        return FriendViewHolder(view)
    }

    override fun onBindViewHolder(holder: FriendViewHolder, position: Int) {
        val friend = friendList[position]
        holder.bind(friend)
        holder.itemView.setOnClickListener { onItemClick(friend) }
    }

    override fun getItemCount(): Int = friendList.size

    class FriendViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivAvatar: ImageView = itemView.findViewById(R.id.ivAvatar)
        private val tvName: TextView = itemView.findViewById(R.id.tvName)
        private val tvMessage: TextView = itemView.findViewById(R.id.tvMessage)
        private val tvTime: TextView = itemView.findViewById(R.id.tvTime)

        fun bind(friend: Friend) {
            // 載入頭像
            Glide.with(itemView.context)
                .load(friend.targetFigure)
                .placeholder(R.drawable.ic_default_avatar) // 預設圖示
                .error(R.drawable.ic_default_avatar) // 載入失敗時顯示的圖示
                .into(ivAvatar)

            tvName.text = friend.targetName
            tvMessage.text = friend.lateMessage
            tvTime.text = friend.timeLate
        }
    }
}