package tw.ibiz.yukachat

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI
import java.nio.ByteBuffer

class VoiceCallClient(private val context: Context, serverUri: String) {
    private val TAG = "VoiceCallClient"
    private lateinit var webSocketClient: WebSocketClient
    private lateinit var audioRecord: AudioRecord
    private lateinit var audioTrack: AudioTrack
    private val sampleRate = 44100 // 採樣率
    private val bufferSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )

    init {
        setupWebSocket(serverUri)
        // Only setup audio if permission is granted
        if (checkPermission()) {
            setupAudio()
        }
    }

    fun checkPermission(): Boolean {
        return if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request permission if not granted
            if (context is AppCompatActivity) {
                ActivityCompat.requestPermissions(
                    context,
                    arrayOf(Manifest.permission.RECORD_AUDIO),
                    REQUEST_CODE
                )
            }
            false // Permission not granted yet
        } else {
            Log.i(TAG, "錄音權限已授予")
            true // Permission granted
        }
    }

    private fun setupWebSocket(serverUri: String) {
        webSocketClient = object : WebSocketClient(URI(serverUri)) {
            override fun onOpen(handshakedata: ServerHandshake?) {
                Log.i(TAG, "WebSocket 連接成功")
                if (checkPermission()) {
                    setupAudio() // Ensure audio is set up if not already
                    startRecording()
                }
            }

            override fun onMessage(bytes: ByteBuffer?) {
                bytes?.let { playAudio(it.array()) }
            }

            override fun onMessage(message: String?) {
                // Handle text messages if needed
            }

            override fun onClose(code: Int, reason: String?, remote: Boolean) {
                Log.i(TAG, "WebSocket 關閉: $reason")
                stopRecording()
            }

            override fun onError(ex: Exception?) {
                Log.e(TAG, "WebSocket 錯誤: ${ex?.message}")
            }
        }
        webSocketClient.connect()
    }

    private fun setupAudio() {
        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            audioTrack = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize,
                AudioTrack.MODE_STREAM
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "缺少錄音權限: ${e.message}")
        }
    }

    private fun startRecording() {
        try {
            audioRecord.startRecording()
            Thread {
                val buffer = ByteArray(bufferSize)
                while (webSocketClient.isOpen) {
                    val read = audioRecord.read(buffer, 0, bufferSize)
                    if (read > 0) {
                        webSocketClient.send(buffer.copyOf(read))
                    }
                }
            }.start()
        } catch (e: SecurityException) {
            Log.e(TAG, "無法開始錄音，缺少權限: ${e.message}")
        }
    }

    private fun stopRecording() {
        try {
            audioRecord.stop()
            audioRecord.release()
            audioTrack.stop()
            audioTrack.release()
        } catch (e: IllegalStateException) {
            Log.e(TAG, "停止錄音失敗: ${e.message}")
        }
    }

    private fun playAudio(data: ByteArray) {
        try {
            audioTrack.play()
            audioTrack.write(data, 0, data.size)
        } catch (e: IllegalStateException) {
            Log.e(TAG, "播放音頻失敗: ${e.message}")
        }
    }

    fun disconnect() {
        webSocketClient.close()
    }

    companion object {
        private const val REQUEST_CODE = 100
    }
}