package tw.ibiz.yukachat

import com.google.gson.annotations.SerializedName

data class Friend(
    @SerializedName("target_name") val targetName: String,
    @SerializedName("target_figure") val targetFigure: String,
    @SerializedName("target_sid") val targetXid: String,
    @SerializedName("late_message") val lateMessage: String,
    @SerializedName("time_late") val timeLate: String
)