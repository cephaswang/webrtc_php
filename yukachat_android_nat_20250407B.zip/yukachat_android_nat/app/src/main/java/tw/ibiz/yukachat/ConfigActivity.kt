package tw.ibiz.yukachat

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

class ConfigActivity : AppCompatActivity() {

    private lateinit var languageLabel: TextView
    private lateinit var languageField: TextView
    private lateinit var translateLabel: TextView
    private lateinit var translateField: TextView
    private lateinit var submitButton: Button

    private val languageDic = mapOf(
        "tw" to "繁體中文",
        "en" to "英文",
        "cn" to "簡體中文"
    )

    private val translateDic = mapOf(
        "0" to "否",
        "1" to "是"
    )

    private var xid: String = ""
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        xid = sharedPref.getString("xid", "") ?: ""

        title = "翻譯設定"

        // 返回按鈕點擊事件
        val backButton: ImageView = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            Log.d("ConfigActivity", "返回按鈕被點擊")
            finish() // 結束當前 Activity
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        initViews()
        setupListeners()
        loadSettingsFromAPI()
    }

    private fun initViews() {
        languageLabel = findViewById(R.id.languageLabel)
        languageField = findViewById(R.id.languageField)
        translateLabel = findViewById(R.id.translateLabel)
        translateField = findViewById(R.id.translateField)
        submitButton = findViewById(R.id.submitButton)

        // Set initial values
        languageField.setText("  繁體中文")
        translateField.setText("  否")
    }

    private fun setupListeners() {
        languageField.setOnClickListener { selectLanguage() }
        translateField.setOnClickListener { selectTranslation() }
        submitButton.setOnClickListener { submitButtonTapped() }
    }

    @SuppressLint("SetTextI18n")
    private fun selectLanguage() {
        showSelectionDialog("選擇語言", languageDic.values.toList()) { selected ->
            languageField.setText("  $selected")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun selectTranslation() {
        showSelectionDialog("自動翻譯", translateDic.values.toList()) { selected ->
            translateField.setText("  $selected")
        }
    }

    private fun submitButtonTapped() {
        val language = languageField.text.toString().trim()
        val translate = translateField.text.toString().trim()

        if (language.isEmpty() || translate.isEmpty()) {
            showAlert("錯誤", "請完成所有選擇")
            return
        }

        val languageKey = languageDic.entries.firstOrNull { it.value == language }?.key ?: "tw"
        val translateKey = translateDic.entries.firstOrNull { it.value == translate }?.key ?: "0"

        // Save to SharedPreferences
        getSharedPreferences("YukaChat", MODE_PRIVATE).edit()
            .putString("selectedLanguage", languageKey)
            .putString("autoTranslate", translateKey)
            .apply()

        updateSettings(languageKey, translateKey, xid) { success, message ->
            runOnUiThread {
                if (success) {
                    showAlert("成功", message ?: "設置已保存")
                } else {
                    showAlert("錯誤", message ?: "更新失敗")
                }
            }
        }
    }

    private fun loadSettingsFromAPI() {
        val url = "${ConfigIni.SERVER_URL}app/api/?mode=setting&xid=$xid"

        println(url)

        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                setDefaultSettings()
            }

            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { responseBody ->
                    try {
                        val json = JSONObject(responseBody)

                        println(json)

                        if (json.getString("status") == "succ") {
                            val data = json.getJSONObject("data")

                            val languageKey = data.getString("language")
                            val translateKey = data.getString("translate")

                            runOnUiThread {
                                languageField.setText("  ${languageDic[languageKey] ?: languageDic["tw"]}")
                                translateField.setText("  ${translateDic[translateKey] ?: translateDic["0"]}")
                            }
                        } else {
                            setDefaultSettings()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        setDefaultSettings()
                    }
                } ?: run {
                    setDefaultSettings()
                }
            }
        })
    }

    @SuppressLint("SetTextI18n")
    private fun setDefaultSettings() {
        runOnUiThread {
            languageField.setText("  ${languageDic["tw"]}")
            translateField.setText("  ${translateDic["0"]}")
        }
    }

    private fun updateSettings(language: String, translate: String, xid: String, callback: (Boolean, String?) -> Unit) {
        val url = "${ConfigIni.SERVER_URL}user/app/api/?mode=setting_update&language=$language&translate=$translate&xid=$xid"

        println(url)

        val request = Request.Builder()
            .url(url)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(false, "Network error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { responseBody ->
                    try {
                        val json = JSONObject(responseBody)
                        println(json)
                        if (json.getString("status") == "succ") {
                            val title = json.optString("title", "Settings updated successfully")
                            callback(true, title)
                        } else {
                            val title = json.optString("title", "Update failed")
                            callback(false, title)
                        }
                    } catch (e: Exception) {
                        callback(false, "Failed to parse response")
                    }
                } ?: run {
                    callback(false, "No response body")
                }
            }
        })
    }

    private fun showSelectionDialog(title: String, options: List<String>, callback: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(options.toTypedArray()) { _, which ->
                callback(options[which])
            }
            .setNegativeButton("取消") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showAlert(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("確定", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}