<?php
// WebSocket 伺服器地址
// php test_websocket.php moAMnWxvCiOu8u250317140134 iEUkJZdR6Hsu9e250312163547
$websocketServer = "wss://ims.yukaai.com:8080/";

//$websocketServer = "ws:///192.168.0.12:8080/";

// 檢查是否提供了 sid 和 targetSid
if (empty($argv[1]) || empty($argv[2])) {
    die("請提供 sid 和 targetSid 作為命令列參數。\n用法：php test_websocket.php <sid> <targetSid>\n");
}

$sid = $argv[1]; // 從命令列獲取 sid
$targetSid = $argv[2]; // 從命令列獲取 targetSid

// 測試 connect 功能
function testConnect($sid) {
    global $websocketServer;

    $message = json_encode([
        "type" => "connect",
        "sid" => $sid
    ]);

    $command = "echo '$message' | websocat -v $websocketServer";
    $response = shell_exec($command);

    echo "Testing connect...\n";
    echo "Response: $response\n";
}

// 測試 send_text 功能
function testSendText($sid, $targetSid) {
    global $websocketServer;

    $message = json_encode([
        "type" => "send_text",
        "sid" => $sid,
        "target_sid" => $targetSid,
        "message" => "你好，這是測試訊息！"
    ]);

    $command = "echo '$message' | websocat -v $websocketServer";
    $response = shell_exec($command);

    echo "Testing send_text...\n";
    echo "Response: $response\n";
}

// 測試 send_file 功能
function testSendFile($sid, $targetSid) {
    global $websocketServer;

    $message = json_encode([
        "type" => "send_file",
        "sid" => $sid,
        "target_sid" => $targetSid,
        "file_list" => "image.png"
    ]);

    $command = "echo '$message' | websocat -v $websocketServer";
    $response = shell_exec($command);

    echo "Testing send_file...\n";
    echo "Response: $response\n";
}

// 執行測試
testConnect($sid);
testSendText($sid, $targetSid);
testSendFile($sid, $targetSid);
?>