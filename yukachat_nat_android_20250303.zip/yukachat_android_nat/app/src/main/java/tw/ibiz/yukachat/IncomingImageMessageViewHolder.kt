package tw.ibiz.yukachat

import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.stfalcon.chatkit.messages.MessageHolders

/*
class IncomingImageMessageViewHolder(itemView: View) :
    MessageHolders.IncomingImageMessageViewHolder<MessageModel>(itemView) {

    private val imageView: ImageView = itemView.findViewById(R.id.imageView)

    override fun onBind(message: MessageModel) {
        super.onBind(message)
        Glide.with(itemView.context).load(message.imageUrl).into(imageView)
    }
}
*/