package tw.ibiz.yukachat

/*
android 13
ShowGlideGptActivity
import com.bumptech.glide.Glide
四個按鍵事件，呈現四種圖檔範例，
1 網路圖片，若檔案不存在，則改用資源檔ic_user，
2 手機端選取的圖檔(打印檔案位置，打印檔案容量)
3 拍照需建立依時間命名的暫存檔(打印檔案位置，打印檔案容量)
4 資源檔 ic_user


private val imageUrl = "https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2025/02/26/realtime/31564330.jpg&x=0&y=0&sw=0&sh=0&sl=W&fw=800&exp=3600&w=930&nt=1"  // 替換成你的網路圖片
*/


import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShowGlideActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var tempPhotoFile: File
    private val REQUEST_CAMERA = 100

    // 註冊相機和圖片選擇的 Activity Result
    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            loadTempPhoto()
        }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { loadLocalImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_glide)

        imageView = findViewById(R.id.imageView)

        // 設置四個按鈕
        findViewById<Button>(R.id.btnNetwork).setOnClickListener { loadNetworkImage() }
        findViewById<Button>(R.id.btnLocal).setOnClickListener { pickLocalImage() }
        findViewById<Button>(R.id.btnCamera).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.btnResource).setOnClickListener { loadResourceImage() }
    }

    // 1. 載入網路圖片，若失敗則使用 ic_user
    private fun loadNetworkImage() {
        val imageUrl = "https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2025/02/26/realtime/31564330.jpg&x=0&y=0&sw=0&sh=0&sl=W&fw=800&exp=3600&w=930&nt=1"
        Glide.with(this)
            .load(imageUrl)
            .error(R.drawable.ic_user) // 若載入失敗使用資源檔
            .into(imageView)
    }

    // 2. 載入手機端選取的圖檔
    private fun loadLocalImage(uri: Uri) {
        Glide.with(this)
            .load(uri)
            .into(imageView)

        // 打印檔案資訊
        contentResolver.openInputStream(uri)?.use { inputStream ->
            val fileSize = inputStream.available() / 1024 // KB
            println("檔案位置: $uri")
            println("檔案容量: $fileSize KB")
        }
    }

    private fun pickLocalImage() {
        pickImageLauncher.launch("image/*")
    }

    // 3. 拍照並載入臨時檔案
    private fun takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA)
            return
        }

        // 建立時間命名的暫存檔
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        tempPhotoFile = File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)

        val photoUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", tempPhotoFile)
        takePictureLauncher.launch(photoUri)
    }

    private fun loadTempPhoto() {
        Glide.with(this)
            .load(tempPhotoFile)
            .into(imageView)

        // 打印檔案資訊
        val fileSize = tempPhotoFile.length() / 1024 // KB
        println("檔案位置: ${tempPhotoFile.absolutePath}")
        println("檔案容量: $fileSize KB")
    }

    // 4. 載入資源檔 ic_user
    private fun loadResourceImage() {
        Glide.with(this)
            .load(R.drawable.ic_user)
            .into(imageView)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            takePhoto()
        }
    }
}