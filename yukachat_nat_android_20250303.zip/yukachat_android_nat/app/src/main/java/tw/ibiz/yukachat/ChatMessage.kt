package tw.ibiz.yukachat


import com.stfalcon.chatkit.commons.models.IMessage
import com.stfalcon.chatkit.commons.models.IUser
import com.stfalcon.chatkit.commons.models.MessageContentType
import java.util.Date

class ChatMessage(
    private val id: String,
    private val authorId: String,
    private val authorName: String,
    private val authorAvatar: String,
    private val text: String?,
    private val imageUrl: String?,
    private val createdAt: Date
) : IMessage, MessageContentType.Image {

    override fun getId(): String = id

    override fun getText(): String = text ?: ""

    override fun getCreatedAt(): Date = createdAt

    override fun getUser(): IUser = Author(authorId, authorName, authorAvatar)

    override fun getImageUrl(): String? = imageUrl

    // Check if message has content
    fun hasImage(): Boolean = !imageUrl.isNullOrEmpty()
}

class Author(
    private val id: String,
    private val name: String,
    private val avatar: String
) : IUser {

    override fun getId(): String = id

    override fun getName(): String = name

    override fun getAvatar(): String = avatar
}