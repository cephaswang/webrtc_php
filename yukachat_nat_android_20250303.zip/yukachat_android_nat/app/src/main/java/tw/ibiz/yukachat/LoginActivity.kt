package tw.ibiz.yukachat

/* deepseek

brew services restart httpd
查看 Apache 錯誤日誌
tail -f /opt/homebrew/var/log/httpd/error_log
清除 Apache 錯誤日誌
sudo truncate -s 0 /opt/homebrew/var/log/httpd/error_log

1. 查看本機（內網）IP 地址
如果你的 macOS 連接到 Wi-Fi，可以使用：
ipconfig getifaddr en0
192.168.0.12

如果使用 有線網路（Ethernet），則用：
ipconfig getifaddr en1
192.168.0.15

LoginActivity
Android 12 kotlin
變量 token == “未定義”
則 delay 8 秒 運行 onstart



LoginActivity
Android 12 kotlin 語言設定

用線性佈局

由上而下

圖檔，居中 yuka_logo，版面(CircleImageView)
文字，歡迎使用 Yuka AI Chat
文字，帳號*，靠左
輸入框，提示(請輸入帳號)，版面(灰色圓角外框)，文字，黑色，提示，黑色
文字，密碼*，靠左
輸入框，提示(請輸入密碼)，版面(灰色圓角外框)，文字，黑色，提示，黑色
按鍵，文字(登入)，版面(#2196F3色圓角外框)，事件，打印
文字，註冊帳號，灰色，靠左，事件，打印
文字，忘記密碼，灰色，靠左，事件，打印


LoginActivity
Android 12 kotlin

讀取 xid 寫入 SharedPreferences 記錄

EditText
帳號 account_input
密碼 password_input

Button
login_button
事件
將 account_input password_input 寫入 SharedPreferences
傳送 account_input password_input 到 api get 不用 okhttp

login_result
解析回傳 json
status 的值若等於 succ 打印登入成功 ，跳轉回到上一頁 ConversationsActivity
不等於 打印登入失敗
title 打印值

https://ims.yukaai.com/user/app/api/?mode=log_in&is_uu=(account_input)&is_pp=(password_input)&xid=(xid)
中文


http://192.168.0.12/api.php?mode=log_in&is_uu=(account_input)&is_pp=(password_input)&cmark=(cmark)
中文


改用 https://ims.yukaai.com/app/api/?mode=token&device=ios&token=test&language=tw


ConversationsActivity
Android 12 kotlin 聊天主頁面
完整 import

fun apiLoaderList() 不用 okhttp

val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
讀取 cmark 寫入 SharedPreferences 記錄

val apiUrl = "https://ims.yukaai.com/im/app/api/?mode=target_list&cmark=$cmark"
解析回傳 json 打印 值

ConversationsActivity
Android 12 kotlin 聊天主頁面
完整 import

延遲 1 秒 檢查 變量 isLogin == true ， 運行 apiLoaderList()


ConversationsActivity
Android 12 kotlin 聊天主頁面
完整 import

檢查是否巳登入 fun checkIfLoggedIn

登入 login fun
val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
從全域記錄讀取帳號 account ，密碼 password， xid

如果全域記錄參數不完整，則結束。

訪問 api
https://ims.yukaai.com/user/app/api/?mode=log_in&is_uu=(account)&is_pp=(password)&xid=(xid)

讀取回傳 json
if status == "succ"
登入成功
全域記錄 logged_in 設定為 true
運行 apiLoaderList()

登入失敗
全域記錄 logged_in 設定為 false
跳轉到下一頁 LoginActivity
fun 結束

ConversationsActivity
Android 12 kotlin 聊天主頁面
完整 import

val sharedPref = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
全域記錄 帳號 account ，密碼 password， xid 設定為空


*/

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.messaging.FirebaseMessaging
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException


class LoginActivity : AppCompatActivity() {

    private lateinit var xid: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        getFirebaseToken()

        val accountInput = findViewById<EditText>(R.id.account_input)
        val passwordInput = findViewById<EditText>(R.id.password_input)

        // 登入按鈕點擊事件
        val loginButton: Button = findViewById(R.id.login_button)
        loginButton.setOnClickListener {
            Log.d("LoginActivity", "登入按鈕被點擊")
            // finish() // 結束當前 Activity
            val account = accountInput.text.toString()
            val password = passwordInput.text.toString()

            if (account.isNotEmpty() && password.isNotEmpty()) {

                // 將帳號和密碼保存到 SharedPreferences
                saveCredentialsToSharedPreferences(account, password)

                // 發送 API 請求
                sendLoginRequest(account, password)

            } else {
                Toast.makeText(this, "請輸入帳號與密碼", Toast.LENGTH_SHORT).show()
            }
        }

        // 註冊帳號點擊事件
        val registerText: TextView = findViewById(R.id.register_text)
        registerText.setOnClickListener {
            Log.d("LoginActivity", "註冊帳號被點擊")
            // finish() // 結束當前 Activity
        }


        // 忘記密碼點擊事件
        val forgotPasswordText: TextView = findViewById(R.id.forgot_password_text)
        forgotPasswordText.setOnClickListener {
            Log.d("LoginActivity", "忘記密碼被點擊")
        }
    }


    override fun onStart() {
        super.onStart()


        val sharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        xid = sharedPreferences.getString("xid", "default_value") ?: "default_value"
        Log.d("LoginActivity:onStart", "xid $xid")

    }

    private fun getFirebaseToken() {
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.e("Firebase", "Fetching token failed", task.exception)
                    return@addOnCompleteListener
                }
                val token = task.result
                Log.d("Firebase", "Retrieved token: $token")
            }
            .addOnSuccessListener { token -> Log.d("Firebase", "Token: $token") }
            .addOnFailureListener { Log.e("Firebase", "Failed to get token") }

    }


    private fun saveCredentialsToSharedPreferences(account: String, password: String) {
        val sharedPreferences by lazy {
            getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        }
        val editor = sharedPreferences.edit()
        editor.putString("account", account)
        editor.putString("password", password)
        editor.apply()
    }


    // 使用 OkHttp 發送 GET 請求
    private fun sendLoginRequest(account: String, password: String) {
        val sharedPreferences = getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)
        // 從 SharedPreferences 讀取 xid
        val xid = sharedPreferences.getString("xid", "") ?: ""

        // 組合 API URL
        val apiUrl =
            "${ConfigIni.SERVER_URL}user/app/api/?mode=log_in&is_uu=${account}&is_pp=${password}&xid=${xid}"

        Log.d("sendLoginRequest", apiUrl)

        val request = Request.Builder()
            .url(apiUrl)
            .get()
            .build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("LoginActivity", "API 請求錯誤: ${e.message}")
                runOnUiThread {
                    //tvResult.text = "無法連接伺服器"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful) {
                        Log.e("LoginActivity", "伺服器錯誤: ${response.code}")
                        runOnUiThread {
                           // tvResult.text = "伺服器錯誤: ${response.code}"
                        }
                        return
                    }

                    val responseData = response.body?.string()
                    runOnUiThread { handleApiResponse(responseData) }
                }
            }
        })
    }

    // 處理 API 回應
    private fun handleApiResponse(response: String?) {
        if (response.isNullOrEmpty()) {
          //  tvResult.text = "無法解析伺服器回應"
            return
        }

        try {
            val jsonObject = JSONObject(response)
            val status = jsonObject.optString("status", "")
           // val title = jsonObject.optString("title", "")

           // tvResult.text = title // 顯示 title

            if (status == "succ") {
                Log.d("LoginActivity", "登入成功")
                // 跳轉到 ConversationsActivity
                val intent = Intent(this, ConversationsActivity::class.java)
                startActivity(intent)
                finish() // 關閉 LoginActivity
            } else {
                Log.d("LoginActivity", "登入失敗")
            }
        } catch (e: Exception) {
            Log.e("LoginActivity", "JSON 解析錯誤: ${e.message}")
           // tvResult.text = "資料解析錯誤"
        }
    }


}