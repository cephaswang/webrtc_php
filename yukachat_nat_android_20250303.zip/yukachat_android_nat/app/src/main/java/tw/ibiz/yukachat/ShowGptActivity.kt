package tw.ibiz.yukachat

/*
ChatGpt
Android 12 kotlin
ShowGptActivity
ImageView
按鍵1，事件，選取圖檔，ImageView 呈現，打印檔案所在位置，打印檔案所在位置絕對路徑
按鍵2，事件，拍照，ImageView 呈現，建立暫存檔，打印檔案所在位置絕對路徑

/storage/emulated/0/Pictures/Messenger/received_2327896100924845.jpeg

*/


import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ShowGptActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var btnSelectImage: Button
    private lateinit var btnTakePhoto: Button
    private var currentPhotoPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_gpt)

        imageView = findViewById(R.id.imageView)
        btnSelectImage = findViewById(R.id.btnSelectImage)
        btnTakePhoto = findViewById(R.id.btnTakePhoto)

        // 選取圖檔
        btnSelectImage.setOnClickListener {
            selectImage()
        }

        // 拍照
        btnTakePhoto.setOnClickListener {
            takePhoto()
        }
    }

    // 啟動選取圖檔
    private fun selectImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        selectImageLauncher.launch(intent)
    }

    // 選取圖片後處理
    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val selectedImageUri: Uri? = result.data?.data
            selectedImageUri?.let {
                imageView.setImageURI(it)

                // **打印檔案 URI**
                Log.d("ShowGptActivity", "Selected Image URI: $it")

                // **取得絕對路徑並打印**
                val absolutePath = getRealPathFromURI(it)
                Log.d("ShowGptActivity", "Selected Image Absolute Path: $absolutePath")
            }
        }
    }

    // 取得選取圖片的絕對路徑
    private fun getRealPathFromURI(uri: Uri): String? {
        var result: String? = null
        if (contentResolver != null) {
            val cursor: Cursor? = contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATA), null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val columnIndex = it.getColumnIndex(MediaStore.Images.Media.DATA)
                    result = if (columnIndex != -1) it.getString(columnIndex) else null
                }
            }
        }
        return result
    }

    // 拍照並存儲到暫存檔案
    private fun takePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: IOException) {
            Log.e("ShowGptActivity", "Error creating file: ${ex.message}")
            null
        }

        photoFile?.also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                it
            )
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            takePhotoLauncher.launch(intent)
        }
    }

    // 建立暫存檔案
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    // 拍照後處理
    private val takePhotoLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            currentPhotoPath?.let {
                val bitmap: Bitmap = BitmapFactory.decodeFile(it)
                imageView.setImageBitmap(bitmap)

                // **打印檔案 URI**
                Log.d("ShowGptActivity", "Captured Photo URI: ${Uri.fromFile(File(it))}")

                // **打印檔案絕對路徑**
                Log.d("ShowGptActivity", "Captured Photo Absolute Path: $it")
            }
        }
    }
}
